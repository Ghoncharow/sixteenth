<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$queryResult = array(
    "method" => $_POST["METHOD"], 
    "number" => $_POST["NUMBER"], 
    "name" => $_POST["NAME"], 
    "sort" => $_POST["SORT"], 
);
$obEnum = new CUserFieldEnum;
$FIELD_ID = 311;

switch ($_POST["METHOD"]) {
    case '@INSERT':
        $obEnum->SetEnumValues($FIELD_ID, array(
            "n0" => array("VALUE" => $_POST["NAME"], "SORT" => $_POST["SORT"]),
        ));
        $rsEnum = $obEnum->GetList(array("ID" => "DESC"), array("USER_FIELD_ID" => $FIELD_ID));
        $PropID = $rsEnum->Fetch()["ID"];
        if ($PropID) $queryResult["number"] = $PropID;
        break;
    case '@UPDATE':
        $obEnum->SetEnumValues($FIELD_ID, array(
            $_POST["NUMBER"] => array("VALUE" => $_POST["NAME"], "SORT" => $_POST["SORT"]),
        ));
        break;
    case '@DELETE':
        $obEnum->SetEnumValues($FIELD_ID, array(
            $_POST["NUMBER"] => array("DEL" => "Y"),
        ));
        break;
    default:
        $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);