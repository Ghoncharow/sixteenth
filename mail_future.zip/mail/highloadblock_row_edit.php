<?php define('ADMIN_MODULE_NAME', 'highloadblock');

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/bx_root.php");

define("START_EXEC_PROLOG_BEFORE_1", microtime());
$GLOBALS["BX_STATE"] = "PB";
unset($_REQUEST["BX_STATE"]);
unset($_GET["BX_STATE"]);
unset($_POST["BX_STATE"]);
unset($_COOKIE["BX_STATE"]);
unset($_FILES["BX_STATE"]);

define("NEED_AUTH", false);
define("ADMIN_SECTION", false);

if (isset($_REQUEST['bxpublic']) && $_REQUEST['bxpublic'] == 'Y' && !defined('BX_PUBLIC_MODE'))
	define('BX_PUBLIC_MODE', 1);

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include.php");
if(!headers_sent())
	header("Content-type: text/html; charset=".LANG_CHARSET);

if (defined('BX_PUBLIC_MODE') && BX_PUBLIC_MODE == 1)
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST')
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_jspopup.php");
}

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/admin_tools.php");
require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");

CMain::PrologActions();
CJSCore::Init(array('jquery2', 'masked_input'));

IncludeModuleLangFile(__FILE__);
IncludeModuleLangFile(__DIR__.'/highloadblock_rows_list.php');

?>
<style>
tr.adm-footer-wrap, #main_navchain, #hlrow_edit_8_tabs, 
.bx-core-window.bx-core-adm-dialog, .bx-core-dialog-overlay, 
.adm-detail-content-cell-l > img, #tr_ID, #btn_list {
	display: none !important;
}
.adm-main-wrap > tbody > tr:first-child {
	height: 10px;
}
.adm-main-wrap {
	min-width: 800px !important;
}
#adm-workarea {
    padding: 0 10px !important;
}
</style>
<?
$currentUserArr = CUser::GetUserGroup($GLOBALS["USER"]->GetId());
$currentUser = $GLOBALS["USER"]->IsAdmin() || in_array("47", $currentUserArr);

function sendMailAndMessages($arFields) {
	if (IsModuleInstalled("im") && CModule::IncludeModule("im")) {
		// $fromSender = (CUser::GetByID($GLOBALS["USER"]->GetID()))->Fetch()["EMAIL"];
		// $lettersHeader = "Федеральное казначейство";
		// $protocolHeaders  = 'MIME-Version: 1.0' . "\r\n";
		// $protocolHeaders .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		// $protocolHeaders .= "From: <".$fromSender.">\r\n";
		$candidatName = $arFields["UF_LAST_NAME"].' '.$arFields["UF_NAME"].' '.$arFields["UF_SECOND_NAME"];
		if (empty($arFields["UF_LAST_NAME"])) $candidatName = $arFields["UF_NAME"];
		$notifyMessageOut = "$candidatName претендует на замещение вакантной должности.";
		$notifyMessageOut .= ' Дата рассмотрения заявки отделом кадров: '.$arFields["UF_HR_ALLOTMENT"].'.';
		$arMessageFieldsToChat = array(
			// получатель
		   "TO_USER_ID" => '1',
		   // отправитель
		   "FROM_USER_ID" => $GLOBALS["USER"]->GetID(), 
		   // тип уведомления
		   "NOTIFY_TYPE" => IM_NOTIFY_FROM, 
		   // модуль запросивший отправку уведомления
		   "NOTIFY_MODULE" => "calendar",
		   // текст уведомления на сайте
		   "NOTIFY_MESSAGE" => $notifyMessageOut, 
		   // текст уведомления для отправки на почту (или XMPP), если различий нет - не задаем параметр
		   "NOTIFY_MESSAGE_OUT" => $notifyMessageOut 
		);
		$dataGroups1 = CUser::GetList(($by="ID"), ($order="ASC"), array('GROUPS_ID' => array(47), 'ACTIVE' => 'Y'));
		while($arUserGroups = $dataGroups1->Fetch()) {
			$arMessageFieldsToChat["TO_USER_ID"] = $arUserGroups['ID'];
			CIMNotify::Add($arMessageFieldsToChat);
			// mail($arUserGroups["EMAIL"], $lettersHeader, $notifyMessageOut, $protocolHeaders);
		}
	}
}
// $dataGroups = CUser::GetList(($by="ID"), ($order="ASC"), array('GROUPS_ID' => array(9), 'ACTIVE' => 'Y'));
// while($arUser = $dataGroups->Fetch()) {
//     $arUserTest[] = $arUser;
// }
// echo '<script type="text/javascript">console.log('.json_encode($arUserTest).');</script>';


if (!CModule::IncludeModule(ADMIN_MODULE_NAME))
{
	echo 'Модуль Highloadblock не подключается.';
	// $APPLICATION->AuthForm(GetMessage('ACCESS_DENIED'));
}

use Bitrix\Highloadblock as HL;

$hlblock = null;

// get entity info
$_REQUEST['ENTITY_ID'] = 8;
if (isset($_REQUEST['ENTITY_ID']))
{
	$hlblock = HL\HighloadBlockTable::getById($_REQUEST['ENTITY_ID'])->fetch();

	if (!empty($hlblock))
	{
		//localization
		$lang = HL\HighloadBlockLangTable::getList(array(
					'filter' => array('ID' => $hlblock['ID'], '=LID' => LANG))
				)->fetch();
		if ($lang)
		{
			$hlblock['NAME_LANG'] = $lang['NAME'];
		}
		else
		{
			$hlblock['NAME_LANG'] = $hlblock['NAME'];
		}
		//check rights
		if ($USER->isAdmin() || true)
		{
			$canEdit = $canDelete = true;
		}
		else
		{
			$operations = HL\HighloadBlockRightsTable::getOperationsName($ENTITY_ID);
			if (empty($operations))
			{
				$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
			}
			else
			{
				$canEdit = in_array('hl_element_write', $operations);
				$canDelete = in_array('hl_element_delete', $operations);
			}
		}
	}
}

if (empty($hlblock))
{
	// 404
	if ($_REQUEST['mode'] == 'list')
	{
		require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_js.php');
	}
	else
	{
		require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php');
	}

	echo GetMessage('HLBLOCK_ADMIN_ROW_EDIT_NOT_FOUND');

	if ($_REQUEST['mode'] == 'list')
	{
		require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin_js.php');
	}
	else
	{
		require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php');
	}

	die();
}

$is_create_form = true;
$is_update_form = false;
$action = isset($_REQUEST['action']) ? htmlspecialcharsbx($_REQUEST['action']) : 'add';

$isEditMode = $canEdit;

$errors = array();

// get entity
$entity = HL\HighloadBlockTable::compileEntity($hlblock);

/** @var HL\DataManager $entity_data_class */
$entity_data_class = $entity->getDataClass();

// get row
$row = null;
if (isset($_REQUEST['ID']) && $_REQUEST['ID'] > 0)
{
	$row = $entity_data_class::getById($_REQUEST['ID'])->fetch();

	if (empty($row))
	{
		$row = null;
	}

	if (!empty($row))
	{
		if ($action != 'copy')
		{
			if ($action != 'delete')
			{
				$action = 'update';
			}
			$is_update_form = true;
			$is_create_form = false;
		}
	}
}

// if ($is_create_form)
// {
// 	$APPLICATION->SetTitle(GetMessage('HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_NEW', array('#NAME#' => $hlblock['NAME_LANG'])));
// }
// else
// {
// 	$APPLICATION->SetTitle(GetMessage('HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_EDIT',
// 		array('#NAME#' => $hlblock['NAME_LANG'], '#NUM#' => $row['ID']))
// 	);
// }

$APPLICATION->SetTitle("Карточка кандидата");

// form
$aTabs = array(
	array('DIV' => 'edit1', 'TAB' => "Карточка кандидата", 'ICON'=>'ad_contract_edit', 'TITLE'=> "Карточка кандидата")
);

$tabControl = new CAdminForm('hlrow_edit_'.$hlblock['ID'], $aTabs);

// delete action
if ($is_update_form && $action === 'delete' && $canDelete && check_bitrix_sessid())
{
	$entity_data_class::delete($row['ID']);
	// LocalRedirect('highloadblock_rows_list.php?ENTITY_ID='.$hlblock['ID'].'&lang='.LANGUAGE_ID);
}

// save action
if ((strlen($save)>0 || strlen($apply)>0) && $REQUEST_METHOD=='POST' && $canEdit && check_bitrix_sessid())
{
	$data = array();
	// AddMessage2Log("update2<script>console.log(".json_encode($_POST).");</script><br>", '', 0);

	$USER_FIELD_MANAGER->EditFormAddFields('HLBLOCK_'.$hlblock['ID'], $data);

	/** @param Bitrix\Main\Entity\AddResult $result */
	if ($is_update_form)
	{
		$ID = intval($_REQUEST['ID']);

		// $data["UF_HR_STATUS"] = (empty($data["UF_HR_STATUS"])) ? "80" : $data["UF_HR_STATUS"];
		if ($_POST["METHOD"] == "@UPDATE") {
			$data1["UF_HR_STATUS"] = "81";
			$data["UF_HR_ALLOTMENT"] = $data1["UF_HR_ALLOTMENT"] = date('d.m.Y', time());
			if (empty($data["UF_HR_CATEGORY"][0])) $data1["UF_HR_CATEGORY"] = array("84");
			$data1["UF_HR_SUPERVISOR"] = $GLOBALS["USER"]->GetId();
			sendMailAndMessages($data);
			unset($_POST["METHOD"]);
			$_FILES['UF_UPLOAD_FILE']['error'] = 1;
			$data = $data1;
		}
		unset($data["UF_HR_UPLOADS"]);
		if (isset($_FILES) && ($_FILES['UF_UPLOAD_FILE']['error'] == 0) && ($_FILES["file"]["size"] < 5000000)) {
			// Директория для размещения файла
			$destiationDir = str_replace('mail', '', dirname(__FILE__));
			$destiationDir .= "upload/mail/hr/user_$ID/";
			if (!file_exists($destiationDir)) mkdir($destiationDir, 0777, true);
			$destiationDir .= $_FILES['UF_UPLOAD_FILE']['name'];
			// Перемещаем файл из каталога для временного хранения в желаемую директорию
			move_uploaded_file($_FILES['UF_UPLOAD_FILE']['tmp_name'], $destiationDir);
			$data["UF_HR_UPLOADS"] = serialize($_FILES['UF_UPLOAD_FILE']);
		}
		// AddMessage2Log("\$destiationDir<script>console.log(".json_encode($destiationDir).");</script><br>", '', 0);

		$data["UF_TIMESTAMP_X"] = date('d.m.Y H:i:s');
		$result = $entity_data_class::update($ID, $data);
		// AddMessage2Log("update3<script>console.log(".json_encode($data).");</script><br>", '', 0);
	}
	else
	{
		unset($data["UF_HR_UPLOADS"]);
		$data["UF_HR_STATUS"] = "80";
		$data["UF_TIMESTAMP_X"] = date('d.m.Y H:i:s');
		$data["UF_DATE_REGISTER"] = date('d.m.Y H:i:s');
		$result = $entity_data_class::add($data);
		// AddMessage2Log("add<script>console.log(".json_encode($data).");</script><br>", '', 0);

		$ID = $result->getId();
		// AddMessage2Log("add<script>console.log(".json_encode($ID).");</script><br>", '', 0);

		if (isset($_FILES) && ($_FILES['UF_UPLOAD_FILE']['error'] == 0) && ($_FILES["file"]["size"] < 5000000)) {
			// Директория для размещения файла
			$destiationDir = str_replace('mail', '', dirname(__FILE__));
			$destiationDir .= "upload/mail/hr/user_$ID/";
			if (!file_exists($destiationDir)) mkdir($destiationDir, 0777, true);
			$destiationDir .= $_FILES['UF_UPLOAD_FILE']['name'];
			// Перемещаем файл из каталога для временного хранения в желаемую директорию
			move_uploaded_file($_FILES['UF_UPLOAD_FILE']['tmp_name'], $destiationDir);
			$uploadFile = serialize($_FILES['UF_UPLOAD_FILE']);
			$entity_data_class::update($ID, array('UF_HR_UPLOADS' => $uploadFile));
		}
		// AddMessage2Log("\$destiationDir<script>console.log(".json_encode($destiationDir).");</script><br>", '', 0);
	}

	if($result->isSuccess())
	{
		if ($is_update_form) {
			LocalRedirect($_SERVER['REQUEST_URI']);
		} else {
			LocalRedirect($_SERVER['REQUEST_URI'].'&ID='.$ID);
		}
	}
	else
	{
		$errors = $result->getErrorMessages();

		// rewrite values
		foreach ($data as $k => $v)
		{
			if (isset($row[$k]))
			{
				$row[$k] = $v;
			}
		}
	}
}

// menu
// $aMenu = array(
// 	array(
// 		'TEXT'	=> (!empty($_GET["mailId"])) ? "Назад к письму" : "Вернуться к списку",
// 		'TITLE'	=> (!empty($_GET["mailId"])) ? "По клику перейдёт к письму" : "По клику вернётся к списку",
// 		'LINK'	=> (!empty($_GET["mailId"])) ? $_COOKIE['PREVIOUS_PAGE_MAIL'] : $_SERVER['REQUEST_URI'],
// 		'ICON'	=> 'btn_list',
// 	)
// );
// if ($ID && true)
// {
// 	$aMenu[] = array(
// 		'TEXT' => "На рассмотрение",
// 		'TITLE' => "Отправить кандидата на рассмотрение",
// 		'LINK' => $_SERVER['REQUEST_URI'],
// 		'ICON' => 'to-supervise',
// 	);
// }
// $context = new CAdminContextMenu($aMenu);


//view

// if ($_REQUEST['mode'] == 'list')
// {
// 	require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_js.php');
// }
// else
// {
// 	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php');
// }

define("START_EXEC_PROLOG_AFTER_1", microtime());
$GLOBALS["BX_STATE"] = "PA";

if(!defined("BX_ROOT"))
	define("BX_ROOT", "/bitrix");

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");

if (!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1)
{
	if (!defined('BX_AUTH_FORM') || !BX_AUTH_FORM)
		require_once($_SERVER["DOCUMENT_ROOT"]."/mail/prolog_main_admin.php");
		// require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_main_admin_custom.php");
	else
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_auth_admin.php");
}
else
	require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_jspopup_admin.php");

define("START_EXEC_PROLOG_AFTER_2", microtime());
$GLOBALS["BX_STATE"] = "WA";

// $context->Show();


if (!empty($errors))
{
	$bVarsFromForm = true;
	CAdminMessage::ShowMessage(join("\n", $errors));
}
else
{
	$bVarsFromForm = false;
}

$tabControl->BeginPrologContent();

echo $USER_FIELD_MANAGER->ShowScript();

echo CAdminCalendar::ShowScript();

$tabControl->EndPrologContent();
$tabControl->BeginEpilogContent();
?>

	<?=bitrix_sessid_post()?>
	<input type="hidden" name="ID" value="<?= htmlspecialcharsbx(!empty($row) ? $row['ID'] : '')?>">
	<input type="hidden" name="ENTITY_ID" value="<?= htmlspecialcharsbx($hlblock['ID'])?>">
	<input type="hidden" name="lang" value="<?= LANGUAGE_ID?>">
	<input type="hidden" name="action" value="<?= $action?>">

<?$tabControl->EndEpilogContent();?>

	<? $tabControl->Begin(array(
		'FORM_ACTION' => $APPLICATION->GetCurPage().'?ENTITY_ID='.$hlblock['ID'].'&ID='.IntVal($ID).'&lang='.LANG
	));?>

	<? $tabControl->BeginNextFormTab(); ?>

	<?
	$ufields = $USER_FIELD_MANAGER->GetUserFields('HLBLOCK_'.$hlblock['ID']);
	$hasSomeFields = !empty($ufields);

	if ($action != 'copy')
	{
		$tabControl->AddViewField('ID', 'ID', !empty($row) ? $row['ID'] : '');
	}
	//remove files for copy action
	elseif ($hasSomeFields && !empty($row))
	{
		foreach ($ufields as $ufCode => $ufField)
		{
			if (
				isset($ufField['USER_TYPE_ID']) && $ufField['USER_TYPE_ID'] == 'file' ||
				(
					isset($ufField['USER_TYPE']) && is_array($ufField['USER_TYPE']) &&
					isset($ufField['USER_TYPE']['BASE_TYPE']) && $ufField['USER_TYPE']['BASE_TYPE'] == 'file'
				)
			)
			{
				$row[$ufCode] = null;
			}
		}
	}

	// команда рендерит все пользовательские поля в форму
	echo $tabControl->ShowUserFieldsWithReadyData('HLBLOCK_'.$hlblock['ID'], $row, $bVarsFromForm, 'ID');
	// echo '<script type="text/javascript">console.log('.json_encode($row).');</script>';
	?>

	<?
	$disable = true;
	if($isEditMode)
		$disable = false;

	if ($hasSomeFields)
	{
		$tabControl->Buttons(array(
			'disabled' => $disable, 
			'back_url' => (!empty($_GET["mailId"])) ? $_COOKIE['PREVIOUS_PAGE_MAIL'] : $_SERVER['REQUEST_URI']
		));
	}
	else
	{
		$tabControl->Buttons(false);
	}


	$tabControl->Show();
	?>
</form>
<?
if ($ID == 0) {
	$linkId = $GLOBALS["USER"]->GetId();
} else {
	$linkUserDb = $entity_data_class::getList(array("select" => array("*"), "filter" => array("ID" => $ID)));
	$linkUserArray = $linkUserDb->Fetch();
	$arrFileUpload = unserialize($linkUserArray["UF_HR_UPLOADS"]);
	$supervisorId = $linkUserArray["UF_HR_SUPERVISOR"];
	$linkId = $linkUserArray["UF_HR_MAKER"];
	// AddMessage2Log("\$arrFileUpload<script>console.log(".json_encode($arrFileUpload).");</script><br>", '', 0);
}
$linkId = ($linkId) ? $linkId : 479;
$linkUser = CUser::GetByID($linkId)->Fetch();
$linkName = $linkUser["LAST_NAME"].' '.$linkUser["NAME"].' '.$linkUser["SECOND_NAME"];
if (empty($linkUser["LAST_NAME"])) $linkName = $linkUser["NAME"];
$linkTag = "<a href='/company/personal/user/$linkId/' target='_blank'>$linkName</a>";
// AddMessage2Log("\$linkName<script>console.log(".json_encode($linkName).");</script><br>", '', 0);
if (!empty($supervisorId)) {
	$supervisorUser = CUser::GetByID($supervisorId)->Fetch();
	$supervisorName = $supervisorUser["LAST_NAME"].' '.$supervisorUser["NAME"].' '.$supervisorUser["SECOND_NAME"];
	if (empty($supervisorUser["LAST_NAME"])) $supervisorName = $supervisorUser["NAME"];
	$supervisorTag = "<a href='/company/personal/user/$supervisorId/' target='_blank'>$supervisorName</a>";
}

if (!empty($_GET["mailId"])) {
	$letterId = $_GET["mailId"];
	$messageList = Bitrix\Mail\MailMessageTable::getList(array(
		'select' => array('ID', 'MAILBOX_ID', 'MAILBOX_NAME' => 'MAILBOX.NAME', 'NEW_MESSAGE', 'SUBJECT', 
				'MESSAGE_SIZE', 'SPAM', 'SPAM_RATING', 'FIELD_FROM', 'FIELD_REPLY_TO', 'FIELD_CC', 
				'FIELD_BCC', 'FIELD_DATE', 'DATE_INSERT', 'ATTACHMENTS', 'MSG_ID'),
		'filter' => array_filter(array('ID' => $_GET["mailId"]))
	));
	$fieldFrom = TxtToHTML($messageList->fetch()['FIELD_FROM']);
	$fieldFrom = explode('&lt;', $fieldFrom);
	$fieldMailFrom = str_replace('&gt;', '', $fieldFrom[1]);	
} else {
	if ($ID != 0) $letterId = $linkUserArray["UF_HR_LETTER_ID"];
}
if (!empty($letterId)) {
	Bitrix\Main\Loader::includeModule('mail');
	$dbr_attach = CMailAttachment::GetList(Array("NAME" => "ASC", "ID" => "ASC"), Array("MESSAGE_ID" => $letterId));
	unset($resumeFiles);
	while($dbr_attach_arr = $dbr_attach->GetNext()) {
		$attach_resume["FILE_SIZE"] = CFile::FormatSize($dbr_attach_arr["FILE_SIZE"]);		
		$attach_resume["HREF"] = "/bitrix/admin/mail_attachment_view.php?lang=ru&ID=".$dbr_attach_arr["ID"];
		$attach_resume["FILE_NAME"] = (empty($dbr_attach_arr["FILE_NAME"])) ? "Безымянный" : $dbr_attach_arr["FILE_NAME"];
		$resumeFiles[] = $attach_resume;
	}
}
if (!empty($arrFileUpload)) $resumeFiles[] = array(
	"FILE_SIZE" => CFile::FormatSize($arrFileUpload["size"]),
	"HREF" => "/upload/mail/hr/user_$ID/".$arrFileUpload["name"],
	"FILE_NAME" => $arrFileUpload["name"]
);
?>
<script type="text/javascript">
	$(document).ready(function () {	
		$('#edit1_edit_table tr > td > a').remove();
		var mailFrom = $(<?=json_encode($fieldMailFrom)?>).html();
		if (mailFrom) $('input[name="UF_EMAIL"]').attr('value', mailFrom);
		if (!mailFrom) $('a#btn_list, input[name="cancel"]').click(function(e) {
			e.preventDefault();
			if(parent.jQuery) parent.$(parent.document).find('span.side-panel-close').click();
		});
		$('input[name="save"]').click(function(e){
			var bName = $('input[name="UF_NAME"]').val();
			var bLastName = $('input[name="UF_LAST_NAME"]').val();
			var bEmail = $('input[name="UF_EMAIL"]').val();
			bEmail = /^([a-zA-Z0-9_-]+\.)*[a-zA-Z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,9}$/.test(bEmail);
			var bMobile = $('input[name="UF_PERSONAL_MOBILE"]').val();
			bMobile1 = /^((\+7)|d{1})(\(\_{3}\))(_{3})(\-_{2})(\-_{2})$/.test(bMobile);
			bMobile2 = /^((\+7)|d{1})(\(\d{3}\))(\d{3})(\-\d{2})(\-\d{2})$/.test(bMobile);
			bMobile = bMobile1 || bMobile2;
			var bMessage = "Пожалуйста введите данные правильно.";
			if (bName && bLastName && bEmail && bMobile) {
				if (bMobile1) BX('ph-number').value = 'нет';
				// console.log(banner);
			} else {
				e.preventDefault();
				if (!bName || !bLastName || !bEmail) bMessage = bMessage + " Поля со звёздочкой обязательны для заполнения.";
				if (!bName) bMessage = bMessage + " Имя кандидата не заполнено.";
				if (!bLastName) bMessage = bMessage + " Фамилия кандидата не заполнена.";
				if (!bEmail) bMessage = bMessage + " Адрес E-mail необходимо вводить в соответствии с форматом, представленным в пустом поле.";
				if (!bMobile) bMessage = bMessage + " Номер мобильного телефона необходимо вводить в соответствии с заданным форматом. Поле должно быть пустым, если номер отсутствует.";
				alert(bMessage);
				// console.log(bMobile);
				setTimeout(function() {
					BX.adminPanel.closeWait(this);				
				}, 500);
			}
		});
		$('input[name="apply"]').attr({'value': 'На рассмотрение', 'title': 'Отправить кандидата на рассмотрение'}).click(function(){
			$("#hlrow_edit_8_form").append('<input type="hidden" name="METHOD" value="@UPDATE">');
		});
		$('#hlrow_edit_8_form').submit(function(){
			parent.$(parent.document).find('span.side-panel-close').click();
			parent.$(parent.document).trigger('refresh');
		});
		
		var linkId = <?=json_encode($linkId)?>;
		var linkTag = <?=json_encode($linkTag)?>;
		var supervisorId = <?=json_encode($supervisorId)?>;
		var supervisorTag = <?=json_encode($supervisorTag)?>;	
		var candidatId = <?=json_encode($ID)?>;
		var letterId = <?=json_encode($letterId)?>;
		var resumes = <?=json_encode($resumeFiles)?>;
		var currentUser = <?=json_encode($currentUser)?>;

		if (!currentUser) $('input[name="save"]').attr('disabled', '');
		$('input[name="UF_HR_UPLOADS"]').parent().parent().css('display', 'none');
		$('input[name="UF_HR_LETTER_ID"]').attr('value', letterId).parent().parent().css('display', 'none');
		$('input[name="UF_TIMESTAMP_X"]').parent().parent().parent().css('display', 'none');
		$('input[name="UF_DATE_REGISTER"]').parent().parent().parent().css('display', 'none');
		$('select[name="UF_HR_POSITION"]').parent().parent().css('display', 'none');

		if (supervisorId) $('input[name="UF_HR_SUPERVISOR"]').attr('type', 'hidden').attr('value', supervisorId).before(supervisorTag);
		else $('input[name="UF_HR_SUPERVISOR"]').parent().parent().css('display', 'none');

		if (!candidatId) {			
			$('input[name="UF_HR_ALLOTMENT"]').parent().parent().parent().css('display', 'none');
			$('select[name="UF_HR_STATUS"]').parent().parent().css('display', 'none');
		}
		if (!candidatId || ($('select[name="UF_HR_STATUS"]').val() == '81')) $('input[name="apply"]').css('display', 'none');
		
		$('input[name="UF_NAME"]').parent().parent().find('.adm-detail-content-cell-l').html('Имя<font color="red">*</font>:');
		$('input[name="UF_LAST_NAME"]').parent().parent().find('.adm-detail-content-cell-l').html('Фамилия<font color="red">*</font>:');
		$('input[name="UF_EMAIL"]').parent().parent().find('.adm-detail-content-cell-l').html('Электронная почта<font color="red">*</font>:');		
		$('input[name="UF_EMAIL"]').attr({'placeholder': 'nick@fsfk.local'});
		$('input[name="UF_PERSONAL_MOBILE"]').attr({'id': 'ph-number', 'placeholder': '+7(9__)___-__-__'});
		setTimeout(function() {
			var phResult = new BX.MaskedInput({
				mask: '+7(999)999-99-99', // устанавливаем маску
				input: BX('ph-number'),
				placeholder: '_' // символ замены +7 ___ ___ __ __
			});
			// console.log(BX('ph-number').value);
			if ((BX('ph-number').value == '+7(___)___-__-__') || !BX('ph-number').value) phResult.setValue('9'); // устанавливаем значение
		}, 100);


		$('input[name="UF_HR_MAKER"]').attr('type', 'hidden').attr('value', linkId).before(linkTag);
		$('input[name="UF_UPLOAD_FILE"]').attr('type', 'file').css('margin', '1px 0px 9px 0px');
		$('input[name="UF_UPLOAD_FILE"]').parent().parent().find('.adm-detail-content-cell-l').css({'vertical-align': 'top', 'padding-top': '9px'});
		
		// console.log(letterId);
		if (resumes) {
			// console.log(resumes);
			var resumeFiles = '';
			resumes.forEach(function(item, i, arr) {
				resumeFiles = resumeFiles + '<br><a href="' + item.HREF + '" download>' + item.FILE_NAME + '</a> (' + item.FILE_SIZE + ')';
			});
			$('input[name="UF_UPLOAD_FILE"]').parent().append(resumeFiles);
		}
	});
</script>
<?
if ($_REQUEST['mode'] == 'list') require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin_js.php');
else require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php');
