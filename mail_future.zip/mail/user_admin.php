<?
/**
 * Bitrix Framework
 * @package bitrix
 * @subpackage main
 * @copyright 2001-2013 Bitrix
 */

/**
 * Bitrix vars
 * @global CUser $USER
 * @global CMain $APPLICATION
 * @global CDatabase $DB
 * @global CUserTypeManager $USER_FIELD_MANAGER
 * @global string $by
 * @global string $order
 */
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/bx_root.php");

define("START_EXEC_PROLOG_BEFORE_1", microtime());
$GLOBALS["BX_STATE"] = "PB";
unset($_REQUEST["BX_STATE"]);
unset($_GET["BX_STATE"]);
unset($_POST["BX_STATE"]);
unset($_COOKIE["BX_STATE"]);
unset($_FILES["BX_STATE"]);

define("NEED_AUTH", false);
define("ADMIN_SECTION", false);

if (isset($_REQUEST['bxpublic']) && $_REQUEST['bxpublic'] == 'Y' && !defined('BX_PUBLIC_MODE'))
	define('BX_PUBLIC_MODE', 1);

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include.php");
if(!headers_sent())
	header("Content-type: text/html; charset=".LANG_CHARSET);

if (defined('BX_PUBLIC_MODE') && BX_PUBLIC_MODE == 1)
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST')
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_jspopup.php");
}

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/admin_tools.php");
require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mail/prolog.php");

CMain::PrologActions();
define("HELP_FILE", "users/user_admin.php");
$entity_id = "USER";

$currentUserArr = CUser::GetUserGroup($GLOBALS["USER"]->GetId());
$currentUser = $GLOBALS["USER"]->IsAdmin() || in_array("47", $currentUserArr);

if (!(($_GET["grid_id"] == "tbl_user1") || ($_REQUEST["mode"] == 'excel'))) {
	$currentPath = str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);
	$APPLICATION->SetAdditionalCSS($currentPath."/jsgrid/jsgrid.min.css", true);
	$APPLICATION->SetAdditionalCSS($currentPath."/jsgrid/jsgrid-theme.min.css", true);
	$APPLICATION->SetAdditionalCSS($currentPath."/jsgrid/bootstrap.min.css", true);
	$APPLICATION->AddHeadScript($currentPath."/jsgrid/bootstrap.min.js", true);
	$APPLICATION->AddHeadScript($currentPath."/jsgrid/jsgrid.min.js", true);
	$APPLICATION->AddHeadScript($currentPath."/jsgrid/i18n/jsgrid-ru.js", true);

?>
<style>
	* {
		box-sizing: unset;
		border-collapse: unset;
	}
	#adm-workarea {
		padding: 5px 0;
	}
	.webform-button-icon {
		margin: -3.5px 2px 0 0 !important;
	}
	.webform-small-button {
		height: 39px !important;
		line-height: 39px !important;
	}
	.adm-toolbar-panel-flexible-space {
		margin: 0 33px 0 0 !important;
		/* flex: none !important;
		width: calc(100% - 290px); */
	}
	.adm-toolbar-panel-align-right {
		margin-right: <?=($currentUser) ? '20px' : '33px';?>;
	}
	.adm-toolbar-panel-container .main-ui-filter-search {
		max-width: none !important;
	}
	.adm-workarea-wrap.adm-workarea-wrap-top {
		background: #eef2f4;
	}
	.modal-dialog.modal-dialog-centered {
		max-width: 700px !important;
	}
	#userlink {
		display: none;
	}
	/* .main-grid-settings-window-list > .main-grid-settings-window-list-item:last-child {
		display: none;
	} */
</style>
<?
}
// if(!($USER->CanDoOperation('view_subordinate_users') || $USER->CanDoOperation('view_all_users') || $USER->CanDoOperation('edit_all_users') || $USER->CanDoOperation('edit_subordinate_users')))
// 	$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));

use Bitrix\Main\UserTable;
use Bitrix\Main\UserGroupTable;
use Bitrix\Main\Entity\Query;
use Bitrix\Main\DB\SqlExpression;
use Bitrix\Main\Entity\ExpressionField;
use Bitrix\Main\UI\PageNavigation;
use Bitrix\Main\Text\HtmlFilter;
use Bitrix\Main\Type\DateTime;

use Bitrix\Main\Loader; 

Loader::includeModule("highloadblock"); 

use Bitrix\Highloadblock as HL; 
use Bitrix\Main\Entity;

$hlbl = 8; // Указываем ID нашего highload-блока к которому будет делать запросы.
$hlblock8 = HL\HighloadBlockTable::getById($hlbl)->fetch(); 

$entity8 = HL\HighloadBlockTable::compileEntity($hlblock8); 
$entity_data_class = $entity8->getDataClass(); 

IncludeModuleLangFile(__FILE__);

//authorize as user
// if($_REQUEST["action"] == "authorize" && check_bitrix_sessid() && $USER->CanDoOperation('edit_php'))
// {
// 	$USER->Logout();
// 	$USER->Authorize(intval($_REQUEST["ID"]));
// 	LocalRedirect("user_admin.php?lang=".LANGUAGE_ID);
// }

$sTableID = "tbl_user1";

$oSort = new CAdminSorting($sTableID, "TIMESTAMP_X", "desc");
$lAdmin = new CAdminUiList($sTableID, $oSort);

$bIntranetEdition = IsModuleInstalled("intranet");//(defined("INTRANET_EDITION") && INTRANET_EDITION == "Y");

$arFilterFields = Array(
	"find",
	"find_type",
	"find_id",
	"find_timestamp_1",
	"find_timestamp_2",
	"find_last_login_1",
	"find_last_login_2",
	"find_active",
	"find_login",
	"find_name",
	"find_email",
	"find_keywords",
	"find_group_id"
);
if ($bIntranetEdition) $arFilterFields[] = "find_intranet_users";

$USER_FIELD_MANAGER->AdminListAddFilterFields($entity_id, $arFilterFields);

$lAdmin->InitFilter($arFilterFields);

function CheckFilter($FilterArr)
{
	global $strError;
	foreach($FilterArr as $f)
		global ${$f};

	$str = "";
	if(strlen(trim($find_timestamp_1))>0 || strlen(trim($find_timestamp_2))>0)
	{
		$date_1_ok = false;
		$date1_stm = MkDateTime(FmtDate($find_timestamp_1,"D.M.Y"),"d.m.Y");
		$date2_stm = MkDateTime(FmtDate($find_timestamp_2,"D.M.Y")." 23:59","d.m.Y H:i");
		if (!$date1_stm && strlen(trim($find_timestamp_1))>0)
			$str.= GetMessage("MAIN_WRONG_TIMESTAMP_FROM")."<br>";
		else $date_1_ok = true;
		if (!$date2_stm && strlen(trim($find_timestamp_2))>0)
			$str.= GetMessage("MAIN_WRONG_TIMESTAMP_TILL")."<br>";
		elseif ($date_1_ok && $date2_stm <= $date1_stm && strlen($date2_stm)>0)
			$str.= GetMessage("MAIN_FROM_TILL_TIMESTAMP")."<br>";
	}

	if(strlen(trim($find_last_login_1))>0 || strlen(trim($find_last_login_2))>0)
	{
		$date_1_ok = false;
		$date1_stm = MkDateTime(FmtDate($find_last_login_1,"D.M.Y"),"d.m.Y");
		$date2_stm = MkDateTime(FmtDate($find_last_login_2,"D.M.Y")." 23:59","d.m.Y H:i");
		if(!$date1_stm && strlen(trim($find_last_login_1))>0)
			$str.= GetMessage("MAIN_WRONG_LAST_LOGIN_FROM")."<br>";
		else
			$date_1_ok = true;
		if(!$date2_stm && strlen(trim($find_last_login_2))>0)
			$str.= GetMessage("MAIN_WRONG_LAST_LOGIN_TILL")."<br>";
		elseif($date_1_ok && $date2_stm <= $date1_stm && strlen($date2_stm)>0)
			$str.= GetMessage("MAIN_FROM_TILL_LAST_LOGIN")."<br>";
	}

	$strError .= $str;
	if(strlen($str)>0)
	{
		global $lAdmin;
		$lAdmin->AddFilterError($str);
		return false;
	}

	return true;
}

$arFilter = Array();
if(CheckFilter($arFilterFields))
{
	$arFilter = Array(
		"ID" => $find_id,
		"TIMESTAMP_1" => $find_timestamp_1,
		"TIMESTAMP_2" => $find_timestamp_2,
		"LAST_LOGIN_1" => $find_last_login_1,
		"LAST_LOGIN_2" => $find_last_login_2,
		"ACTIVE" => $find_active,
		"LOGIN" => ($find!='' && $find_type == "login"? $find: $find_login),
		"NAME" => ($find!='' && $find_type == "name"? $find: $find_name),
		"EMAIL" => ($find!='' && $find_type == "email"? $find: $find_email),
		"KEYWORDS" => $find_keywords,
		"GROUPS_ID" => $find_group_id
		);
	if ($bIntranetEdition)
		$arFilter["INTRANET_USERS"] = $find_intranet_users;
	$USER_FIELD_MANAGER->AdminListAddFilter($entity_id, $arFilter);
}

/* Prepare data for new filter */
$queryObject = CGroup::GetDropDownList("AND ID!=2");
// $listGroup = array();
// while($group = $queryObject->fetch()) $listGroup[$group["REFERENCE_ID"]] = $group["REFERENCE"];

$obEnum = new \CUserFieldEnum; 
$rsEnum = $obEnum->GetList(array(), array("USER_FIELD_ID" => 311));
$enumValue = $sGr = $listGroup = $infoList = array();
while ($arEnum = $rsEnum->Fetch()){
	$enumValue[] = $arEnum;
	$sGr[] = array("NAME" => $arEnum["VALUE"], "VALUE" => intval($arEnum["ID"]));
	$listGroup[intval($arEnum["ID"])] = $arEnum["VALUE"];
	$infoList[] = array("Номер" => $arEnum["ID"], "Название" => $arEnum["VALUE"], "Сортировка" => $arEnum["SORT"]);
}
// echo '<script type="text/javascript">console.log('.json_encode($infoList).');</script>';

// $listGroup1 = array(75 => "младшая", 76 => "старшая", 77 => "ведущая", 78 => "главная", 79 => "высшая");
$listGroup2 = array(80 => "баллотируется", 81 => "на рассмотрении", 83 => "принят(а)");
// echo '<script type="text/javascript">console.log('.json_encode($listGroup2).');</script>';

$filterFields = array(
	array(
		"id" => "ID",
		"name" => GetMessage("MAIN_USER_ADMIN_FIELD_ID"),
		"filterable" => "",
		"default" => false
	),
	array(
		"id" => "UF_NAME",
		"name" => GetMessage("NAME"),
		"filterable" => "",
		"default" => true
	),
	array(
		"id" => "UF_LAST_NAME",
		"name" => GetMessage("LAST_NAME"),
		"filterable" => "",
		"default" => true
	),
	array(
		"id" => "UF_SECOND_NAME",
		"name" => GetMessage("SECOND_NAME"),
		"filterable" => "",
		"default" => true
	),	
	array(
		"id" => "UF_EMAIL",
		"name" => GetMessage("MAIN_F_EMAIL"),
		"filterable" => "%",
		"default" => true
	),	
	array(
		"id" => "UF_PERSONAL_MOBILE",
		"name" => GetMessage("PERSONAL_MOBILE"),
		"filterable" => "",
		"default" => true
	),	
	array(
		"id" => "UF_PERSONAL_BIRTHDAY",
		"name" => GetMessage("PERSONAL_BIRTHDAY"),
		"type" => "date",
		"default" => false
	),
	array(
		"id" => "UF_DATE_REGISTER",
		"name" => GetMessage("MAIN_FLT_REG_DATE"),
		"type" => "date",
		"default" => false
	),
	array(
		"id" => "UF_TIMESTAMP_X",
		"name" => GetMessage("MAIN_F_TIMESTAMP"),
		"type" => "date",
		"default" => false
	),
	array(
		"id" => "UF_HR_ALLOTMENT",
		"name" => "Дата рассмотрения",
		"type" => "date",
		"default" => false
	),
	array(
		"id" => "UF_HR_RESERV",
		"name" => GetMessage("UF_HR_RESERV"),
		"type" => "list",
		"items" => array(
			"Y" => GetMessage("MAIN_YES"),
			"N" => GetMessage("MAIN_NO")
		),
		"filterable" => ""
	),
	array(
		"id" => "UF_CIVIL_SERVICE",
		"name" => GetMessage("UF_CIVIL_SERVICE"),
		"type" => "list",
		"items" => array(
			"Y" => GetMessage("MAIN_YES"),
			"N" => GetMessage("MAIN_NO")
		),
		"filterable" => ""
	),
	array(
		"id" => "UF_HR_CATEGORY",
		"name" => GetMessage("F_GROUP"),
		"type" => "list",
		"items" => $listGroup,
		"params" => array("multiple" => "Y"),
		"filterable" => ""
	),
	// array(
	// 	"id" => "UF_HR_POSITION",
	// 	"name" => GetMessage("F_GROUP1"),
	// 	"type" => "list",
	// 	"items" => $listGroup1,
	// 	"params" => array("multiple" => "N"),
	// 	"filterable" => ""
	// ),
	array(
		"id" => "UF_HR_STATUS",
		"name" => GetMessage("F_GROUP2"),
		"type" => "list",
		"items" => $listGroup2,
		"params" => array("multiple" => "N"),
		"filterable" => ""
	),
	array(
		"id" => "UF_HR_EXPERIENCE",
		"name" => GetMessage("UF_HR_EXPERIENCE"),
		"filterable" => "%",
	),
);
if ($bIntranetEdition && false)
{
	$filterFields[] = array(
		"id" => "INTRANET_USERS",
		"name" => GetMessage("F_FIND_INTRANET_USERS"),
		"type" => "list",
		"items" => array(
			"" => GetMessage("MAIN_ALL"),
			"Y" => GetMessage("MAIN_YES")
		),
		"filterable" => ""
	);
}
// $USER_FIELD_MANAGER->AdminListAddFilterFieldsV2($entity_id, $filterFields);
$arFilter = (empty($GLOBALS["HR_FILTRATION"])) ? array() : $GLOBALS["HR_FILTRATION"];
$lAdmin->AddFilter($filterFields, $arFilter);

$USER_FIELD_MANAGER->AdminListAddFilterV2($entity_id, $arFilter, $sTableID, $filterFields);

$arUserSubordinateGroups = array();
if(!$USER->CanDoOperation('edit_all_users') && !$USER->CanDoOperation('view_all_users'))
{
	$arUserGroups = CUser::GetUserGroup($USER->GetID());
	for ($j = 0, $len = count($arUserGroups); $j < $len; $j++)
	{
		$arSubordinateGroups = CGroup::GetSubordinateGroups($arUserGroups[$j]);
		$arUserSubordinateGroups = array_merge ($arUserSubordinateGroups, $arSubordinateGroups);
	}
	$arUserSubordinateGroups = array_unique($arUserSubordinateGroups);

	$arFilter["CHECK_SUBORDINATE"] = $arUserSubordinateGroups;

	if($USER->CanDoOperation('edit_own_profile'))
		$arFilter["CHECK_SUBORDINATE_AND_OWN"] = $USER->GetID();
}

if($lAdmin->EditAction())
{	
	$editableFields = array(
		"NAME" => 1, "LAST_NAME" => 1, "SECOND_NAME" => 1, "EMAIL" => 1, "PERSONAL_MOBILE" => 1, "PERSONAL_BIRTHDAY" => 1,
		"UF_HR_RESERV" => 2, "UF_CIVIL_SERVICE" => 2, "UF_HR_ALLOTMENT" => 2, 
		"UF_HR_STATUS" => 2, "UF_HR_CATEGORY" => 2, "UF_HR_EXPERIENCE" => 2, // "UF_HR_POSITION" => 2, 
		// "PERSONAL_WWW"=>1, "PERSONAL_ICQ"=>1, "PERSONAL_GENDER"=>1, "PERSONAL_PHONE"=>1, 
		// "PERSONAL_CITY"=>1, "PERSONAL_STREET"=>1, "WORK_COMPANY"=>1, "WORK_DEPARTMENT"=>1, "WORK_POSITION"=>1,
		// "WORK_WWW"=>1, "WORK_PHONE"=>1, "WORK_CITY"=>1, "XML_ID"=>1, "ACTIVE"=>1, "LOGIN"=>1, "TITLE"=>1, 
	);

	foreach($_POST["FIELDS"] as $ID => $arFields)
	{
		$ID = intval($ID);
		AddMessage2Log("field$ID<script>console.log(".json_encode($arFields).");</script><br>", '', 0);
		
		$arrFieldsUf = array();
		foreach($arFields as $key => $field) {
			if($editableFields[$key] === 1) $arrFieldsUf['UF_'.$key] = $field;
			if($editableFields[$key] === 2) $arrFieldsUf[$key] = $field;
		}
		$arrFieldsUf["UF_TIMESTAMP_X"] = date('d.m.Y H:i:s');
		$entity_data_class::update($ID, $arrFieldsUf);		
	}
}

if(($arID = $lAdmin->GroupAction()) && ($USER->CanDoOperation('edit_all_users') || $USER->CanDoOperation('edit_subordinate_users')) || true)
{

	$gr_id = intval($_REQUEST['groups']);
	$struct_id = intval($_REQUEST['UF_DEPARTMENT']);

	foreach($arID as $ID)
	{
		$ID = intval($ID);
		if($ID < 1) continue;


		switch($_REQUEST['action'])
		{
			case "delete":
				$entity_data_class::Delete($ID);
				break;
			case "to_categories":
				$entity_data_class::update($ID, array("UF_HR_STATUS" => 80));
				break;
			case "to_consider":
				$ajaxFields["UF_HR_STATUS"] = 81;				
				$ajaxFields["UF_HR_SUPERVISOR"] = $GLOBALS["USER"]->GetId();
				if (IsModuleInstalled("im") && CModule::IncludeModule("im")) {
					$ajaxFields["UF_HR_ALLOTMENT"] = date('d.m.Y', time());
					// $fromSender = (CUser::GetByID($GLOBALS["USER"]->GetID()))->Fetch()["EMAIL"];
					// $lettersHeader = "Федеральное казначейство";
					// $protocolHeaders  = 'MIME-Version: 1.0' . "\r\n";
					// $protocolHeaders .= 'Content-type: text/html; charset=utf-8' . "\r\n";
					// $protocolHeaders .= "From: <".$fromSender.">\r\n";
					$entityFields = $entity_data_class::getList(array("select" => array("*"), "filter" => array("ID" => $ID)));
					$arrFields = $entityFields->Fetch();
					$candidatName = $arrFields["UF_LAST_NAME"].' '.$arrFields["UF_NAME"].' '.$arrFields["UF_SECOND_NAME"];
					if (empty($arrFields["UF_LAST_NAME"])) $candidatName = $arrFields["UF_NAME"];
					$notifyMessageOut = "$candidatName претендует на замещение вакантной должности.";
					$notifyMessageOut .= ' Дата рассмотрения заявки отделом кадров: '.$ajaxFields["UF_HR_ALLOTMENT"].'.';
					$arMessageFieldsToChat = array(
						// получатель
					"TO_USER_ID" => '1',
					// отправитель
					"FROM_USER_ID" => $GLOBALS["USER"]->GetID(), 
					// тип уведомления
					"NOTIFY_TYPE" => IM_NOTIFY_FROM, 
					// модуль запросивший отправку уведомления
					"NOTIFY_MODULE" => "calendar",
					// текст уведомления на сайте
					"NOTIFY_MESSAGE" => $notifyMessageOut, 
					// текст уведомления для отправки на почту (или XMPP), если различий нет - не задаем параметр
					"NOTIFY_MESSAGE_OUT" => $notifyMessageOut 
					);
					$dataGroups1 = CUser::GetList(($by="ID"), ($order="ASC"), array('GROUPS_ID' => array(47), 'ACTIVE' => 'Y'));
					while($arUserGroups = $dataGroups1->Fetch()) {
						$arMessageFieldsToChat["TO_USER_ID"] = $arUserGroups['ID'];
						CIMNotify::Add($arMessageFieldsToChat);
						// mail($arUserGroups["EMAIL"], $lettersHeader, $notifyMessageOut, $protocolHeaders);
					}
				}				
				$entity_data_class::update($ID, $ajaxFields);
				break;
			case "to_taken":
				$entity_data_class::update($ID, array("UF_HR_STATUS" => 83));
				break;
			case "to_archive":
				$entity_data_class::update($ID, array("UF_HR_STATUS" => null));
				break;
			case "activate":
				$entity_data_class::update($ID, array("UF_HR_RESERV" => null));
				// AddMessage2Log("activate<script>console.log(".json_encode($ID).");</script><br>", '', 0);
				break;
			case "deactivate":
				$entity_data_class::update($ID, array("UF_HR_RESERV" => 1));
				// AddMessage2Log("deactivate<script>console.log(".json_encode($ID).");</script><br>", '', 0);
				break;
			case "add_group":				
				$entity_data_class::update($ID, array(
					"UF_TIMESTAMP_X" => date('d.m.Y H:i:s'),
					"UF_HR_STATUS" => 80,
					"UF_HR_CATEGORY" => array($gr_id),
				));
				// AddMessage2Log("$ID<script>console.log(".json_encode($gr_id).");</script><br>", '', 0);
				break;
			case "intranet_deactivate":
				// $ob = new CUser();
				// $arFields = Array("LAST_LOGIN"=>false);
				// if(!$ob->Update($ID, $arFields))
				// 	$lAdmin->AddGroupError(GetMessage("MAIN_EDIT_ERROR").$ob->LAST_ERROR, $ID);
				break;
		}
	}
}

setHeaderColumn($lAdmin);

$nav = new PageNavigation("pages-user-admin");
$nav->setPageSize($lAdmin->getNavSize());
$nav->initFromUri();
$listSelectFields = $lAdmin->getVisibleHeaderColumns();
if (!in_array("ID", $listSelectFields)) $listSelectFields[] = "ID";

$listRatingColumn = preg_grep('/^RATING_(\d+)$/i', $listSelectFields);
if (!empty($listRatingColumn)) $listSelectFields = array_diff($listSelectFields, $listRatingColumn);

$sortBy = strtoupper($by);
if(!UserTable::getEntity()->hasField($sortBy))
{
	$sortBy = "TIMESTAMP_X";
}
$sortOrder = strtoupper($order);
if($sortOrder <> "DESC" && $sortOrder <> "ASC")
{
	$sortOrder = "DESC";
}

$filterOption = new Bitrix\Main\UI\Filter\Options($sTableID);
$filterData = $filterOption->getFilter($filterFields);
// echo '<script type="text/javascript">console.log('.json_encode($filterData).');</script>';
if ($filterData["FILTER_APPLIED"]) $findValue = strtolower(trim($filterData["FIND"]));

// echo '<script type="text/javascript">console.log('.json_encode($arFilter).');</script>';

// автоматическое снятие с рассмотрения кандидатов через месяц
$userStatusDb = $entity_data_class::getList(array(
	"select" => array("ID", "UF_HR_STATUS", "UF_HR_ALLOTMENT"),
	"filter" => array("UF_HR_STATUS" => "81", "<UF_HR_ALLOTMENT" => date('d.m.Y', (time() - (60*60*24*30)))),
	"order" => array("ID" => "ASC"),
)); 
while($userStatus = $userStatusDb->Fetch()){
	$entity_data_class::update($userStatus["ID"], array("UF_HR_STATUS" => "80"));
}

// согласование сущностей шаблона и модели
$fieldsWithoutUF = array(
	'NAME', 'LAST_NAME', 'SECOND_NAME', 'EMAIL', 'PERSONAL_BIRTHDAY', 'PERSONAL_MOBILE', 'TIMESTAMP_X', 'DATE_REGISTER'
);
$allFieldsFromEntity = array(
	'ID', 'NAME', 'LAST_NAME', 'SECOND_NAME', 'EMAIL', '%UF_EMAIL', 'PERSONAL_BIRTHDAY', '<=PERSONAL_BIRTHDAY', 
	'>=PERSONAL_BIRTHDAY', 'PERSONAL_MOBILE', 'TIMESTAMP_X', '>UF_TIMESTAMP_X', '>=UF_TIMESTAMP_X', '<=UF_TIMESTAMP_X', 
	'DATE_REGISTER', '<=UF_DATE_REGISTER', '>=UF_DATE_REGISTER', 'UF_HR_RESERV', '=UF_HR_RESERV', 
	'UF_CIVIL_SERVICE', // 'UF_HR_POSITION', '=UF_HR_POSITION', 
	'UF_HR_MAKER', 'UF_HR_STATUS', '=UF_HR_STATUS', 'UF_HR_ALLOTMENT', '<=UF_HR_ALLOTMENT', '>=UF_HR_ALLOTMENT', 
	'UF_HR_CATEGORY', '=UF_HR_CATEGORY', 'UF_HR_UPLOADS', 'UF_HR_LETTER_ID', 'UF_HR_EXPERIENCE', '%UF_HR_EXPERIENCE'
);

// $entity_data_class::update(42, array("UF_TIMESTAMP_X" => '04.08.2019 08:18:49'));
// $entity_data_class::update(47, array("UF_TIMESTAMP_X" => '25.11.2019 09:23:59'));
// $entity_data_class::update(15, array("UF_TIMESTAMP_X" => '16.12.2019 12:23:58'));
// $entity_data_class::update(13, array("UF_HR_ALLOTMENT" => '14.08.2020'));
// $entity_data_class::update(22, array("UF_HR_ALLOTMENT" => '25.12.2019'));

$listSelectFields8 = array();
foreach($listSelectFields as $value83) {
	if (in_array($value83, $allFieldsFromEntity)) {
		if (in_array($value83, $fieldsWithoutUF)) $listSelectFields8[] =  'UF_'.$value83;
		else $listSelectFields8[] =  $value83;
	}
}
$arFilter8 = array();
foreach($arFilter as $key84 => $value84) {
	if (in_array($key84, $allFieldsFromEntity) || 
		in_array(str_replace('UF_', '', $key84), $allFieldsFromEntity)) {
		if (in_array($key84, $fieldsWithoutUF)) $arFilter8['UF_'.$key84] =  $value84;
		else $arFilter8[$key84] =  $value84;
	}
	if ($key84 == 'UF_CIVIL_SERVICE') $arFilter8[$key84] = ($value84 == 'Y') ? 1 : null;
}
// echo '<script type="text/javascript">console.log('.json_encode($arFilter8).');</script>';
if (in_array($sortBy, $allFieldsFromEntity)) {
	$sortBy8 = (in_array($sortBy, $fieldsWithoutUF)) ? 'UF_'.$sortBy : $sortBy;
}

$rsData8 = $entity_data_class::getList(array(
   "select" => $listSelectFields8,
   "filter" => $arFilter8,
   "order" => array($sortBy8 => $sortOrder),
));

while($arData8 = $rsData8->Fetch()){
	foreach($arData8 as $key8 => $value8) {
		$banner8 = true;
		foreach($fieldsWithoutUF as $key81) {
			if ($key8 == ('UF_'.$key81)) {
				$arData81[$key81] = $value8;
				$banner8 = false;
			} 			
		}
		if ($banner8) $arData81[$key8] = $value8;
	}
	$arrayData[] = $arData81;
}
if (!empty($findValue)) $arrayData = array_filter($arrayData, function ($dataFields) use ($findValue) {
	if (ctype_digit($findValue)) {
		return ($dataFields["ID"] == $findValue);
    } else {
		$fitness = ($findValue == strtolower($dataFields["LAST_NAME"].' '.$dataFields["NAME"])) || 
		($findValue == strtolower($dataFields["LAST_NAME"].' '.$dataFields["NAME"].' '.$dataFields["SECOND_NAME"]));
		$pos1 = strpos(strtolower(trim($dataFields["NAME"])), $findValue);
		$pos2 = strpos(strtolower(trim($dataFields["LAST_NAME"])), $findValue);
		$pos3 = strpos(strtolower(trim($dataFields["SECOND_NAME"])), $findValue);
		$pos4 = strpos(strtolower(trim($dataFields["EMAIL"])), $findValue);
		$pos5 = strpos(strtolower(trim($dataFields["PERSONAL_MOBILE"])), $findValue);
		return ($fitness || ($pos1 !== false) || ($pos2 !== false) || ($pos3 !== false) || ($pos4 !== false) || ($pos5 !== false));
	}
});
// echo '<script type="text/javascript">console.log('.json_encode($arrayData).');</script>';

// создадим объект класса CDBResult
$result = new CDBResult;
// инициализируем этот объект исходным массивом
$result->InitFromArray($arrayData);
$listOffset = $nav->getOffset();
$listCount = $nav->getLimit();
$listNumber = ($listOffset/$listCount) + 1;
$result->NavStart($listCount, true, $listNumber);

//---------------------------------------------------

// $nav->setRecordCount($result->getCount());
$nav->setRecordCount($result->SelectedRowsCount());
$lAdmin->setNavigation($nav, GetMessage("MAIN_USER_ADMIN_PAGES"), false);

while ($userData = $result->fetch())
{
	$userId = $userData["ID"];
	$row =& $lAdmin->addRow($userId, $userData);
	$USER_FIELD_MANAGER->addUserFields("HLBLOCK_8", $userData, $row);
	$row->addViewField("ID", "<a onclick='window.openAccountNow(".
		$userId.")' title='".GetMessage("MAIN_EDIT_TITLE")."'>".$userId."</a>");
	
	$can_edit = $own_edit = $edit = true;
	// if ($userId == 1 || $own_edit || !$can_edit) $row->addCheckField("ACTIVE", false);
	// else $row->addCheckField("ACTIVE");

	if ($can_edit && $edit)
	{
		// $row->addField("LOGIN", "<a onclick='window.openAccountNow(".$userId.
		// 	")' title='".GetMessage("MAIN_EDIT_TITLE")."'>".HtmlFilter::encode($userData["LOGIN"])."</a>", true);
		// $row->addInputField("TITLE");
		$row->addInputField("NAME");
		$row->addInputField("LAST_NAME");
		$row->addInputField("SECOND_NAME");
		$row->addInputField("EMAIL");
		$row->addInputField("PERSONAL_MOBILE");
		$row->AddCalendarField("PERSONAL_BIRTHDAY");
		$row->AddCalendarField("UF_HR_ALLOTMENT");
		$row->addViewField("EMAIL", TxtToHtml($userData["EMAIL"]));
		$row->addViewField("UF_HR_CATEGORY", empty($userData["UF_HR_CATEGORY"]) ? "нет" : $listGroup[$userData["UF_HR_CATEGORY"][0]]);
		$row->addViewField("UF_HR_STATUS", empty($userData["UF_HR_STATUS"]) ? "нет" : $listGroup2[$userData["UF_HR_STATUS"]]);
		// $row->addViewField("UF_HR_POSITION", empty($userData["UF_HR_POSITION"]) ? "нет" : $listGroup1[$userData["UF_HR_POSITION"]]);
		// $row->addViewField("UF_HR_RESERV", empty($userData["UF_HR_RESERV"]) ? "нет" : "да");

		// $row->addInputField("PERSONAL_PROFESSION");
		// $row->addViewField("PERSONAL_WWW", TxtToHtml($userData["PERSONAL_WWW"]));
		// $row->addInputField("PERSONAL_WWW");
		// $row->addInputField("PERSONAL_ICQ");
		// $row->addSelectField("PERSONAL_GENDER", array("" => GetMessage("USER_DONT_KNOW"),
		// 	"M" => GetMessage("USER_MALE"), "F" => GetMessage("USER_FEMALE")));
		// $row->addInputField("PERSONAL_PHONE");
		// $row->addInputField("PERSONAL_CITY");
		// $row->addInputField("PERSONAL_STREET");
		// $row->addInputField("WORK_COMPANY");
		// $row->addInputField("WORK_DEPARTMENT");
		// $row->addInputField("WORK_POSITION");
		// $row->addViewField("WORK_WWW", TxtToHtml($userData["WORK_WWW"]));
		// $row->addInputField("WORK_WWW");
		// $row->addInputField("WORK_PHONE");
		// $row->addInputField("WORK_CITY");
		// $row->addInputField("XML_ID");
	}
	else
	{
		$row->addViewField("LOGIN", "<a onclick='window.openAccountNow(".$userId.
			")' title='".GetMessage("MAIN_EDIT_TITLE")."'>".HtmlFilter::encode($userData["LOGIN"])."</a>");
		$row->addViewField("EMAIL", TxtToHtml($userData["EMAIL"]));
		$row->addViewField("PERSONAL_WWW", TxtToHtml($userData["PERSONAL_WWW"]));
		$row->addViewField("WORK_WWW", TxtToHtml($userData["WORK_WWW"]));
	}

	$arActions = array();
	$can_edit = $currentUser;
	$arActions[] = array(
		"ICON" => $can_edit ? "edit" : "view",
		"TEXT" => GetMessage($can_edit ? "MAIN_ADMIN_MENU_EDIT" : "MAIN_ADMIN_MENU_VIEW"),
		"ACTION" => "window.openAccountNow($userId)",
		"DEFAULT" => true
	);
	if ($can_edit || $edit || true)
	{
		// $arActions[] = array(
		// 	"ICON" => "copy",
		// 	"TEXT" => GetMessage("MAIN_ADMIN_ADD_COPY"),
		// 	"LINK" => "user_edit.php?lang=".LANGUAGE_ID."&COPY_ID=".$userId
		// );
		if (in_array(1, $GLOBALS["HR_SELECTING_STATUS"])) {
			$arActions[] = array(
				"ICON" => "",
				"TEXT" => "На рассмотрение",
				"ACTION" => $lAdmin->actionDoGroup($userId, "to_consider")
			);
		}
		if ($currentUser && in_array(2, $GLOBALS["HR_SELECTING_STATUS"])) {
			$arActions[] = array(
				"ICON" => "",
				"TEXT" => "В список кандидатов",
				"ACTION" => $lAdmin->actionDoGroup($userId, "to_categories")
			);
		}
		if ($currentUser && in_array(3, $GLOBALS["HR_SELECTING_STATUS"])) {
			$arActions[] = array(
				"ICON" => "",
				"TEXT" => "Отправить в архив",
				"ACTION" => $lAdmin->actionDoGroup($userId, "to_archive")
			);
		}
		if (in_array(4, $GLOBALS["HR_SELECTING_STATUS"])) {
			$arActions[] = array(
				"ICON" => "",
				"TEXT" => "Принять",
				"ACTION" => $lAdmin->actionDoGroup($userId, "to_taken")
			);
		}
		if ($currentUser) {
			$arActions[] = array(
				"ICON" => "delete",
				"TEXT" => GetMessage("MAIN_ADMIN_MENU_DELETE"),
				"ACTION" => "if(confirm('".GetMessage('CONFIRM_DEL_USER')."')) ".$lAdmin->actionDoGroup($userId, "delete")
			);
			// $testVary = "if(confirm('".GetMessage('CONFIRM_DEL_USER')."')) ".$lAdmin->actionDoGroup($userId, "delete");
			// AddMessage2Log("\$testVary<script>console.log(".json_encode($testVary).");</script><br>", '', 0);
		}
	}
	if($USER->CanDoOperation('edit_php') && false)
	{
		$arActions[] = array("SEPARATOR"=>true);
		$arActions[] = array(
			"ICON" => "",
			"TEXT" => GetMessage("MAIN_ADMIN_AUTH"),
			"TITLE" => GetMessage("MAIN_ADMIN_AUTH_TITLE"),
			"LINK" => "user_admin.php?lang=".LANGUAGE_ID."&ID=".$userId."&action=authorize&".bitrix_sessid_get()
		);
	}

	$row->addActions($arActions);
}

$aContext = Array();

if ($USER->CanDoOperation('edit_subordinate_users') || $USER->CanDoOperation('edit_all_users') || true)
{
	// foreach($listGroup as $referenceId => $reference) $sGr[] = array("NAME" => $reference, "VALUE" => $referenceId);

	$ar = Array(
		"edit" => $currentUser,
		"delete" => $currentUser,
		"for_all" => true,
		// "deactivate" => "Добавить в резерв",
		// "activate" => "Убрать из резерва",
		// "add_group" => array(
		// 	"lable" => "Указать специальность",
		// 	"type" => "select",
		// 	"name" => "groups",
		// 	"items" => $sGr
		// ),
		// "remove_group"=>array(
		// 	"lable" => GetMessage("MAIN_ADMIN_LIST_REM_GROUP"),
		// 	"type" => "select",
		// 	"name" => "groups",
		// 	"items" => $sGr
		// )
	);
	if (in_array(1, $GLOBALS["HR_SELECTING_STATUS"])) $ar["to_consider"] = "На рассмотрение";
	if ($currentUser) {
		if (in_array(2, $GLOBALS["HR_SELECTING_STATUS"])) $ar["to_categories"] = "В список кандидатов";
		if (in_array(3, $GLOBALS["HR_SELECTING_STATUS"])) $ar["to_archive"] = "Отправить в архив";
	}
	if (in_array(4, $GLOBALS["HR_SELECTING_STATUS"])) $ar["to_taken"] = "Принять";

	//for Intranet editions: structure group operations and last authorization time
	if($bIntranetEdition && false)
	{
		$arUserFields = $USER_FIELD_MANAGER->GetUserFields('USER', 0, LANGUAGE_ID);
		$arUserField = $arUserFields['UF_DEPARTMENT'];
		if(is_array($arUserField))
		{
			$arUserField['MULTIPLE'] = 'N';
			$arUserField['SETTINGS']['LIST_HEIGHT'] = 1;

			$sStruct = call_user_func_array(
				array($arUserField["USER_TYPE"]["CLASS_NAME"], "GetGroupActionData"),
				array(
					$arUserField,
					array(
						"NAME" => $arUserField["FIELD_NAME"],
						"VALUE" => "",
					),
				)
			);
			$ar["add_structure"] = array(
				"lable" => GetMessage("MAIN_ADMIN_LIST_ADD_STRUCT"),
				"type" => "select",
				"name" => "UF_DEPARTMENT",
				"items" => $sStruct
			);
			$ar["remove_structure"] = array(
				"lable" => GetMessage("MAIN_ADMIN_LIST_REM_STRUCT"),
				"type" => "select",
				"name" => "UF_DEPARTMENT",
				"items" => $sStruct
			);
		}
		$ar["intranet_deactivate"] = GetMessage("MAIN_ADMIN_LIST_INTRANET_DEACTIVATE");
	}

	$arParams = array("select_onchange"=>"document.getElementById('bx_user_groups').style.display = (this.value == 'add_group' || this.value == 'remove_group'? 'block':'none');".(isset($ar["structure"])? "document.getElementById('bx_user_structure').style.display = (this.value == 'add_structure' || this.value == 'remove_structure'? 'block':'none');":""));

	$lAdmin->AddGroupActionTable($ar, $arParams);

	if ($currentUser) $aContext[] = array(
		"TEXT"	=> GetMessage("MAIN_ADD_USER"),
		"LINK"	=> "highloadblock_row_edit.php?lang=".LANGUAGE_ID,
		"TITLE"	=> GetMessage("MAIN_ADD_USER_TITLE"),
		"ICON"	=> "btn_new"
	);
}

$GLOBALS["BANK_RESUME"] = true;
$lAdmin->AddAdminContextMenu($aContext, true, $currentUser);
$lAdmin->CheckListMode();

// $APPLICATION->SetTitle(GetMessage("TITLE"));


define("START_EXEC_PROLOG_AFTER_1", microtime());
$GLOBALS["BX_STATE"] = "PA";

if(!defined("BX_ROOT"))
	define("BX_ROOT", "/bitrix");

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");

if (!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1)
{
	if (!defined('BX_AUTH_FORM') || !BX_AUTH_FORM)
		require_once($_SERVER["DOCUMENT_ROOT"]."/mail/prolog_main_admin.php");
		// require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_main_admin_custom.php");
	else
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_auth_admin.php");
}
else
	require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_jspopup_admin.php");

define("START_EXEC_PROLOG_AFTER_2", microtime());
$GLOBALS["BX_STATE"] = "WA";

$lAdmin->DisplayFilter($filterFields);
$lAdmin->DisplayList();
// require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");

function setHeaderColumn(CAdminUiList $lAdmin)
{
	$arHeaders = array(
		array("id"=>"ID", "content"=>"ID", 	"sort"=>"id", "default"=>false, "align"=>"right"),
		array("id"=>"EMAIL", "content"=>GetMessage('EMAIL'), "sort"=>"email", "default"=>true),
		array("id"=>"NAME", "content"=>GetMessage("NAME"), "sort"=>"name",	"default"=>true),
		array("id"=>"LAST_NAME", "content"=>GetMessage("LAST_NAME"), "sort"=>"last_name", "default"=>true),
		array("id"=>"SECOND_NAME", "content"=>GetMessage("SECOND_NAME"), "sort"=>"second_name", "default"=>true),
		array("id"=>"PERSONAL_MOBILE", "content"=>GetMessage("PERSONAL_MOBILE"), "sort"=>"personal_mobile", "default"=>true),
		array("id"=>"DATE_REGISTER", "content"=>GetMessage("DATE_REGISTER"), "sort"=>"date_register", "default"=>true),
		array("id"=>"TIMESTAMP_X", "content"=>GetMessage('TIMESTAMP'), "sort"=>"timestamp_x", "default"=>true),
		array("id"=>"PERSONAL_BIRTHDAY", "content"=>GetMessage("PERSONAL_BIRTHDAY"), "sort"=>"personal_birthday", "default"=>false),
		array("id"=>"UF_HR_RESERV", "content"=>"Кадровый резерв", "sort"=>"UF_HR_RESERV", "default"=>false),
		array("id"=>"UF_CIVIL_SERVICE", "content"=>"Опыт работы на гражданской службе", "sort"=>"UF_CIVIL_SERVICE", "default"=>false),
		array("id"=>"UF_HR_ALLOTMENT", "content"=>"Время рассмотрения", "sort"=>"UF_HR_ALLOTMENT", "default"=>false),
		array("id"=>"UF_HR_STATUS", "content"=>"Статус кандидата", "sort"=>"UF_HR_STATUS", "default"=>false),
		array("id"=>"UF_HR_CATEGORY", "content"=>"Специальность", "sort"=>"UF_HR_CATEGORY", "default"=>false),
		array("id"=>"UF_HR_EXPERIENCE", "content"=>"Стаж работы", "sort"=>"UF_HR_EXPERIENCE", "default"=>false),
		// array("id"=>"UF_HR_POSITION", "content"=>"Группа должностей", "sort"=>"UF_HR_POSITION", "default"=>false),	
	);

	// setRatingHeadersColumn($arHeaders);
	// setUFHeadersColumn($arHeaders);
	// AddMessage2Log("setUFHeadersColumn<script>console.log(".json_encode($arHeaders).");</script><br>", '', 0);

	$lAdmin->addHeaders($arHeaders);
}

function setRatingHeadersColumn(&$arHeaders)
{
	$rsRatings = CRatings::GetList(array('ID' => 'ASC'), array('ACTIVE' => 'Y', 'ENTITY_ID' => 'USER'));
	while ($arRatingsTmp = $rsRatings->GetNext())
	{
		$ratingId = $arRatingsTmp['ID'];
		$arHeaders[] = array(
			"id" => "RATING_".$ratingId,
			"content" => htmlspecialcharsbx($arRatingsTmp['NAME']),
			"sort" => "RATING_".$ratingId
		);
	}
}

function setUFHeadersColumn(&$arHeaders)
{
	global $USER_FIELD_MANAGER;
	$USER_FIELD_MANAGER->adminListAddHeaders("USER", $arHeaders);
}
?>

<div id="userlink" data-toggle="modal" data-target="#warning_lks">Редактировать список</div>

<div class="modal fade" id="warning_lks" tabindex="-1" role="dialog" aria-labelledby="warningTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="warningModalLongTitle" style="font-size: 16px; margin-left: 10px;">
                Редактировать список специальностей</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div id="jsGrid"></div>
                    <script>                        
                        var informationList = <?=json_encode($infoList)?>;
                        var pathToAjax = "<?=$currentPath;?>/special_ajax.php"; 
                        jsGrid.locale("ru");
                                    
                        $("#jsGrid").jsGrid({
                            width: "100%",
                            height: "326px",
                            data: informationList,                    
                            inserting: true,
                            editing: true,
                            sorting: true,
                            paging: true,
                            pageSize: 6,
                    
                            deleteConfirm: function(item) {
                                return "Специальность кандидата \"" + item["Номер"] + " - " + item["Название"] + "\" будет удалена. Вы уверены?";
                            },
                            onItemInserted: function(args) {
                                var thatGrid = this;
								var dataToOrm = { METHOD: '@INSERT', 
									NUMBER: args.item["Номер"], NAME: args.item["Название"], SORT: args.item["Сортировка"] };
                                $.post(pathToAjax, dataToOrm, function (data) {
                                    args.item["Номер"] = data.number;
                                    thatGrid.refresh();
                                    // console.log(data);
                                }, "json");
                            },
                            onItemUpdated: function(args) {
                                var thatGrid = this;
								var dataToOrm = { METHOD: '@UPDATE', 
									NUMBER: args.item["Номер"], NAME: args.item["Название"], SORT: args.item["Сортировка"] };
                                $.post(pathToAjax, dataToOrm, function (data) {
                                    args.item["Номер"] = data.number;
                                    thatGrid.refresh();
                                    // console.log(data);
                                }, "json");
                            },
                            onItemDeleted: function(args) {
								var dataToOrm = { METHOD: '@DELETE', 
									NUMBER: args.item["Номер"], NAME: args.item["Название"], SORT: args.item["Сортировка"] };
                                $.post(pathToAjax, dataToOrm, function (data) {
                                    // console.log(data);
                                }, "json");
                            },
                    
                            fields: [
                                { name: "Номер", type: "number", width: 50, editing: false },
                                { name: "Название", type: "text", width: 200, validate: "required" },
                                { name: "Сортировка", type: "number", width: 50, validate: "required" },
                                { type: "control" }
                            ]
                        });
                        setTimeout(function() {                            
                            $('.jsgrid .jsgrid-mode-button').trigger('click');
                            $('.jsgrid-grid-body').css({'height': '210px', 'overflow': 'hidden'});
                            $('.jsgrid-grid-header.jsgrid-header-scrollbar').css({'overflow': 'hidden'});
                        }, 400);
                    </script>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Закрыть</button>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
	$(document).ready(function() {
		$('html').attr('id', 'bx-admin-prefix');
		$('#adm-workarea').removeClass('adm-workarea').addClass('adm-workarea1');

		window.openAccountNow = function(userId) {
			var currentPath = 'highloadblock_row_edit.php?lang=ru&ID=' + userId;
			BX.SidePanel.Instance.open(currentPath);
		}

		$('div.adm-toolbar-panel-align-right > a').click(function(e) {
			e.preventDefault();
			// console.log(e);
			BX.SidePanel.Instance.open(e.currentTarget.href);
		});

		$(document).bind('refresh', function() {
			setTimeout(function() {
				BX.Main.gridManager.getById('tbl_user1').instance.reloadTable('POST');
			}, 700);		
		});

		$(this).keydown(function(event) {
			// console.log(event.which);
			if (event.which == 27) {
				BX.Main.gridManager.getById('tbl_user1').instance.reloadTable('POST');
			}
		});

	});		  
</script>