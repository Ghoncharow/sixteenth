<?
$MESS["HLBLOCK_ADMIN_ROWS_ADD_NEW_BUTTON"] = "Добавить запись";
$MESS["HLBLOCK_ADMIN_ROWS_RETURN_TO_LIST_BUTTON"] = "Вернуться в список";
$MESS["HLBLOCK_ADMIN_DELETE_ROW_CONFIRM"] = "Удалить запись?";
$MESS["HLBLOCK_ADMIN_ROWS_LIST_PAGE_TITLE"] = "Highload-блок \"#NAME#\": Список записей";
$MESS["HLBLOCK_ADMIN_ROWS_EDIT_ENTITY"] = "Редактировать Highload-блок";
$MESS["HLBLOCK_ADMIN_ROWS_LIST_NOT_FOUND"] = "Информация о Highload-блоке не найдена";
$MESS["MAIN_ADMIN_MENU_VIEW"] = "Посмотреть";
?>