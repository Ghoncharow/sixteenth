<?
$MESS["HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_EDIT"] = "Highload information block \"#NAME#\": Edit record ##NUM#";
$MESS["HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_NEW"] = "Highload information block \"#NAME#\": New record";
$MESS["HLBLOCK_ADMIN_ROW_EDIT_NOT_FOUND"] = "Highload information block data was not found.";
$MESS["HLBLOCK_ADMIN_ROWS_COPY"] = "Copy";
$MESS["HLBLOCK_ADMIN_ROWS_ACTIONS"] = "Actions";
$MESS["HLBLOCK_ADMIN_ROWS_ADD"] = "Add";
$MESS["HLBLOCK_ADMIN_ROWS_DEL"] = "Delete";
$MESS["HLBLOCK_ADMIN_ROWS_DEL_CONF"] = "Are you sure want to delete it?";
?>