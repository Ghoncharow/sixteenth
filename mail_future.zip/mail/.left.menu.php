<?
CJSCore::Init(array('jquery2', 'sidepanel'));
$aMenuLinks = Array(
	Array(
		"Почта", 
		"/mail", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Список кандидатов", 
		"/mail/categories/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"На рассмотрении", 
		"/mail/await.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Архив", 
		"/mail/archive/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
<style>
#layout-left-column .main-menu-item {
	max-width: 140px !important;	
	line-height: 1.4 !important;
}
</style>
