<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$queryResult = array( "method" => $_POST["METHOD"], "mailId" => $_POST["MAIL_ID"] );

if ($_POST["METHOD"] == '@UPDATE') {	
	Bitrix\Main\Loader::includeModule('mail');
	CMailMessage::Update( $_POST["MAIL_ID"], Array("NEW_MESSAGE"=>"N"));        
} else {
    $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);