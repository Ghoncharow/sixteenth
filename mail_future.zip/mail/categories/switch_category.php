<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();


$currentUser = CUser::GetUserGroup($GLOBALS["USER"]->GetId());
$jobEmploee = CUser::GetByID($GLOBALS["USER"]->GetId())->Fetch();
$jobPosition = CIBlockElement::GetList(['SORT' => 'ASC'], 
    ['IBLOCK_ID' => '31', 'ID' => $jobEmploee['UF_POSITION_WEIGHT']], false, [], ['SORT', 'ID', 'IBLOCK_ID'])->Fetch()['SORT'];
$jobPosition = empty($jobPosition) ? 1000 : intval($jobPosition);
if (!($GLOBALS["USER"]->IsAdmin() || ($jobPosition < 46) || in_array("47", $currentUser))) {
    echo "К разделу имеют доступ только сотрудники отдела кадров и их руководство. Приносим свои извинения.";
    echo "<br><br><br><br><br><br><br><br><br><br><br><br>";
    require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
    die();
}

$obEnum = new \CUserFieldEnum; 
$rsEnum = $obEnum->GetList(array(), array("USER_FIELD_ID" => 311));
$arrSpecial = array();
while ($arEnum = $rsEnum->Fetch()) $arrSpecial[] = $arEnum["ID"];

if (!in_array($_GET["special"], $arrSpecial) && ($_GET["special"] != 'without')) {
    $hrefLocation = "/mail/categories/?special=without";
    $nameButton = "Без специальности";
} else {
    $hrefLocation = "/mail/categories/";
    $nameButton = "Все специальности";
}
?>
<style>
    #hr_department_post {
        width: 230px;
    	font-size: 15px;
        height: 39px;
        margin: 15px 15px 15px 20px;
        padding: 2px;
        border: 1px solid #d5dde0;
        border-radius: 2px;
    }
	#button-all-categories {
		position: relative;
		display: inline-block;
		vertical-align: top;
		height: 39px;
		padding: 0 19px;
		margin: 15px;
		border-radius: 2px;
		text-align: center;
		background-color: #3bc8f5;
		color: #fff;
		text-transform: uppercase;
		font: 600 12px/39px "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
		cursor: pointer;
		transition: 160ms color linear, 160ms background-color linear, 160ms opacity linear, 160ms padding linear;
	}
	#button-all-categories:hover {
		background-color: rgba(59, 210, 255, 0.9);
	}
</style>
<select id="hr_department_post">
    <? $rsEnum = $obEnum->GetList(array(), array("USER_FIELD_ID" => 311));
       $ji = intval($rsEnum->SelectedRowsCount()); ?>
    <option value="0">Выберите специальность:</option>
    <? while ($arEnum = $rsEnum->Fetch()) { 
        $lastLetter = (1 == $ji--) ? '.' : ';';?>    
        <option value="<?=$arEnum["ID"];?>">- <?=$arEnum["VALUE"].$lastLetter;?></option>
    <? } ?>                        
</select>

<div onclick="redirectTo('<?=$hrefLocation;?>')" id="button-all-categories"><?=$nameButton;?></div>
<script>
	function redirectTo(path) {
		document.location.href = path;
	}
    $(document).ready(function () {
        var hrDepartment = $("#hr_department_post");
        hrDepartment.change(function () {
            var selectedPath = "/mail/categories/?special=" + hrDepartment.val();
            if (hrDepartment.val() != '<?=$_GET["special"];?>') document.location.href = selectedPath;
        });
    });
</script>
<?