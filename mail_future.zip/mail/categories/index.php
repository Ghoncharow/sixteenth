<?php

if (!(($_GET["grid_id"] == "tbl_user1") || ($_REQUEST["mode"] == 'excel'))) {
    require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
    $APPLICATION->SetPageProperty("description", "Банк резюме - специальности");
    require_once($_SERVER["DOCUMENT_ROOT"]."/mail/categories/switch_category.php");
} else {
    require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
    Bitrix\Main\Loader::includeModule('main');
}

$obEnum = new \CUserFieldEnum; 
$rsEnum = $obEnum->GetList(array(), array("USER_FIELD_ID" => 311));
$arrSpecial = array();
while ($arEnum = $rsEnum->Fetch()) {
    $arrSpecial[] = $arEnum["ID"];
    $arrTitles[$arEnum["ID"]] = $arEnum["VALUE"];
}

if (in_array($_GET["special"], $arrSpecial)) {
    $APPLICATION->SetTitle($arrTitles[$_GET["special"]]);
    $GLOBALS["HR_SELECTING_STATUS"] = array(1, 3, 4);
    $GLOBALS["HR_FILTRATION"] = array(
            "UF_HR_CATEGORY" => array($_GET["special"]), 
            "UF_HR_STATUS" => ["80"], 
            ">UF_TIMESTAMP_X" => date('d.m.Y', (time() - (60*60*24*365)))
        );
} elseif ($_GET["special"] == 'without') {
    $APPLICATION->SetTitle("Банк резюме - без специальности");
    $GLOBALS["HR_SELECTING_STATUS"] = array(3, 4);
    $GLOBALS["HR_FILTRATION"] = array(
            "=UF_HR_CATEGORY" => null,
            "UF_HR_STATUS" => ["80"], 
            ">UF_TIMESTAMP_X" => date('d.m.Y', (time() - (60*60*24*365)))
        );
} else {
    $APPLICATION->SetTitle("Банк резюме - все специальности");
    $GLOBALS["HR_SELECTING_STATUS"] = array(1, 3, 4);
    $GLOBALS["HR_FILTRATION"] = array(
            "UF_HR_CATEGORY" => $arrSpecial, 
            "UF_HR_STATUS" => ["80"], 
            ">UF_TIMESTAMP_X" => date('d.m.Y', (time() - (60*60*24*365)))
        );
}
// echo date('d.m.Y', (time() - (60*60*24*184)));
// echo date('d.m.Y', (time() - (60*60*24*30)));
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');

