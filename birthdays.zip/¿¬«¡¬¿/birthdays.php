<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/intranet/public/company/birthdays.php");
$APPLICATION->SetTitle(GetMessage("COMPANY_TITLE"));
?>
<?$APPLICATION->IncludeComponent(
	"custom:intranet.structure.birthday.nearest", 
	".default", 
	array(
		"STRUCTURE_PAGE" => "structure.php",
		"PM_URL" => "/company/personal/messages/chat/#USER_ID#/",
		"PATH_TO_CONPANY_DEPARTMENT" => "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#",
		"PATH_TO_VIDEO_CALL" => "/company/personal/video/#USER_ID#/",
		"STRUCTURE_FILTER" => "structure",
		"NUM_USERS"	=>	"6",
		"NAV_TITLE"	=>	"Сотрудники",
		"SHOW_NAV_BOTTOM"	=>	"Y",
		"DATE_FORMAT" => "d.m.Y",
		"DATE_FORMAT_NO_YEAR" => "d.m",
		"DATE_TIME_FORMAT" => "d.m.Y H:i:s",
		"SHOW_YEAR" => "M",
		"USER_PROPERTY" => array(
			0 => "PERSONAL_PHOTO",
			1 => "PERSONAL_PHONE",
			2 => "UF_DEPARTMENT",
			3 => "UF_PHONE_INNER",
			4 => "UF_SKYPE",
		),
		"SHOW_FILTER" => "Y",
		"FILTER_ID" => 'BIRTHDAYS',
		"COMPONENT_TEMPLATE" => ".default",
		"NAME_TEMPLATE" => "",
		"SHOW_LOGIN" => "Y",
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "3600",
		"DEPARTMENT" => "0"
	),
	false
);?>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>