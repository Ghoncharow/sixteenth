<?
$MESS['WIDGET_BIRTHDAY_TITLE'] = 'Дни рождения';
?>