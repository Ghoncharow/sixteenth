<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
// echo '<script type="text/javascript">console.log('.json_encode($arResult).');</script>';

$this->addExternalCss(SITE_TEMPLATE_PATH."/css/sidebar.css");

$this->setFrameMode(true);

if (count($arResult["USERS"]) < 1)
	return;

$this->SetViewTarget("sidebar", 300);
?>
<style>
.sidebar-widget-top {
    background-color: mediumvioletred;
    margin-bottom: 13px;
}
.sidebar-widget-top-title:hover {
    color: #fff;
    font-family: "OpenSans-Bold", sans-serif;
    font-size: 12px;
    height: 40px;
    line-height: 40px;
    padding-left: 20px;
    text-transform: uppercase;
}
.user-events-name {
    display: inline-block;
    width: 100%;
}
.user-events-date {    
    display: inline-block;    
    font-weight: normal;
    width: 100%;
}
</style>
<div class="sidebar-widget sidebar-widget-events">
	<div class="sidebar-widget-top">
		<a href="/company/events.php" target="_blank" class="sidebar-widget-top-title"><?=GetMessage("WIDGET_HR_TITLE")?></a>
	</div>
	<?
	$i = 0;
	foreach ($arResult['ENTRIES'] as $arEntry):
	$arUser = $arResult['USERS'][$arEntry['PROPERTY_USER_VALUE']];
	$arUser['SUBTITLE'] = $arEntry['DATE_ACTIVE_FROM'].' - '.ToLower(
		$arEntry['PROPERTY_STATE_VALUE'] ? $arEntry['PROPERTY_STATE_VALUE'] 
			: ($arEntry['PREVIEW_TEXT'] ? $arEntry['PREVIEW_TEXT'] : $arEntry['NAME'])
	);?>
	<a href="<?=$arUser["DETAIL_URL"]?>" class="sidebar-widget-item<?if(++$i == count($arResult["USERS"])):?> widget-last-item<?endif?><?if ($arUser["IS_BIRTHDAY"]):?> today-birth<?endif?>">
		<span class="user-avatar user-default-avatar"
			<?if (isset($arUser["PERSONAL_PHOTO"]["src"])):?>
				style="background: url('<?=$arUser["PERSONAL_PHOTO"]["src"]?>') no-repeat center; background-size: cover;"
			<?endif?>>
		</span>
		<span class="sidebar-user-info">
			<span class="user-events-name"><?=CUser::FormatName($arParams['NAME_TEMPLATE'], $arUser, true);?></span>
			<span class="user-events-date" style="font-size: 12px; color: black;">
				<?=$arUser['SUBTITLE']?>
			</span>
			<span class="user-events-date" style="font-size: 14px; color: #80868e;">
				<?=empty($arEntry['PROPERTY_POST_VALUE']) ? 'Без должности' : $arEntry['PROPERTY_POST_VALUE']?>
			</span>
		</span>
	</a>
	<?endforeach?>
</div>