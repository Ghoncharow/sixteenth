<?
$MESS['WIDGET_HR_TITLE'] = 'Кадровые изменения';
?>