<?
$MESS["INTRANET_USTAT_ONLINE_EMPTY"] = "Немає даних";
$MESS["INTRANET_USTAT_ONLINE_FINISHED_DAY"] = "Завершили";
$MESS["INTRANET_USTAT_ONLINE_HINT"] = "Співробітників онлайн";
$MESS["INTRANET_USTAT_ONLINE_STARTED_DAY"] = "Працюють";
$MESS["INTRANET_USTAT_ONLINE_USERS"] = "Співробітники онлайн";
?>