<?
$MESS["INTRANET_USTAT_ONLINE_COMPONENT_MODULE_NOT_INSTALLED"] = "Модуль Push&Pull не встановлено";
?>