<?
$MESS["INTRANET_USTAT_ONLINE_COMPONENT_MODULE_NOT_INSTALLED"] = "Das Modul Push&Pull ist nicht installiert";
?>