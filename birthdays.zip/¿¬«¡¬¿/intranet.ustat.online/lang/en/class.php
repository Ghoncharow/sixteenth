<?
$MESS["INTRANET_USTAT_ONLINE_COMPONENT_MODULE_NOT_INSTALLED"] = "The Push&Pull module is not installed";
?>