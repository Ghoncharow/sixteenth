<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if ($arParams['bCache'])
{
	$cache_dir = '/'.SITE_ID.$this->__component->GetRelativePath().'/'.$this->GetName();
	$cache_id = $this->GetFile().'|'.$arParams['NUM_USERS'];//.'|'.$USER->GetGroups();
	$obCache = new CPHPCache();
}

$arParams['SHOW_FILTER'] = $arParams['SHOW_FILTER'] == 'N' ? 'N' : 'Y';

if (!$arParams['bShowFilter'])
	$arParams['SHOW_FILTER'] = 'N';

$bLoadDepartments = in_array('UF_DEPARTMENT', $arParams['USER_PROPERTY']);

if ($arParams['bCache'] && $obCache->InitCache($arParams['CACHE_TIME'], $cache_id, $cache_dir))
{
	$vars = $obCache->GetVars();
	$arCacheData = $vars['TEMPLATE_DATA'];
	$arResult['USER_PROP'] = $vars['USER_PROP'];
}
else
{
	$arCacheData = array();

	$arResult['USER_PROP'] = array();
	$arRes = $GLOBALS["USER_FIELD_MANAGER"]->GetUserFields("USER", 0, LANGUAGE_ID);

	if (!empty($arRes))
	{
		foreach ($arRes as $key => $val)
		{
			$arResult['USER_PROP'][$val["FIELD_NAME"]] = ($val["EDIT_FORM_LABEL"] <> '' ? $val["EDIT_FORM_LABEL"] : $val["FIELD_NAME"]);
		}
	}
}


if ($arParams['SHOW_FILTER'] == 'Y') {
	$this->SetViewTarget('inside_pagetitle', 0);
		if (empty($arParams["FILTER_ID"])) $arParams["FILTER_ID"] = 'BIRTHDAYS';
		$toolbarId = 'BIRTHDAYS_FILTER_TOOLBAR'; 
		$APPLICATION->IncludeComponent(
			'bitrix:main.ui.filter',
			'',
			array(
				'THEME' => 'ROUNDED',
				'GRID_ID' => $arParams["FILTER_ID"],
				'FILTER_ID' => $arParams["FILTER_ID"],
				'FILTER' => $arResult["FilterFields"],
				'FILTER_FIELDS' => array(),
				'FILTER_PRESETS' => $arResult['FilterPresets'],
				'ENABLE_LIVE_SEARCH' => false,
				'RESET_TO_DEFAULT_MODE' => false,
				'ENABLE_LABEL' => true,
				'COMPACT_STATE' => true,
				'CONFIG' => array(
					'AUTOFOCUS' => false,
					'POPUP_BIND_ELEMENT_SELECTOR' => '#'.htmlspecialcharsbx($arParams["FILTER_ID"]).'_filter_container_max',
					'POPUP_OFFSET_LEFT' => 0,
					'DEFAULT_PRESET' => false
				)
			),
			$this->getComponent()
		);?>
		<script>
			BX.ready(function(){
				var searchInput = document.querySelector("input.main-ui-filter-search-filter");
				var rounded = document.querySelector(".main-ui-filter-search.main-ui-filter-theme-rounded");
				if (rounded && searchInput) {
					var squarePreset = document.querySelector(".main-ui-filter-search-square.main-ui-square");
					if (!squarePreset && !searchInput.value) rounded.classList.add("closed");
					rounded.onclick = function() {
						if (!this.classList.contains("open")) this.classList.add("open");
					};
					searchInput.onblur = function() {
						setTimeout(function() {
							squarePreset = document.querySelector(".main-ui-filter-search-square.main-ui-square");
							var popup = document.querySelector(".popup-window.main-ui-popup-show-animation");
							popupOpen = popup && popup.style.display == "block";
							if (!squarePreset && !popupOpen && !searchInput.value) rounded.classList.remove("open");
							if (!rounded.classList.contains("closed")) rounded.classList.add("closed");					
						}, 200);
					};
				}
			});
			BX.addCustomEvent("BX.Main.Filter:apply", BX.delegate(function(eventFilterId, values, ob, filterPromise, filterParams) {
				// console.log(eventFilterId, values, ob, filterPromise, filterParams);
				if (eventFilterId == "BIRTHDAYS") {
					setTimeout(function() {
						// document.location.reload();
						var ajaxPath = location.pathname + "?AJAX_BIRTHDAYS=Y&IFRAME=Y" + 
											"<?=empty($_GET['PAGEN_1']) ? '' : '&PAGEN_1='.$_GET['PAGEN_1'];?>";
						// console.log(ajaxPath);
						BX.ajax({   
							url: ajaxPath,
							method: 'GET',
							dataType: 'html',
							timeout: 30,
							async: true,
							processData: true,
							scriptsRunFirst: true,
							emulateOnload: true,
							start: true,
							cache: false,
							onsuccess: function(data) {
								// console.log(data);
								if (data) {
									var ajaxArea = document.querySelector("#ajax-birthdays-area");
									var ajaxData = data.split("<!--ajax-birthdays-separator-->");
									// console.log(ajaxArea, ajaxData[1]);
									if (ajaxArea) ajaxArea.innerHTML = ajaxData[1];
								}
							},
							onfailure: function(){
								console.log('Ajax-request error.');
							}
						});
					}, 400);
				}
			}, this));
		</script>
		<div id="<?=htmlspecialcharsbx($toolbarId)?>" class="pagetitle-container pagetitle-align-right-container">
			<button id="feed_filter_button" class="ui-btn ui-btn-link ui-btn-filter-button ui-btn-themes"></button>
			<script>
				BX.ready(function() {
					var helpMesage = "Фильтр панели инструментов позволяет искать сотрудников по фамилиии или номеру учётной записи, " + 
					"а также из модального окна выбирать другие критерии поиска.";
					BX.bind(BX('feed_filter_button'), 'click', function() {
						alert(helpMesage);
					});
				});
			</script>
		</div>
		<?
	$this->EndViewTarget();
}

if ($arResult['bUsersCached'])
	$strUserIDs = '';

if ($arParams['bCache'])
{
	$obCache->StartDataCache();
	global $CACHE_MANAGER;
	$CACHE_MANAGER->StartTagCache($cache_dir);
}

foreach ($arResult['USERS'] as $key => $arUser)
{
	if ($arResult['bUsersCached'])
		$strUserIDs .= ($strUserIDs ? '|' : '').$arUser['ID'];

	if (!is_array($arCacheData[$arUser['ID']]))
		$arCacheData[$arUser['ID']] = array();

	$arUser['IS_ONLINE'] = $arResult['bUsersCached'] ? false : CIntranetUtils::IsOnline($arUser['LAST_ACTIVITY_DATE']);

	$arUser['IS_BIRTHDAY'] = CIntranetUtils::IsToday($arUser['PERSONAL_BIRTHDAY']);
	
	if (array_key_exists('IS_ABSENT', $arCacheData[$arUser['ID']]))
	{
		$arUser['IS_ABSENT'] = $arCacheData[$arUser['ID']]['IS_ABSENT'];
	}
	else
	{
		$arUser['IS_ABSENT'] = $arCacheData[$arUser['ID']]['IS_ABSENT'] = CIntranetUtils::IsUserAbsent($arUser['ID']);
	}

	if (array_key_exists('IS_FEATURED', $arCacheData[$arUser['ID']]))
	{
		$arUser['IS_FEATURED'] = $arCacheData[$arUser['ID']]['IS_FEATURED'];
	}
	else
	{
		$arUser['IS_FEATURED'] = $arCacheData[$arUser['ID']]['IS_FEATURED'] = CIntranetUtils::IsUserHonoured($arUser['ID']);
	}
	
	
	if ($arUser['PERSONAL_PHOTO'])
	{
		$arImage = CIntranetUtils::InitImage($arUser['PERSONAL_PHOTO'], 100);
		$arUser['PERSONAL_PHOTO'] = $arImage['IMG'];
		//$arUser['PERSONAL_PHOTO'] = CFile::ShowImage($arUser['PERSONAL_PHOTO'], 100, 100);
	}

	if ($bLoadDepartments && is_array($arUser['UF_DEPARTMENT']) && count($arUser['UF_DEPARTMENT']) > 0)
	{
		if (array_key_exists('UF_DEPARTMENT', $arCacheData[$arUser['ID']]))
		{
			$arUser['UF_DEPARTMENT'] = $arCacheData[$arUser['ID']]['UF_DEPARTMENT'];
		}
		else
		{
			$arUser['UF_DEPARTMENT'] = $arCacheData[$arUser['ID']]['UF_DEPARTMENT'] = CIntranetUtils::GetDepartmentsData($arUser['UF_DEPARTMENT']);
		}
	}
	
	$arResult['USERS'][$key] = $arUser;
}

if ($arParams['bCache'])
{
	$CACHE_MANAGER->EndTagCache();
	$obCache->EndDataCache(array(
		'TEMPLATE_DATA' => $arCacheData,
		'USER_PROP' => $arResult['USER_PROP'],
	));
}

if ($arResult['bUsersCached'] && $strUserIDs <> '')
{
	$dbRes = CUser::GetList($by='id', $order='asc', array('ID' => $strUserIDs, 'LAST_ACTIVITY' => 120));
	while ($arRes = $dbRes->Fetch())
	{
		$arResult['USERS'][$arRes['ID']]['IS_ONLINE'] = true;
	}
	unset($dbRes);
}
?>