<?
$MESS ['INTR_GROUP_NAME'] = 'Корпоративный портал';
$MESS ['INTR_ISBN_COMPONENT_NAME'] = 'Дни рождения';
$MESS ['INTR_ISBN_COMPONENT_DESCR'] = 'Вывод списка ближайших именинников';
$MESS ['INTR_HR_GROUP_NAME'] = 'HR';
?>