<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTR_ISBN_COMPONENT_NAME'] = "Birthdays";
$MESS ['INTR_ISBN_COMPONENT_DESCR'] = "Shows soonest birthdays";
$MESS ['INTR_HR_GROUP_NAME'] = "HR";
?>
