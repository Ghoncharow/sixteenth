<?
$MESS ['NAME_TEMPLATE_TIP'] = "Possible macros: #NAME# - first name; #LAST_NAME# - last name, #SECOND_NAME# - middle name; #NAME_SHORT#, #LAST_NAME_SHORT#, #SECOND_NAME_SHORT# - abbreviations of the respective names.";
?>