<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

// Parameters:
// NUM_USERS => 5 - number of users to show
// DATE_INTERVAL => 60 - date interval to show (days) // not yet

if (!CModule::IncludeModule('intranet')) return;

$arResult["AJAX_BIRTHDAYS"] = isset($_REQUEST["AJAX_BIRTHDAYS"]) && ($_REQUEST["AJAX_BIRTHDAYS"] == "Y");
unset($_GET["AJAX_BIRTHDAYS"]);
unset($_GET["_"]);
unset($_GET["IFRAME"]);

$arParams['NUM_USERS'] = intval($arParams['NUM_USERS']);

if (trim($arParams["NAME_TEMPLATE"]) == '')
{
	$arParams["NAME_TEMPLATE"] = CSite::GetNameFormat();
}
$arParams['SHOW_LOGIN'] = $arParams['SHOW_LOGIN'] != "N" ? "Y" : "N";

if (!array_key_exists("PM_URL", $arParams))
	$arParams["~PM_URL"] = $arParams["PM_URL"] = "/company/personal/messages/chat/#USER_ID#/";
if (!array_key_exists("PATH_TO_CONPANY_DEPARTMENT", $arParams))
	$arParams["~PATH_TO_CONPANY_DEPARTMENT"] = $arParams["PATH_TO_CONPANY_DEPARTMENT"] = "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#";
if (IsModuleInstalled("video") && !array_key_exists("PATH_TO_VIDEO_CALL", $arParams))
	$arParams["~PATH_TO_VIDEO_CALL"] = $arParams["PATH_TO_VIDEO_CALL"] = "/company/personal/video/#USER_ID#/";

$arParams['SHOW_YEAR'] = $arParams['SHOW_YEAR'] == 'Y' ? 'Y' : ($arParams['SHOW_YEAR'] == 'M' ? 'M' : 'N');

if (!$arParams['DATE_FORMAT']) $arParams['DATE_FORMAT'] = CComponentUtil::GetDateFormatDefault();
if (!$arParams['DATE_FORMAT_NO_YEAR']) $arParams['DATE_FORMAT_NO_YEAR'] = CComponentUtil::GetDateFormatDefault(true);

$arParams['DETAIL_URL'] = trim($arParams['DETAIL_URL']);
if (!$arParams['DETAIL_URL'])
	$arParams['~DETAIL_URL'] = $arParams['DETAIL_URL'] = COption::GetOptionString('intranet', 'search_user_url', '/user/#ID#/');

$arParams['DEPARTMENT'] = intval($arParams['DEPARTMENT']);
$arParams['bShowFilter'] = $arParams['DEPARTMENT'] <= 0;

// for bitrix:main.user.link
$arTooltipFieldsDefault = serialize(array(
	"EMAIL",
	"PERSONAL_MOBILE",
	"WORK_PHONE",
	"PERSONAL_ICQ",
	"PERSONAL_PHOTO",
	"PERSONAL_CITY",
	"WORK_COMPANY",
	"WORK_POSITION",
));
$arTooltipPropertiesDefault = serialize(array(
	"UF_DEPARTMENT",
	"UF_PHONE_INNER",
));

if (!array_key_exists("SHOW_FIELDS_TOOLTIP", $arParams))
	$arParams["SHOW_FIELDS_TOOLTIP"] = unserialize(COption::GetOptionString("socialnetwork", "tooltip_fields", $arTooltipFieldsDefault));
if (!array_key_exists("USER_PROPERTY_TOOLTIP", $arParams))
	$arParams["USER_PROPERTY_TOOLTIP"] = unserialize(COption::GetOptionString("socialnetwork", "tooltip_properties", $arTooltipPropertiesDefault));

if (
	!array_key_exists("USER_PROPERTY", $arParams)
	|| !is_array($arParams["USER_PROPERTY"])
	|| empty($arParams["USER_PROPERTY"])
)
{
	$arParams["USER_PROPERTY"] = array("WORK_POSITION");
}
// don't show department filter when extranet

if (CModule::IncludeModule('extranet') && CExtranet::IsExtranetSite())
	$arParams['bShowFilter'] = false;

if(!isset($arParams["CACHE_TIME"]))
	$arParams["CACHE_TIME"] = 3600;

if (0 && $arParams['CACHE_TYPE'] == 'A')
	$arParams['CACHE_TYPE'] = COption::GetOptionString("main", "component_cache_on", "Y");

$arParams['bCache'] = $arParams['CACHE_TYPE'] == 'Y' && $arParams['CACHE_TIME'] > 0;

if ($arParams['bCache'])
{
	$cache_dir = '/'.SITE_ID.$this->GetRelativePath();
	$cache_id = $this->GetName().'|'.$arParams['NUM_USERS'].'|'.SITE_ID.'|'.CTimeZone::GetOffset();//.'|'.$USER->GetGroups();
	$obCache = new CPHPCache();
}

$arResult['CURRENT_USER'] = array();

$arResult['DEPARTMENT'] = $arParams['DEPARTMENT'] > 0 ? $arParams['DEPARTMENT'] : (intval($_REQUEST['department']) > 0 ? intval($_REQUEST['department']) : 0);

if ($arParams['bCache'] && $arResult['DEPARTMENT'] > 0)
{
	$cache_id .= '|'.$arResult['DEPARTMENT'];
}
if (CModule::IncludeModule('extranet') && CExtranet::IsExtranetSite())
{
	$cache_id .= '|'.$GLOBALS["USER"]->GetID();
}

// and only from now on we can start caching ;-)
if ($arParams['bCache'] && $obCache->InitCache($arParams['CACHE_TIME'], $cache_id, $cache_dir))
{
	$vars = $obCache->GetVars();

	$arResult['bUsersCached'] = true;
	$arResult['USERS'] = $vars['USERS'];
}
else
{
	$arResult['bUsersCached'] = false;

	if ($arParams['bCache'])
	{
		$obCache->StartDataCache();
		global $CACHE_MANAGER;
		$CACHE_MANAGER->StartTagCache($cache_dir);

		if (defined("BX_COMP_MANAGED_CACHE"))
		{
			$CACHE_MANAGER->RegisterTag('intranet_users');
			$CACHE_MANAGER->RegisterTag('intranet_birthday');
		}
	}

	$arFilter = array(
		'ACTIVE' => 'Y',
		'!EXTERNAL_AUTH_ID' => array('replica', 'email', 'bot', 'imconnector'),
	);

	// if ($arResult['DEPARTMENT'] > 0 && (!CModule::IncludeModule('extranet') || !CExtranet::IsExtranetSite()))
	// {
	// 	$arFilter['UF_DEPARTMENT'] = CIntranetUtils::GetIBlockSectionChildren(intval($arResult['DEPARTMENT']));
	// }
	// elseif (!CModule::IncludeModule('extranet') || !CExtranet::IsExtranetSite())
	// 	$arFilter["!UF_DEPARTMENT"] = false;

	if (CModule::IncludeModule('extranet') && CExtranet::IsExtranetSite())
	{
		$arIDs = array_merge(CExtranet::GetMyGroupsUsers(SITE_ID), CExtranet::GetPublicUsers());

		if ($arParams['bCache'] && defined("BX_COMP_MANAGED_CACHE"))
		{
			$CACHE_MANAGER->RegisterTag('extranet_public');
			$CACHE_MANAGER->RegisterTag('extranet_user_'.$USER->GetID());
		}

		if (count($arIDs) > 0)
			$arFilter['ID'] = implode('|', array_unique($arIDs));
		else
		{
			$bDisable = true;
		}
	}


	$propertyManager = new \Bitrix\Iblock\Helpers\Filter\PropertyManager(6);
	$arResult["FilterFields"] = array(
		array(
			'id' => 'USER_VALUE',
			'name' => 'Именинник',
			'default' => true,
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_PROPERTY_USER_VALUE',
				'multiple' => 'N',
				'contextCode' => 'U',
				'enableAll' => 'N',
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'Y',
			),
		),
		array(
			'id' => 'DEPARTMENT_VALUE',
			'name' => 'Подразделение',
			'default' => true,
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_PROPERTY_DEPARTMENT_VALUE',
				'multiple' => 'N',
				'contextCode' => 'DR',
				'enableAll' => 'N',
				'enableDepartments' => "Y",
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'N',
				'departmentFlatEnable' => "Y",
				'enableUsers' => "N",
				'isNumeric' => "N"
			),
		),
		array(
			"id" => "ID",
			"name" => "ID",
			"type" => "number",
			"filterable" => ""
		),
		array(
			'id' => 'SORT_RANGE',
			'name' => 'Диапазон сортировки',
			'type' => 'list',
			'default' => false,
			'params' => array('multiple' => 'N',),
			'items' => array(				
				'10' => 'Предыдущий месяц',
				'20' => 'Текущий месяц',
				'30' => 'Следующий месяц',
			)
		),
		array(
			"id" => "PERSONAL_BIRTHDAY",
			"name" => "Дата рождения",
			'default' => false,
			"type" => "date",
			"filterable" => ""
		),
		array(
			"id" => "TIMESTAMP_X",
			"name" => "Дата изменения",
			"type" => "date",
			"filterable" => ""
		),
		array(
			"id" => "DATE_REGISTER",
			"name" => "Дата регистрации",
			"type" => "date",
			"filterable" => ""
		),
		array(
			"id" => "LAST_LOGIN",
			"name" => "Последняя авторизация",
			"type" => "date",
			"filterable" => ""
		),
		array(
			"id" => "PERSONAL_PHONE",
			"name" => "Рабочий телефон",
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "UF_PHONE_INNER",
			"name" => "Внутренний телефон",
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "PERSONAL_MOBILE",
			"name" => "Мобильный телефон",
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "EMAIL",
			"name" => "E-mail",
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "WORK_POSITION",
			"name" => "Должность",
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "DEPARTMENTS",
			"name" => "Отделы",
			'type' => 'list',
			'params' => array(
				'multiple' => 'Y',
			),
			'items' => $propertyManager->getFilterFields()[0]["items"],
			"filterable" => "",
		),
	);

	$arResult['FilterPresets'] = array(
		'lastMonth' => array('fields' => array('SORT_RANGE' => "10"), 'name' => "Предыдущий месяц"),
		'thisMonth' => array('fields' => array('SORT_RANGE' => "20"), 'name' => "Текущий месяц"),
		'nextMonth' => array('fields' => array('SORT_RANGE' => "30"), 'name' => "Следующий месяц"),
	);

	if (empty($arParams["FILTER_ID"])) $arParams["FILTER_ID"] = 'BIRTHDAYS';
	$filterOptions = new \Bitrix\Main\UI\Filter\Options($arParams["FILTER_ID"]);
	$filterNow = $filterOptions->getFilter($arResult["FilterFields"]);

	if ($filterNow["FILTER_APPLIED"]) $arResult['FilterNow'] = $filterNow;
	else $arFilter['PERSONAL_BIRTHDAY_1'] = "01.01.1000";

	if ($filterNow["SORT_RANGE"]) {
		global $DB;		
		$nowRange = new DateTime();
		switch ($filterNow["SORT_RANGE"]) {
			case "10":
				$previousMonth = $nowRange->modify('first day of previous month');
				$my_month = $previousMonth->format('m');
			break;
			case "20":
				$my_month = $nowRange->format('m');
			break;
			case "30":
				$nextMonth = $nowRange->modify('first day of next month');
				$my_month = $nextMonth->format('m');
			break;
			default:
		}
		$db_data = $DB->Query('SELECT ID FROM b_user WHERE DATE_FORMAT( PERSONAL_BIRTHDAY, "%m" ) = "'.$my_month.'"');
		$TodayMonthBirthdayIDs = Array();
		while ($user_tmp_data = $db_data->Fetch()) array_push($TodayMonthBirthdayIDs, intval($user_tmp_data["ID"]));
		$arFilter['ID'] = implode('|', $TodayMonthBirthdayIDs);
		$arResult['my_month'] = $my_month;
	}

	if (intval($filterNow["FIND"])) {
		$arFilter['ID'] =  preg_replace("/[^0-9]/", '', $filterNow["FIND"]);
	} else {
		$filterNowArray = explode(' ', $filterNow["FIND"]);
		if ($filterNowArray[1]) $arFilter['NAME'] = '%'.$filterNowArray[1].'%';
		if ($filterNowArray[2]) $arFilter['SECOND_NAME'] = '%'.$filterNowArray[2].'%';
		if ($filterNowArray[0]) $arFilter['LAST_NAME'] = '%'.$filterNowArray[0].'%';
	}
	if ($filterNow["ID_numsel"]) {
		$filterNowArray = array();
		if (empty($filterNow["ID_to"])) {
			$dbAllUsers = CUser::getList($by='ID', $order = 'DESC', array(), array('FIELDS'=>array('ID')));
			$arResult['ID_MAX'] = $filterNow["ID_to"] = $dbAllUsers->Fetch()['ID'];
		}		
		for ($ii = intval($filterNow["ID_from"]); $ii <= intval($filterNow["ID_to"]); $ii++) $filterNowArray[] = $ii;
		$arFilter['ID'] = implode('|', $filterNowArray);
	}
	if ($filterNow["USER_VALUE"]) {
		$filterNowId = preg_replace("/[^0-9]/", '', $filterNow["USER_VALUE"]);
		$arFilter['ID'] = empty($arFilter['ID']) ? $filterNowId : $arFilter['ID'].'|'.$filterNowId;
	}				
	if ($filterNow["PERSONAL_BIRTHDAY_datesel"]) {
		$arFilter['PERSONAL_BIRTHDAY_1'] = $filterNow["PERSONAL_BIRTHDAY_from"];
		$arFilter['PERSONAL_BIRTHDAY_2'] = $filterNow["PERSONAL_BIRTHDAY_to"];
	}
	if ($filterNow["TIMESTAMP_X_datesel"]) {
		$arFilter['TIMESTAMP_1'] = $filterNow["TIMESTAMP_X_from"];
		$arFilter['TIMESTAMP_2'] = $filterNow["TIMESTAMP_X_to"];
	}
	if ($filterNow["DATE_REGISTER_datesel"]) {
		$arFilter['DATE_REGISTER_1'] = $filterNow["DATE_REGISTER_from"];
		$arFilter['DATE_REGISTER_2'] = $filterNow["DATE_REGISTER_to"];
	}	
	if ($filterNow["LAST_LOGIN_datesel"]) {
		$arFilter['LAST_LOGIN_1'] = $filterNow["LAST_LOGIN_from"];
		$arFilter['LAST_LOGIN_2'] = $filterNow["LAST_LOGIN_to"];
	}	
	if ($filterNow["DEPARTMENT_VALUE"]) {
		$headDepartmentValue = preg_replace("/[^0-9]/", '', $filterNow["DEPARTMENT_VALUE"]);
		$arFilter['UF_DEPARTMENT'] = CIntranetUtils::GetIBlockSectionChildren(intval($headDepartmentValue));
	}
	if ($filterNow["DEPARTMENTS"]) {
		if (!is_array($arFilter['UF_DEPARTMENT'])) $arFilter['UF_DEPARTMENT'] = array();
		$arFilter['UF_DEPARTMENT'] = array_merge($arFilter['UF_DEPARTMENT'], $filterNow["DEPARTMENTS"]);
	}
	if ($filterNow["WORK_POSITION"]) $arFilter['WORK_POSITION'] = '%'.$filterNow["WORK_POSITION"].'%';
	
	if ($filterNow["PERSONAL_PHONE"]) $arFilter['PERSONAL_PHONE'] = $filterNow["PERSONAL_PHONE"];   
	if ($filterNow["UF_PHONE_INNER"]) $arFilter['UF_PHONE_INNER'] = $filterNow["UF_PHONE_INNER"];
	if ($filterNow["PERSONAL_MOBILE"]) $arFilter['PERSONAL_MOBILE'] = $filterNow["PERSONAL_MOBILE"];
	if ($filterNow["EMAIL"]) $arFilter['EMAIL'] = $filterNow["EMAIL"];

	
	$dbUsers = CUser::getList(
		$by = 'CURRENT_BIRTHDAY', $order = 'ASC',
		$arFilter,
		array(
			'SELECT'     => array('UF_*'),
			'NAV_PARAMS' => array('nPageSize' => $arParams['NUM_USERS'], 'bShowAll' => false),
			'FIELDS'     => array('*', 'ID', 'PERSONAL_BIRTHDAY'),
		)
	);

	$arResult["BIRTHDAYS_NAV"] = $dbUsers->GetPageNavStringEx($navComponentObject = null, GetMessage('INTR_ISE_USERS_NAV_TITLE'));
	$arResult['CURRENT_FILTER'] = $arFilter;
	$arResult['USERS'] = array();
	while ($arUser = $dbUsers->NavNext(false))
	{
		if ($arParams['bCache'] && defined("BX_COMP_MANAGED_CACHE"))
		{
			$CACHE_MANAGER->RegisterTag('intranet_user_'.$arUser['ID']);
		}

		$arBirthDate = ParseDateTime($arUser['PERSONAL_BIRTHDAY'], CSite::GetDateFormat('SHORT'));
		if (isset($arBirthDate["M"]))
		{
			if (is_numeric($arBirthDate["M"]))
			{
				$arBirthDate["MM"] = intval($arBirthDate["M"]);
			}
			else
			{
				$arBirthDate["MM"] = GetNumMonth($arBirthDate["M"], true);
				if (!$arBirthDate["MM"])
					$arBirthDate["MM"] = intval(date('m', strtotime($arBirthDate["M"])));
			}
		}
		elseif (isset($arBirthDate["MMMM"]))
		{
			if (is_numeric($arBirthDate["MMMM"]))
			{
				$arBirthDate["MM"] = intval($arBirthDate["MMMM"]);
			}
			else
			{
				$arBirthDate["MM"] = GetNumMonth($arBirthDate["MMMM"]);
				if (!$arBirthDate["MM"])
					$arBirthDate["MM"] = intval(date('m', strtotime($arBirthDate["MMMM"])));
			}
		}
		$arUser['IS_BIRTHDAY'] = (intval($arBirthDate['MM']) == date('n', time()+CTimeZone::GetOffset())) && (intval($arBirthDate['DD']) == date('j', time()+CTimeZone::GetOffset()));

		$arUser['arBirthDate'] = $arBirthDate;

		if ($arParams['DETAIL_URL'])
			$arUser['DETAIL_URL'] = str_replace(array('#ID#', '#USER_ID#'), $arUser['ID'], $arParams['DETAIL_URL']);

		if (!$arUser['PERSONAL_PHOTO'])
		{
			switch ($arUser['PERSONAL_GENDER'])
			{
				case "M":
					$suffix = "male";
					break;
				case "F":
					$suffix = "female";
					break;
				default:
					$suffix = "unknown";
			}
			$arUser['PERSONAL_PHOTO'] = COption::GetOptionInt("socialnetwork", "default_user_picture_".$suffix, false, SITE_ID);
		}

		$arResult['USERS'][$arUser['ID']] = $arUser;
	}

	unset($dbUsers);

	if ($arParams['bCache'])
	{
		$CACHE_MANAGER->EndTagCache();
		$obCache->EndDataCache(array(
			'USERS' => $arResult['USERS'],
		));
	}
}

$this->IncludeComponentTemplate();
?>