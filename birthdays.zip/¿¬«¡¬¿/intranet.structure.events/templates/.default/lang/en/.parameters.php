<?
$MESS['INTR_ISE_TPL_PARAM_SHOW_FILTER'] = "Show Filter";
?>
