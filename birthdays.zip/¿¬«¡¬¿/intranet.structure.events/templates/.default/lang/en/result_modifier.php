<?
$MESS ['INTR_ABSC_TPL_ADD_ENTRY'] = "Add entry";
$MESS ['INTR_ABSC_TPL_EDIT_ENTRIES'] = "Management";
$MESS ['INTR_ABSC_TPL_EDIT_ENTRIES_TITLE'] = "Staff Changes Management (in the Control Panel)";
?>