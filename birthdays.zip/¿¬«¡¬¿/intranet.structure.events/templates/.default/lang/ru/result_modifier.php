<?
$MESS ['INTR_ABSC_TPL_ADD_ENTRY'] = "Добавить запись";
$MESS ['INTR_ABSC_TPL_EDIT_ENTRIES'] = "Управление";
$MESS ['INTR_ABSC_TPL_EDIT_ENTRIES_TITLE'] = "Переход в контрольную панель для управления кадровыми изменениями";
?>