<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arResult['USER_PROP'] = array();

$arParams['SHOW_FILTER'] = $arParams['SHOW_FILTER'] == 'N' ? 'N' : 'Y';
$arParams['USER_PROPERTY_LIST'] = null;

if ($arParams['SHOW_FILTER'] == 'Y') {
	$this->SetViewTarget('inside_pagetitle', 0);
		if (empty($arParams["FILTER_ID"])) $arParams["FILTER_ID"] = 'ENTRIES';
		$toolbarId = 'ENTRIES_FILTER_TOOLBAR'; 
		$APPLICATION->IncludeComponent(
			'bitrix:main.ui.filter',
			'',
			array(
				'THEME' => 'ROUNDED',
				'GRID_ID' => $arParams["FILTER_ID"],
				'FILTER_ID' => $arParams["FILTER_ID"],
				'FILTER' => $arResult["FilterFields"],
				'FILTER_FIELDS' => array(),
				'FILTER_PRESETS' => $arResult['FilterPresets'],
				'ENABLE_LIVE_SEARCH' => false,
				'RESET_TO_DEFAULT_MODE' => false,
				'ENABLE_LABEL' => true,
				'COMPACT_STATE' => true,
				'CONFIG' => array(
					'AUTOFOCUS' => false,
					'POPUP_BIND_ELEMENT_SELECTOR' => '#'.htmlspecialcharsbx($arParams["FILTER_ID"]).'_filter_container_max',
					'POPUP_OFFSET_LEFT' => 0,
					'DEFAULT_PRESET' => false
				)
			),
			$this->getComponent()
		);?>
		<style>#pagetitle-menu {margin-left: unset !important;}</style>
		<script>
			BX.ready(function(){
				var searchInput = document.querySelector("input.main-ui-filter-search-filter");
				var rounded = document.querySelector(".main-ui-filter-search.main-ui-filter-theme-rounded");
				if (rounded && searchInput) {
					var squarePreset = document.querySelector(".main-ui-filter-search-square.main-ui-square");
					if (!squarePreset && !searchInput.value) rounded.classList.add("closed");
					rounded.onclick = function() {
						if (!this.classList.contains("open")) this.classList.add("open");
					};
					searchInput.onblur = function() {
						setTimeout(function() {
							squarePreset = document.querySelector(".main-ui-filter-search-square.main-ui-square");
							var popup = document.querySelector(".popup-window.main-ui-popup-show-animation");
							popupOpen = popup && popup.style.display == "block";
							if (!squarePreset && !popupOpen && !searchInput.value) rounded.classList.remove("open");
							if (!rounded.classList.contains("closed")) rounded.classList.add("closed");					
						}, 200);
					};
				}
			});
			BX.addCustomEvent("BX.Main.Filter:apply", BX.delegate(function(eventFilterId, values, ob, filterPromise, filterParams) {
				// console.log(eventFilterId, values, ob, filterPromise, filterParams);
				if (eventFilterId == "ENTRIES") {
					setTimeout(function() {
						// document.location.reload();
						var ajaxPath = location.pathname + "?AJAX_ENTRIES=Y&IFRAME=Y" + 
											"<?=empty($_GET['PAGEN_1']) ? '' : '&PAGEN_1='.$_GET['PAGEN_1'];?>";
						// console.log(ajaxPath);
						BX.ajax({   
							url: ajaxPath,
							method: 'GET',
							dataType: 'html',
							timeout: 30,
							async: true,
							processData: true,
							scriptsRunFirst: true,
							emulateOnload: true,
							start: true,
							cache: false,
							onsuccess: function(data) {
								if (data) {
									var ajaxArea = document.querySelector("#ajax-entries-area");
									var ajaxData = data.split("<!--ajax-entries-separator-->");
									if (ajaxArea) ajaxArea.innerHTML = ajaxData[1];
								}
							},
							onfailure: function(){
								console.log('Ajax-request error.');
							}
						});
					}, 400);
				}
			}, this));
		</script>
		<div id="<?=htmlspecialcharsbx($toolbarId)?>" class="pagetitle-container pagetitle-align-right-container">
			<button id="feed_filter_button" class="ui-btn ui-btn-link ui-btn-filter-button ui-btn-themes"></button>
			<script>
				BX.ready(function() {
					var helpMesage = "Фильтр панели инструментов позволяет искать сотрудников по фамилиии или типу кадровых изменений, " + 
					"а также из модального окна выбирать другие критерии поиска.";
					BX.bind(BX('feed_filter_button'), 'click', function() {
						alert(helpMesage);
					});
				});
			</script>
		</div>
		<?
	$this->EndViewTarget();
}

$arRes = $GLOBALS["USER_FIELD_MANAGER"]->GetUserFields("USER", 0, LANGUAGE_ID);
if (!empty($arRes))
{
	foreach ($arRes as $key => $val)
	{
		$arResult['USER_PROP'][$val["FIELD_NAME"]] = ($val["EDIT_FORM_LABEL"] <> '' ? $val["EDIT_FORM_LABEL"] : $val["FIELD_NAME"]);
	}
}

if (!$arResult["AJAX_ENTRIES"] && ($arParams['SHOW_TOOLBAR_BUTTON'] == 'Y')):

	global $INTRANET_TOOLBAR;
	
	__IncludeLang(dirname(__FILE__).'/lang/'.LANGUAGE_ID.'/'.basename(__FILE__));

	$INTRANET_TOOLBAR->AddButton(array(
		'ONCLICK' => $APPLICATION->GetPopupLink(array(
			'URL' => "/bitrix/admin/iblock_element_edit.php?type=".$arParams['IBLOCK_TYPE']."&lang=".LANGUAGE_ID."&IBLOCK_ID=". $arParams['IBLOCK_ID']."&bxpublic=Y&from_module=iblock",
			'PARAMS' => array(
				'height' => 500,
				'width' => 700,
				'resize' => false
			)
		)),
		"TEXT" => GetMessage('INTR_ABSC_TPL_ADD_ENTRY'),
		"ICON" => 'add',
		"SORT" => 1000,
	));

	if (0) $INTRANET_TOOLBAR->AddButton(array(
		'HREF' => "/bitrix/admin/iblock_element_admin.php?type=".$arParams['IBLOCK_TYPE']."&lang=".LANGUAGE_ID."&IBLOCK_ID=".$arParams['IBLOCK_ID'],
		"TEXT" => GetMessage('INTR_ABSC_TPL_EDIT_ENTRIES'),
		"TITLE" => GetMessage('INTR_ABSC_TPL_EDIT_ENTRIES_TITLE'),
		'ICON' => 'settings',
		"SORT" => 1100,
	));
endif;
?>