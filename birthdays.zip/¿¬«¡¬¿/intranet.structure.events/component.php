<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!CModule::IncludeModule('intranet')) return;

$arResult["AJAX_ENTRIES"] = isset($_REQUEST["AJAX_ENTRIES"]) && ($_REQUEST["AJAX_ENTRIES"] == "Y");
unset($_GET["AJAX_ENTRIES"]);
unset($_GET["_"]);
unset($_GET["IFRAME"]);

$arParams['NUM_USERS'] = intval($arParams['NUM_USERS']);
$arParams['NUM_USERS'] = $arParams['NUM_USERS'] ? $arParams['NUM_USERS'] : 10;

InitBVar($arParams['SHOW_NAV_TOP']);
InitBVar($arParams['SHOW_NAV_BOTTOM']);

$arParams['DETAIL_URL'] = COption::GetOptionString('intranet', 'search_user_url', '/user/#ID#/');

$arParams['IBLOCK_ID'] = intval($arParams['IBLOCK_ID']);
if (!$arParams['IBLOCK_ID']) $arParams['IBLOCK_ID'] = COption::GetOptionInt('intranet', 'iblock_state_history');
if (!$arParams['IBLOCK_TYPE']) $arParams['IBLOCK_TYPE'] = COption::GetOptionString('intranet', 'iblock_type');

if(!isset($arParams["CACHE_TIME"]))
	$arParams["CACHE_TIME"] = 3600;

if (0 && $arParams['CACHE_TYPE'] == 'A')
	$arParams['CACHE_TYPE'] = COption::GetOptionString("main", "component_cache_on", "Y");

if ($arParams["NAME_TEMPLATE"] == '')
	$arParams["NAME_TEMPLATE"] = CSite::GetNameFormat();

$arParams['SHOW_LOGIN'] = $arParams['SHOW_LOGIN'] != "N" ? "Y" : "N";

if (!array_key_exists("PM_URL", $arParams))
	$arParams["~PM_URL"] = $arParams["PM_URL"] = "/company/personal/messages/chat/#USER_ID#/";
if (!array_key_exists("PATH_TO_CONPANY_DEPARTMENT", $arParams))
	$arParams["~PATH_TO_CONPANY_DEPARTMENT"] = $arParams["PATH_TO_CONPANY_DEPARTMENT"] = "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#";
if (IsModuleInstalled("video") && !array_key_exists("PATH_TO_VIDEO_CALL", $arParams))
	$arParams["~PATH_TO_VIDEO_CALL"] = $arParams["PATH_TO_VIDEO_CALL"] = "/company/personal/video/#USER_ID#/";

if (!$arParams['DATE_FORMAT']) $arParams['DATE_FORMAT'] = CComponentUtil::GetDateFormatDefault();

// for bitrix:main.user.link
$arTooltipFieldsDefault	= serialize(array(
	"EMAIL",
	"PERSONAL_MOBILE",
	"WORK_PHONE",
	"PERSONAL_ICQ",
	"PERSONAL_PHOTO",
	"PERSONAL_CITY",
	"WORK_COMPANY",
	"WORK_POSITION",
));
$arTooltipPropertiesDefault = serialize(array(
	"UF_DEPARTMENT",
	"UF_PHONE_INNER",
));

if (!array_key_exists("SHOW_FIELDS_TOOLTIP", $arParams))
	$arParams["SHOW_FIELDS_TOOLTIP"] = unserialize(COption::GetOptionString("socialnetwork", "tooltip_fields", $arTooltipFieldsDefault));
if (!array_key_exists("USER_PROPERTY_TOOLTIP", $arParams))
	$arParams["USER_PROPERTY_TOOLTIP"] = unserialize(COption::GetOptionString("socialnetwork", "tooltip_properties", $arTooltipPropertiesDefault));

if (!array_key_exists("PATH_TO_CONPANY_DEPARTMENT", $arParams))
	$arParams["PATH_TO_CONPANY_DEPARTMENT"] = "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#";

$IBLOCK_PERMISSION = CIBlock::GetPermission($arParams['IBLOCK_ID']);
$arParams['bAdmin'] = $IBLOCK_PERMISSION >= 'U';

$DEPARTMENT = intval($_REQUEST['department']);

$arParams['bCache'] = $arParams['CACHE_TYPE'] == 'Y' && $arParams['CACHE_TIME'] > 0; // && $DEPARTMENT <= 0;

CPageOption::SetOptionString("main", "nav_page_in_session", "N");

if ($arParams['bCache'])
{
	$cache_dir = '/'.SITE_ID.$this->GetRelativePath().'/'.trim(CDBResult::NavStringForCache($arParams['NUM_USERS'], false), '|');
	$cache_id = $this->GetName()
		.'|'.$arParams['NUM_USERS']
		.'|'.$arParams['IBLOCK_ID']
		.'|'.(is_array($arParams['USER_PROPERTY']) ? implode(';', $arParams['USER_PROPERTY']) : '')
		.CDBResult::NavStringForCache($arParams['NUM_USERS'], false);

	if ($DEPARTMENT)
	{
		$cache_dir .= '/'.$DEPARTMENT;
		$cache_id .= '|dpt'.$DEPARTMENT;
	}

	$obCache = new CPHPCache();
}

if ($arParams['bCache'] && $obCache->InitCache($arParams['CACHE_TIME'], $cache_id, $cache_dir))
{
	$bDataFromCache = true;
	$vars = $obCache->GetVars();

	$arResult['ENTRIES'] = $vars['ENTRIES'];
	$arResult['ENTRIES_NAV'] = $vars['ENTRIES_NAV'];
	$arResult['DEPARTMENTS'] = $vars['DEPARTMENTS'];
	$arResult['USERS'] = $vars['USERS'];
}
else
{
	$bDataFromCache = false;

	if ($arParams['bCache'])
	{
		$obCache->StartDataCache();
		global $CACHE_MANAGER;
		$CACHE_MANAGER->StartTagCache($cache_dir);
		$CACHE_MANAGER->RegisterTag('intranet_users');

		if ($DEPARTMENT)
			$CACHE_MANAGER->RegisterTag('intranet_department_'.$DEPARTMENT);
	}

	// prepare list filter
	$arFilter = array('ACTIVE' => 'Y', 'ACTIVE_DATE' => 'Y', 'IBLOCK_ID' => $arParams['IBLOCK_ID'], '!PROPERTY_USER' => false);
	$propertyManager = new \Bitrix\Iblock\Helpers\Filter\PropertyManager($arParams['IBLOCK_ID']);
	$arResult["FilterFields"] = array(
		array(
			"id" => "NAME",
			"name" => GetMessage("IBLIST_A_NAME"),
			"filterable" => "",
			"quickSearch" => "",
			"default" => true
		),
		array(
			'id' => 'PROPERTY_USER_VALUE',
			'name' => GetMessage('SONET_C30_FILTER_PROPERTY_USER'),
			'default' => true,
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_PROPERTY_USER_VALUE',
				'multiple' => 'N',
				'contextCode' => 'U',
				'enableAll' => 'N',
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'Y',
			),
		),
		array(
			'id' => 'PROPERTY_DEPARTMENT_VALUE',
			'name' => GetMessage('SONET_C30_FILTER_PROPERTY_DEPARTMENT'),
			'default' => true,
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_PROPERTY_DEPARTMENT_VALUE',
				'multiple' => 'N',
				'contextCode' => 'DR',
				'enableAll' => 'N',
				'enableDepartments' => "Y",
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'N',
				'departmentFlatEnable' => "Y",
				'enableUsers' => "N",
				'isNumeric' => "N"
			),
		),
		array(
			'id' => 'PROPERTY_STATE_ENUM_ID',
			'name' => GetMessage('SONET_C30_FILTER_PROPERTY_STATE'),
			'type' => 'list',
			'default' => false,
			'params' => array(
				'multiple' => 'N',
			),
			'items' => array(				
				'30' => GetMessage('SONET_C30_FILTER_HIRED'),
				'32' => GetMessage('SONET_C30_FILTER_FIRED'),
				'31' => GetMessage('SONET_C30_FILTER_MOVED'),
			)
		),
		array(
			"id" => "ID",
			"name" => "ID",
			"type" => "number",
			"filterable" => ""
		),
		array(
			"id" => "TIMESTAMP_X",
			"name" => GetMessage("IBLOCK_FIELD_TIMESTAMP_X"),
			"type" => "date",
			"filterable" => ""
		),
		array(
			'id' => 'MODIFIED_BY',
			'name' => GetMessage('IBLIST_A_F_MODIFIED_BY'),
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_MODIFIED_BY',
				'multiple' => 'N',
				'contextCode' => 'U',
				'enableAll' => 'N',
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'Y',
			),
		),
		array(
			"id" => "DATE_CREATE",
			"name" => GetMessage("IBLIST_A_DATE_CREATE"),
			"type" => "date",
			"filterable" => ""
		),
		array(
			'id' => 'CREATED_BY',
			'name' => GetMessage('IBLIST_A_F_CREATED_BY'),
			'type' => 'dest_selector',
			'params' => array (
				'apiVersion' => '3',
				'context' => 'FEED_FILTER_CREATED_BY',
				'multiple' => 'N',
				'contextCode' => 'U',
				'enableAll' => 'N',
				'enableSonetgroups' => 'N',
				'allowEmailInvitation' => 'N',
				'allowSearchEmailUsers' => 'N',
				'departmentSelectDisable' => 'Y',
			),
		),
		array(
			"id" => "DATE_ACTIVE_FROM",
			"name" => GetMessage("IBLIST_A_DATE_ACTIVE_FROM"),
			"type" => "date",
			"filterable" => ""
		),
		// array(
		// 	"id" => "DATE_ACTIVE_TO",
		// 	"name" => GetMessage("IBLIST_A_DATE_ACTIVE_TO"),
		// 	"type" => "date",
		// 	"filterable" => ""
		// ),
		// array(
		// 	"id" => "ACTIVE",
		// 	"name" => GetMessage("IBLIST_A_ACTIVE"),
		// 	"type" => "list",
		// 	"items" => array(
		// 		"Y" => GetMessage("IBLOCK_YES"),
		// 		"N" => GetMessage("IBLOCK_NO")
		// 	),
		// 	"filterable" => ""
		// ),
		array(
			"id" => "PREVIEW_TEXT",
			"name" => GetMessage("IBLIST_A_F_DESC"),
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "PROPERTY_POST_VALUE",
			"name" => GetMessage("IBLIST_A_PROPERTY_POST"),
			"filterable" => "",
			"quickSearch" => "",
		),
		array(
			"id" => "PROPERTY_DEPARTMENTS",
			"name" => "Отделы",
			'type' => 'list',
			'params' => array(
				'multiple' => 'Y',
			),
			'items' => $propertyManager->getFilterFields()[0]["items"],
			"filterable" => "",
		)
	);

	$arResult['FilterPresets'] = array(
		'organization' => array('fields' => array(
			'PROPERTY_DEPARTMENT_VALUE' => "1", 'PROPERTY_DEPARTMENT_VALUE_label' => "Росстат",
		), 'name' => "Росстат"),
		'hired' => array('fields' => array('PROPERTY_STATE_ENUM_ID' => "30"), 'name' => "Принятые"),
		'fired' => array('fields' => array('PROPERTY_STATE_ENUM_ID' => "32"), 'name' => "Уволенные"),
		'moved' => array('fields' => array('PROPERTY_STATE_ENUM_ID' => "31"), 'name' => "Переведённые"),
	);

	if (empty($arParams["FILTER_ID"])) $arParams["FILTER_ID"] = 'ENTRIES';
	$filterOptions = new \Bitrix\Main\UI\Filter\Options($arParams["FILTER_ID"]);
	$filterNow = $filterOptions->getFilter($arResult["FilterFields"]);
	if ($filterNow["FILTER_APPLIED"]) $arResult['FilterNow'] = $filterNow;
	if ($filterNow["FIND"]) $arFilter['SEARCHABLE_CONTENT'] = '%'.$filterNow["FIND"].'%';
	if ($filterNow["NAME"]) $arFilter['NAME'] = '%'.$filterNow["NAME"].'%';
	if ($filterNow["PREVIEW_TEXT"]) $arFilter['PREVIEW_TEXT'] = '%'.$filterNow["PREVIEW_TEXT"].'%';
	if ($filterNow["PROPERTY_POST_VALUE"]) $arFilter['PROPERTY_POST'] = '%'.$filterNow["PROPERTY_POST_VALUE"].'%';
	if ($filterNow["PROPERTY_USER_VALUE"]) 
				$arFilter['PROPERTY_USER'] = preg_replace("/[^0-9]/", '', $filterNow["PROPERTY_USER_VALUE"]);
	if ($filterNow["CREATED_BY"]) $arFilter['CREATED_BY'] = preg_replace("/[^0-9]/", '', $filterNow["CREATED_BY"]);
	if ($filterNow["MODIFIED_BY"]) $arFilter['MODIFIED_BY'] = preg_replace("/[^0-9]/", '', $filterNow["MODIFIED_BY"]);
	if ($filterNow["PROPERTY_DEPARTMENT_VALUE"]) {
		$headDepartmentValue = preg_replace("/[^0-9]/", '', $filterNow["PROPERTY_DEPARTMENT_VALUE"]);
		$arFilter['PROPERTY_DEPARTMENT'] = CIntranetUtils::GetIBlockSectionChildren(intval($headDepartmentValue));
	}
	if ($filterNow["PROPERTY_DEPARTMENTS"]) $arFilter['PROPERTY_DEPARTMENT'] = $filterNow["PROPERTY_DEPARTMENTS"];
	if ($filterNow["PROPERTY_STATE_ENUM_ID"]) $arFilter['PROPERTY_STATE'] = $filterNow["PROPERTY_STATE_ENUM_ID"];
	if ($filterNow["ID_numsel"]) $arFilter[] = array(
		"LOGIC" => "AND", 
		array('>=ID' => intval($filterNow["ID_from"])), 
		empty($filterNow["ID_to"]) ? true : array('<=ID' => intval($filterNow["ID_to"])),
	);
	if ($filterNow["TIMESTAMP_X_datesel"]) $arFilter[] = array(
		"LOGIC" => "AND", array('>=TIMESTAMP_X' => $filterNow["TIMESTAMP_X_from"]), array('<=TIMESTAMP_X' => $filterNow["TIMESTAMP_X_to"]),
	);
	if ($filterNow["DATE_CREATE_datesel"]) $arFilter[] = array(
		"LOGIC" => "AND", array('>=DATE_CREATE' => $filterNow["DATE_CREATE_from"]), array('<=DATE_CREATE' => $filterNow["DATE_CREATE_to"]),
	);
	if ($filterNow["DATE_ACTIVE_FROM_datesel"]) $arFilter[] = array(
		"LOGIC" => "AND", 
		array('>=DATE_ACTIVE_FROM' => $filterNow["DATE_ACTIVE_FROM_from"]), 
		array('<=DATE_ACTIVE_FROM' => $filterNow["DATE_ACTIVE_FROM_to"]),
	);


	$obIB = new CIBlockElement();
	$dbIB = $obIB->GetList(
	array('DATE_ACTIVE_FROM' => 'DESC'),
		$arFilter,
		false,
		array('nPageSize' => $arParams['NUM_USERS'], 'bShowAll' => false),
		array('*', 'IBLOCK_ID', 'NAME', 'PREVIEW_TEXT', 'DATE_ACTIVE_FROM', 'PROPERTY_USER', 'PROPERTY_DEPARTMENT', 'PROPERTY_POST', 'PROPERTY_STATE')
	);

	$arResult['ENTRIES'] = array();
	$arResult["ENTRIES_NAV"] = $dbIB->GetPageNavStringEx($navComponentObject=null, GetMessage('INTR_ISE_USERS_NAV_TITLE'));

	$arDepCacheValue = array();
	$arDepartmentIDs = array();
	$strUserIDs = '';
	while ($arIB = $dbIB->NavNext(false))
	{
		$strUserIDs .= ($strUserIDs == '' ? '' : '|').$arIB['PROPERTY_USER_VALUE'];
		$arDepartmentIDs[] = $arIB['PROPERTY_DEPARTMENT_VALUE'];

		$arResult['ENTRIES'][] = $arIB;
	}

	unset($dbIB);

	$arResult['USERS'] = array();
	$arResult['DEPARTMENTS'] = array();

	if ($strUserIDs != '')
	{
		$dbRes = CIBlockSection::GetList(array('SORT' => 'ASC'), array('IBLOCK_ID' => COption::GetOptionInt('intranet', 'iblock_structure'), 'ID' => array_unique($arDepartmentIDs)));
		while ($arSect = $dbRes->Fetch())
		{
			$arResult['DEPARTMENTS'][$arSect['ID']] = $arSect['NAME'];
		}
		unset($dbRes);

		$dbUsers = CUser::GetList($by = 'ID', $order = "asc", array('ID' => $strUserIDs, '!UF_DEPARTMENT' => false), array('SELECT' => array('UF_*')));
		$arUsedFields = array('PERSONAL_PHOTO', 'FULL_NAME', 'ID','LOGIN','NAME','ACTIVE','SECOND_NAME','LAST_NAME','EMAIL','DATE_REGISTER','PERSONAL_PROFESSION','PERSONAL_WWW','PERSONAL_BIRTHDAY','PERSONAL_ICQ','PERSONAL_GENDER','PERSONAL_PHONE','PERSONAL_FAX','PERSONAL_MOBILE','PERSONAL_PAGER','PERSONAL_STREET','PERSONAL_MAILBOX','PERSONAL_CITY','PERSONAL_STATE','PERSONAL_ZIP','PERSONAL_COUNTRY','WORK_PHONE','PERSONAL_NOTES','ADMIN_NOTES','XML_ID');
		while ($arUser = $dbUsers->Fetch())
		{
			if ($arParams['bCache'])
			{
				$CACHE_MANAGER->RegisterTag('intranet_user_'.$arUser['ID']);
			}

			foreach ($arUser as $key => $value)
			{
				if (!in_array($key, $arUsedFields) && !(is_array($arParams['USER_PROPERTY']) && in_array($key, $arParams['USER_PROPERTY'])))
					unset($arUser[$key]);
			}

			$arUser['IS_FEATURED'] = CIntranetUtils::IsUserHonoured($arUser['ID']);
			//$arUser['IS_ABSENT'] = CIntranetUtils::IsUserAbsent($arUser['ID']);

			$arResult['USERS'][$arUser['ID']] = $arUser;


		}
		unset($dbUsers);
	}

	if ($arParams['bCache'])
	{
		$CACHE_MANAGER->EndTagCache();
		$obCache->EndDataCache(array(
			'ENTRIES' => $arResult['ENTRIES'],
			'ENTRIES_NAV' => $arResult['ENTRIES_NAV'], // may cause problems with additional parameters in URL. we don't use $USER->GetGroups in cache id.
			'DEPARTMENTS' => $arResult['DEPARTMENTS'],
			'USERS' => $arResult['USERS'],
		));
	}
}

if (count($arResult['USERS']) > 0)
{
	foreach ($arResult['USERS'] as $USER_ID => $arUser)
	{
		$arResult['USERS'][$USER_ID]['IS_ABSENT'] = CIntranetUtils::IsUserAbsent($USER_ID);
	}
}

if ($bDataFromCache)
{
	$dbRes = CUser::GetList($by='id', $order='asc', array('ID' => implode('|', array_keys($arResult['USERS'])), '!UF_DEPARTMENT' => false, 'LAST_ACTIVITY' => 120));
	while ($arRes = $dbRes->Fetch())
	{
		$arResult['USERS'][$arRes['ID']]['IS_ONLINE'] = true;
	}
	unset($dbRes);
}

foreach ($arResult['USERS'] as $key => $arUser)
{
	if (!$bDataFromCache)
		$arResult['USERS']['IS_ONLINE'] = CIntranetUtils::IsOnline($arUser['LAST_ACTIVITY_DATE']);

	$arUser['DETAIL_URL'] = str_replace(array('#ID#', '#USER_ID#'), $arUser['ID'], $arParams['DETAIL_URL']);

	$arUser['IS_BIRTHDAY'] = CIntranetUtils::IsToday($arUser['PERSONAL_BIRTHDAY']);

	// this component is an exception for this hack - such garbage isnt't so useless here
	//$arUser['ACTIVE'] = 'Y'; // simple hack to help not to catch useless garbage to a component cache

	if (!$arUser['PERSONAL_PHOTO'])
	{
		switch ($arUser['PERSONAL_GENDER'])
		{
			case "M":
				$suffix = "male";
				break;
			case "F":
				$suffix = "female";
				break;
			default:
				$suffix = "unknown";
		}
		$arUser['PERSONAL_PHOTO'] = COption::GetOptionInt("socialnetwork", "default_user_picture_".$suffix, false, SITE_ID);
	}

	if ($arUser['PERSONAL_PHOTO'])
	{
		$arImage = CIntranetUtils::InitImage($arUser['PERSONAL_PHOTO'], 100);
		$arUser['PERSONAL_PHOTO'] = $arImage['IMG'];
	}

	$arResult['USERS'][$key] = $arUser;
}

$this->IncludeComponentTemplate();

if ($APPLICATION->GetShowIncludeAreas() && $USER->IsAdmin())
{
	// define additional icons for Site Edit mode
	$arIcons = array(
		array(
			'URL' => "javascript:".$APPLICATION->GetPopupLink(
				array(
					'URL' => "/bitrix/admin/iblock_element_edit.php?lang=".LANGUAGE_ID."&bxpublic=Y&from_module=intranet&type=".COption::GetOptionString('intranet', 'iblock_type')."&IBLOCK_ID=".COption::GetOptionInt('intranet', 'iblock_state_history')."&back_url=".urlencode($_SERVER["REQUEST_URI"]),
					'PARAMS' => array(
						'width' => 700,
						'height' => 500,
						'resize' => false,
					)
				)
			),
			'ICON' => 'bx-context-toolbar-edit-icon',
			'TITLE' => GetMessage("INTR_ISE_ICON_ADD"),
		),
	);

	$this->AddIncludeAreaIcons($arIcons);
}
?>