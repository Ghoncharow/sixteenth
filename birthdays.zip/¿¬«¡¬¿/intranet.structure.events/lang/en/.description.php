<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTR_ISE_COMPONENT_NAME'] = "Staff Changes";
$MESS ['INTR_ISE_COMPONENT_DESCR'] = "List of recent changes in company staff";
$MESS ['INTR_HR_GROUP_NAME'] = "HR";
$MESS ['INTR_EVENTS_GROUP_NAME'] = "Staff Changes";
?>
