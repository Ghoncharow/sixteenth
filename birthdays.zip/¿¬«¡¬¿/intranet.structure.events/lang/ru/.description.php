<?
$MESS ['INTR_GROUP_NAME'] = 'Корпоративный портал';
$MESS ['INTR_ISE_COMPONENT_NAME'] = 'Кадровые изменения';
$MESS ['INTR_ISE_COMPONENT_DESCR'] = 'Список последних кадровых перестановок в компании';
$MESS ['INTR_HR_GROUP_NAME'] = 'HR';
$MESS ['INTR_EVENTS_GROUP_NAME'] = 'Кадровые перестановки';
?>