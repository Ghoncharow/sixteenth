<?
$sSectionName = "Доска почета";
$arDirProperties = Array(
   "description" => "Доска почета",
   "keywords" => "board of honor"
);
?>