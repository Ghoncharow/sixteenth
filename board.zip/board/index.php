<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Доска почета");

// menu items
$menuItems = [
	[
		'TEXT' => 'Молодёжный совет',
		'URL' =>"/workgroups/group/221/",
		'ID' => 'council',
		'IS_ACTIVE' => 0,
		'COUNTER' => 0,
		'COUNTER_ID' => 'council'
	],
	[
		'TEXT' => 'Профсоюз',
		'URL' =>"/workgroups/group/342/",
		'ID' => 'union',
		'IS_ACTIVE' => 0,
		'COUNTER' => 0,
		'COUNTER_ID' => 'union'
	],
	[
		'TEXT' => 'Доска почёта',
		'URL' =>"/workgroups/board/",
		'ID' => 'board',
		'IS_ACTIVE' => 1,
		'COUNTER' => 0,
		'COUNTER_ID' => 'board'
	],
];

ob_start();
// place menu
$APPLICATION->IncludeComponent(
	'bitrix:main.interface.buttons',
	'new_menu',
	array(
		'ID' => 'sites',
		'ITEMS' => $menuItems,
		'PHP_SELF' => true,
	)
);

$html = ob_get_contents();
ob_end_clean();

$APPLICATION->AddViewContent("above_pagetitle", $html);

global $USER;
$isContentManager = $USER->IsAdmin() || in_array("9", CUser::GetUserGroup($USER->GetID()));
if ($isContentManager):
	global $INTRANET_TOOLBAR;
	?>
	<script type="text/javascript">
		function customSetTitle(title) {
			var titleBlock = document.querySelector("span.bx-core-adm-dialog-head-inner");
			if (titleBlock) titleBlock.innerHTML = title;
		}
	</script>
	<?
	
	$INTRANET_TOOLBAR->AddButton(array(
		'ONCLICK' => $APPLICATION->GetPopupLink(array(
			'URL' => "/workgroups/board/upload.php?SECTION_ID=1758",
			'PARAMS' => array(
				'height' => 500,
				'width' => 800,
				"resizable" => true
			)
		))."; customSetTitle('Добавить запись');",
		"TEXT" => 'Добавить запись',
		"TITLE" => 'Загрузить с диска фотокарточки почётных деятелей',
		"ICON" => 'add',
		"SORT" => 1000,
	));

	$INTRANET_TOOLBAR->AddButton(array(
		'ONCLICK' => $APPLICATION->GetPopupLink(array(
			'URL' => "/workgroups/board/section_edit.php?SECTION_ID=1758",
			'PARAMS' => array(
				'height' => 500,
				'width' => 630,
				"resizable" => false
			)
		))."; customSetTitle('Управление доской почета');",
		"TEXT" => 'Управление доской почета',
		"TITLE" => 'Изменить либо удалить фотокарточки',
		'ICON' => 'settings',
		"SORT" => 1100,
	));
endif;

$APPLICATION->IncludeComponent(
	"bitrix:photogallery.detail.list.ex",
	"board",
	Array(
		"ADDITIONAL_SIGHTS" => array(),
		"BEHAVIOUR" => "SIMPLE",
		"CACHE_TIME" => "3600",
		"CACHE_TYPE" => "A",
		"COMMENTS_COUNT" => "10",
		"COMMENTS_TYPE" => "forum",
		"DATE_TIME_FORMAT" => "d.m.Y",
		"DETAIL_SLIDE_SHOW_URL" => "slide_show.php?SECTION_ID=#SECTION_ID#&ELEMENT_ID=#ELEMENT_ID#",
		"DETAIL_URL" => "detail.php?SECTION_ID=#SECTION_ID#&ELEMENT_ID=#ELEMENT_ID#",
		"DISPLAY_AS_RATING" => "rating",
		"DRAG_SORT" => "Y",
		"ELEMENT_LAST_TYPE" => "none",
		"ELEMENT_SORT_FIELD" => "SORT",
		"ELEMENT_SORT_FIELD1" => "",
		"ELEMENT_SORT_ORDER" => "asc",
		"ELEMENT_SORT_ORDER1" => "asc",
		"FORUM_ID" => "12",
		"GROUP_PERMISSIONS" => array("1","12"),
		"IBLOCK_ID" => "15",
		"IBLOCK_TYPE" => "photos",
		"MAX_VOTE" => "5",
		"NAME_TEMPLATE" => "",
		"PAGE_ELEMENTS" => "3",
		"PATH_TO_SMILE" => "/bitrix/images/forum/smile/",
		"PATH_TO_USER" => "/company/personal/user/#USER_ID#",
		"PICTURES_SIGHT" => "",
		"POST_FIRST_MESSAGE" => "N",
		"PREORDER" => "N",
		"PROPERTY_CODE" => array("",""),
		"RATING_MAIN_TYPE" => "",
		"SEARCH_URL" => "search.php",
		"SECTION_ID" => "1758",
		"SET_STATUS_404" => "N",
		"SET_TITLE" => "N",
		"SHOW_COMMENTS" => "N",
		"SHOW_LOGIN" => "Y",
		"SHOW_PAGE_NAVIGATION" => "bottom",
		"SHOW_RATING" => "N",
		"SHOW_SHOWS" => "N",
		"THUMBNAIL_SIZE" => "240",
		"URL_TEMPLATES_PROFILE_VIEW" => "",
		"URL_TEMPLATES_READ" => "",
		"USE_CAPTCHA" => "N",
		"USE_COMMENTS" => "Y",
		"USE_DESC_PAGE" => "Y",
		"USE_PERMISSIONS" => "N",
		"VOTE_NAMES" => array("1","2","3","4","5","")
	)
);

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
?>