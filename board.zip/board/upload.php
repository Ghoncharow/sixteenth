<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
$APPLICATION->ShowHead(false);
$APPLICATION->SetPageProperty("tags", "доска почета");
$APPLICATION->SetTitle("Добавить запись");

$APPLICATION->IncludeComponent(
	"bitrix:photogallery.upload",
	"board",
	Array(
		"ALBUM_PHOTO_THUMBS_WIDTH" => "120",
		"IBLOCK_ID" => "15",
		"IBLOCK_TYPE" => "photos",
		"INDEX_URL" => "index.php",
		"JPEG_QUALITY" => "100",
		"JPEG_QUALITY1" => "100",
		"MODERATION" => "N",
		"ORIGINAL_SIZE" => "1280",
		"PATH_TO_FONT" => "default.ttf",
		"SECTION_ID" => "1758",
		"SECTION_URL" => "/workgroups/board/",
		"SET_TITLE" => "N",
		"THUMBNAIL_SIZE" => "90",
		"UPLOAD_MAX_FILE_SIZE" => "7",
		"USE_WATERMARK" => "Y",
		"WATERMARK_MIN_PICTURE_SIZE" => "800",
		"WATERMARK_RULES" => "USER",
		"WATERMARK_TYPE" => "BOTH"
	)
);
?>