<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
$APPLICATION->ShowHead(false);
$APPLICATION->SetPageProperty("tags", "доска почета");
$APPLICATION->SetTitle("Упраление доской почета");

$APPLICATION->IncludeComponent(
	"bitrix:photogallery.section.edit",
	"board",
	Array(
		"ACTION" => $_REQUEST["ACTION"],
		"BEHAVIOUR" => "",
		"CACHE_TIME" => "3600",
		"CACHE_TYPE" => "A",
		"DATE_TIME_FORMAT" => "d.m.Y",
		"IBLOCK_ID" => "15",
		"IBLOCK_TYPE" => "photos",
		"INDEX_URL" => "index.php",
		"SECTION_CODE" => "",
		"SECTION_ID" => "1758",
		"SECTION_URL" => "/workgroups/board/",
		"SET_STATUS_404" => "N",
		"SET_TITLE" => "N",
		"USER_ALIAS" => ""
	)
);
?>