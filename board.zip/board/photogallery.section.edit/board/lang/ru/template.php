<?
$MESS["P_ALBUM_NAME"] = "Название";
$MESS["P_ALBUM_DATE"] = "Дата";
$MESS["P_ALBUM_DESCRIPTION"] = "Описание";
$MESS["P_SUBMIT"] = "Сохранить";
$MESS["P_CANCEL"] = "Отменить";
$MESS["P_SET_PASSWORD"] = "Ограничить доступ по паролю";
$MESS["P_SET_PASSWORD_TITLE"] = "Ограничить доступ к альбому по паролю";
$MESS["P_PASSWORD"] = "Пароль";
$MESS["P_SECTION_EDIT_ICON"] = "Изменить обложку";
$MESS["P_SECTION_DELETE"] = "Удалить";
$MESS["P_EDIT_ALBUM_TITLE"] = "Свойства альбома";
$MESS["P_UNKNOWN_ERROR"] = "Произошла ошибка при сохранении";

$MESS["P_ALBUM_PHOTOS"] = "Фотографии";
$MESS['P_ALBUM_LOADED_PHOTOS'] = "Загруженные фотографии";
$MESS["P_ALBUM_PHOTOS_1"] = "(#SHOWED# из #COUNT#)";
$MESS["P_ALBUM_ALBUMS"] = "Альбомы";

$MESS['P_PHOTOS'] = "фото";
$MESS['P_SECTION_EDIT'] = "Изменить";
$MESS['P_SECTION_EDIT_TITLE'] = "Редактировать свойства альбома";
$MESS['P_SECTION_DELETE_TITLE'] = "Удалить альбом";
$MESS['P_SECTION_DELETE_ASK'] = "Вы хотите удалить альбом без возможности восстановления?";
$MESS['P_EDIT_ICON'] = "Изменить обложку";
$MESS['P_EDIT_ICON_TITLE'] = "Изменить обложку альбома";
$MESS['P_EDIT_ADD_TAGS'] = "Добавить теги";
$MESS['P_MORE_PHOTOS'] = "Еще фотографии";
$MESS['P_ROTATE_LEFT'] = "Повернуть влево";
$MESS['P_ROTATE_RIGHT'] = "Повернуть вправо";
$MESS['P_SELECT_ACT'] = "выберите";
$MESS['P_RESTORE'] = "восстановить";
$MESS['P_MOVE'] = "перенести";
$MESS['P_SELECT_ALL'] = "выделить все";
$MESS['P_DESELECT_ALL'] = "снять выделение";
$MESS['P_DEL_ITEMS_CONFIRM'] = "Вы действительно хотите удалить выбранные элементы?";
$MESS['P_MOVE_ITEMS_CONFIRM'] = "Вы действительно хотите переместить выбранные элементы?";
$MESS['P_EDIT_TAGS'] = "Редактировать теги";
$MESS['P_ADDITIONAL'] = "Дополнительные настройки";
$MESS['P_ADDITIONAL_HIDE'] = "Дополнительные настройки (скрыть)";
$MESS['P_EDIT_WHOLE_ALBUM'] = "Редактировать все фотографии альбома";

?>