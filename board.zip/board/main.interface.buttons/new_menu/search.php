<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");


if (!empty($_POST["referal"]) && CModule::IncludeModule("main")) { //Принимаем данные


        $name = strip_tags($_POST['referal']);
        $name = htmlspecialchars($name);
        $arFilter = ["NAME" => $name . "%", "ACTIVE" => "Y"];
        $dbRes = CUser::GetList($by = 'id', $order = 'asc', $arFilter, array("SELECT" => array("NAME"), "FIELDS" => array("NAME", "LAST_NAME", "SECOND_NAME", "ID")));
        while ($arRes = $dbRes->GetNext()) {
            echo "\n<li><a href='/company/personal/user/" . $arRes['ID'] . "/' target='_blank'>" . $arRes["LAST_NAME"] . " " . $arRes['NAME'] . " " . $arRes["SECOND_NAME"] . "</a></li>";
        }


}

