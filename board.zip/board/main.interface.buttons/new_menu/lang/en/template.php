<?
$MESS["MIB_MAIN_BUTTONS_MORE"] = "More";
$MESS["MIB_LICENSE_BUY_BUTTON"] = "Buy";
$MESS["MIB_LICENSE_TRIAL_BUTTON"] = "Try for free";
$MESS["MIB_LICENSE_WINDOW_HEADER_TEXT"] = "Get access";
$MESS["MIB_LICENSE_WINDOW_TEXT"] = "Buy a license or try for free";
$MESS["MIB_DROPZONE_TEXT"] = "Hide item";
$MESS["MIB_SETTING_MENU_ITEM"] = "Configure Menu";
$MESS["MIB_APPLY_SETTING_MENU_ITEM"] = "Finish customization";
$MESS["MIB_SET_HOME"] = "Set as section home page";
$MESS["MIB_SET_HIDE"] = "Hide";
$MESS["MIB_SET_SHOW"] = "Show";
$MESS["MIB_RESET_SETTINGS"] = "Reset menu";
$MESS["MIB_HIDDEN"] = "Hidden";
$MESS["MIB_MANAGE"] = "Settings";
$MESS["MIB_NO_HIDDEN"] = "Drag here to hide";
$MESS["MIB_RESET_ALERT"] = "Reset menu to default view?";
$MESS["MIB_RESET_BUTTON"] = "Reset";
$MESS["MIB_CANCEL_BUTTON"] = "Cancel";
?>