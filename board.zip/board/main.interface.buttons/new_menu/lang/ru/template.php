<?
$MESS["MIB_MAIN_BUTTONS_MORE"] = "Еще";
$MESS["MIB_LICENSE_BUY_BUTTON"] = "Купить";
$MESS["MIB_LICENSE_TRIAL_BUTTON"] = "Попробовать бесплатно";
$MESS["MIB_LICENSE_WINDOW_HEADER_TEXT"] = "Получить доступ";
$MESS["MIB_LICENSE_WINDOW_TEXT"] = "Купить лицензию или попробовать бесплатно";
$MESS["MIB_DROPZONE_TEXT"] = "Скрыть элемент";
$MESS["MIB_SETTING_MENU_ITEM"] = "Настроить меню";
$MESS["MIB_APPLY_SETTING_MENU_ITEM"] = "Завершить настройку";
$MESS["MIB_SET_HOME"] = "Сделать главной раздела";
$MESS["MIB_SET_HIDE"] = "Скрыть";
$MESS["MIB_SET_SHOW"] = "Показать";
$MESS["MIB_RESET_SETTINGS"] = "Вернуть меню по умолчанию";
$MESS["MIB_HIDDEN"] = "Скрытые";
$MESS["MIB_MANAGE"] = "Управление";
$MESS["MIB_NO_HIDDEN"] = "Перетащите сюда, чтобы скрыть";
$MESS["MIB_RESET_ALERT"] = "Сбросить меню в первоначальное состояние?";
$MESS["MIB_RESET_BUTTON"] = "Сбросить";
$MESS["MIB_CANCEL_BUTTON"] = "Отмена";
?>