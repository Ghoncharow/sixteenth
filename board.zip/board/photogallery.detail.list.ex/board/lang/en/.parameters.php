<?
$MESS["P_SHOW_PAGE_NAVIGATION"] = "Display navigation";
$MESS["P_SHOW_PAGE_NAVIGATION_NONE"] = "hide";
$MESS["P_SHOW_PAGE_NAVIGATION_TOP"] = "top";
$MESS["P_SHOW_PAGE_NAVIGATION_BOTTOM"] = "bottom";
$MESS["P_SHOW_PAGE_NAVIGATION_BOTH"] = "top and bottom";
$MESS["P_SHOW_RATING"] = "Show votes";
$MESS["P_SHOW_COMMENTS"] = "Show comment count";
$MESS["P_SHOW_SHOWS"] = "Show view count";
$MESS["P_THUMBS_SIZE"] = "Thumbnail size (px)";
$MESS["IBLOCK_MAX_VOTE"] = "Maximum Rating";
$MESS["IBLOCK_VOTE_NAMES"] = "Rating Legend";
$MESS["TP_CBIV_DISPLAY_AS_RATING"] = "Show in rating ";
$MESS["TP_CBIV_AVERAGE"] = "Average value";
$MESS["TP_CBIV_RATING"] = "Rating value";
$MESS["TP_CBIV_RATING_MAIN"] = "Rating (Kernel module)";
$MESS["RATING_MAIN_TYPE"] = "Rating buttons design (Kernel module)";
$MESS["RATING_MAIN_TYPE_CONFIG"] = "default";
$MESS["RATING_MAIN_TYPE_STANDART_TEXT"] = "Like/Unlike (text)";
$MESS["RATING_MAIN_TYPE_STANDART_GRAPHIC"] = "Like/Unlike (image)";
$MESS["RATING_MAIN_TYPE_LIKE_TEXT"] = "Like (text)";
$MESS["RATING_MAIN_TYPE_LIKE_GRAPHIC"] = "Like (image)";
?>