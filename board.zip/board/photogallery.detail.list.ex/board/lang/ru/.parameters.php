<?
$MESS ['P_SHOW_PAGE_NAVIGATION'] = "Показывать навигацию";
$MESS ['P_SHOW_PAGE_NAVIGATION_NONE'] = "не показывать";
$MESS ['P_SHOW_PAGE_NAVIGATION_TOP'] = "сверху";
$MESS ['P_SHOW_PAGE_NAVIGATION_BOTTOM'] = "снизу";
$MESS ['P_SHOW_PAGE_NAVIGATION_BOTH'] = "сверху и снизу";
$MESS ['P_SHOW_RATING'] = "Показывать голосования";
$MESS ['P_SHOW_COMMENTS'] = "Показывать количество комментариев";
$MESS ['P_SHOW_SHOWS'] = "Показывать количество показов";
$MESS['P_THUMBS_SIZE'] = "Размер фотографии-анонса (px)";
$MESS ['IBLOCK_MAX_VOTE'] = "Максимальный балл";
$MESS ['IBLOCK_VOTE_NAMES'] = "Подписи к баллам";
$MESS ['TP_CBIV_DISPLAY_AS_RATING'] = "В качестве рейтинга показывать";
$MESS ['TP_CBIV_AVERAGE'] = "Среднее значение";
$MESS ['TP_CBIV_RATING'] = "Рейтинг";
$MESS ['TP_CBIV_RATING_MAIN'] = "Рейтинг (главного модуля)";
$MESS ['RATING_MAIN_TYPE'] = "Вид кнопок рейтинга (главного модуля)";
$MESS ['RATING_MAIN_TYPE_CONFIG'] = "по умолчанию";
$MESS ['RATING_MAIN_TYPE_STANDART_TEXT'] = "Нравится / Не нравится (текстовый)";
$MESS ['RATING_MAIN_TYPE_STANDART_GRAPHIC'] = "Нравится / Не нравится (графический)";
$MESS ['RATING_MAIN_TYPE_LIKE_TEXT'] = "Мне нравится (текстовый)";
$MESS ['RATING_MAIN_TYPE_LIKE_GRAPHIC'] = "Мне нравится (графический)";
?>