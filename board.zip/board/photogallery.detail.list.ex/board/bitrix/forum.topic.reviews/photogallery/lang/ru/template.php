<?
$MESS["OPINIONS_NAME"] = "Ваше имя";
$MESS["OPINIONS_EMAIL"] = "Ваш E-Mail";
$MESS["REQUIRED_FIELD"] = "Обязательное поле";
$MESS["F_CAPTCHA_TITLE"] = "Защита от автоматических сообщений";
$MESS["F_CAPTCHA_PROMT"] = "Символы на картинке";
$MESS["JQOUTE_AUTHOR_WRITES"] = "пишет";
$MESS["JERROR_NO_TOPIC_NAME"] = "Вы должны ввести название темы. ";
$MESS["JERROR_NO_MESSAGE"] = "Вы должны ввести сообщение. ";
$MESS["JERROR_MAX_LEN"] = "Максимальная длина сообщения #MAX_LENGTH# символов. Всего символов: #LENGTH#.";
$MESS["ADD_COMMENT"] = "Добавить комментарий";
$MESS["ADD_COMMENT_TITLE"] = "Добавить комментарий (Ctrl + Enter)";
$MESS["MORE_COMMENTS"] = "Показать предыдущие комментарии";
$MESS["COMMENTS_N_FROM_M"] = "#N# из #M#";
?>