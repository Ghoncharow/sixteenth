<?
$MESS["F_FILES_COUNT"] = "Maximum number of attachments per message";
?>