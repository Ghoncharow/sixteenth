<?
$MESS["OPINIONS_NAME"] = "Your name";
$MESS["OPINIONS_EMAIL"] = "Your E-mail";
$MESS["REQUIRED_FIELD"] = "Required field";
$MESS["F_CAPTCHA_TITLE"] = "Spam bot protection (CAPTCHA)";
$MESS["F_CAPTCHA_PROMT"] = "CAPTCHA image characters";
$MESS["JQOUTE_AUTHOR_WRITES"] = "wrote";
$MESS["JERROR_NO_TOPIC_NAME"] = "Please provide message title. ";
$MESS["JERROR_NO_MESSAGE"] = "Please provide your message. ";
$MESS["JERROR_MAX_LEN"] = "Maximum message length is #MAX_LENGTH# symbols. Total symbols: #LENGTH#.";
$MESS["ADD_COMMENT"] = "Add Comment";
$MESS["ADD_COMMENT_TITLE"] = "Add comment (Ctrl + Enter)";
$MESS["MORE_COMMENTS"] = "Show other comments";
$MESS["COMMENTS_N_FROM_M"] = "#N# of #M#";
?>