<?
$PERM[".left.menu.php"]["9"]="R";
$PERM[".left.menu.php"]["10"]="X";
?>