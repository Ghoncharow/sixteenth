<?
$MESS["INTR_IS_TPL_SEARCH"] = "Find Employee";
$MESS["INTR_IS_TPL_SEARCH_DEPARTMENT"] = "Find Employee in This Department";
$MESS["INTR_IS_TPL_OUTLOOK"] = "Export Employees to Outlook";
$MESS["INTR_IS_TPL_OUTLOOK_TITLE"] = "Export Employees list as Outlook contacts";
$MESS["INTR_IS_TPL_HEAD"] = "Assign Manager";
$MESS["INTR_IS_TPL_EMPLOYEES"] = "Employees";
$MESS["INTR_IS_TPL_SUB_DEPARTMENTS"] = "Subdepartments";
$MESS["INTR_IS_TPL_SUB_DEP"] = "Department";
$MESS["INTR_IS_TPL_SUB_DEP_HEAD"] = "Supervisor";
$MESS["INTR_IS_TPL_ACTIONS"] = "Actions";
$MESS["INTR_IS_TPL_ACTION_INVITE"] = "Invite users";
$MESS["INTR_IS_TPL_ACTION_ADD_DEP"] = "Add department";
$MESS["INTR_IS_TPL_ACTION_EDIT_DEP"] = "Edit department";
$MESS["INTR_IS_TPL_ACTION_DELETE_DEP"] = "Delete department";
$MESS["ISV_confirm_delete_department"] = "Are you sure you want to delete the department? This will move all the underlying subdepartments and employees.";
?>