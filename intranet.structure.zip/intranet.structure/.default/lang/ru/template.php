<?
$MESS ['INTR_IS_TPL_SEARCH'] = "Найти сотрудника";
$MESS ['INTR_IS_TPL_SEARCH_DEPARTMENT'] = "Найти сотрудника в этом отделе";
$MESS ['INTR_IS_TPL_OUTLOOK'] = "Экспорт сотрудников в Outlook";
$MESS ['INTR_IS_TPL_OUTLOOK_TITLE'] = "Синхронизация списка сотрудников с контактами Microsoft Outlook";
$MESS ['INTR_IS_TPL_HEAD'] = "Назначить руководителя";
$MESS ['INTR_IS_TPL_EMPLOYEES'] = "Сотрудники";
$MESS ['INTR_IS_TPL_SUB_DEPARTMENTS'] = "Подотделы";
$MESS ['INTR_IS_TPL_SUB_DEP'] = "Подразделение";
$MESS ['INTR_IS_TPL_SUB_DEP_HEAD'] = "руководитель";
$MESS ['INTR_IS_TPL_ACTIONS'] = "Действия";
$MESS ['INTR_IS_TPL_ACTION_INVITE'] = "Пригласить сотрудников";
$MESS ['INTR_IS_TPL_ACTION_ADD_DEP'] = "Добавить подразделение";
$MESS ['INTR_IS_TPL_ACTION_EDIT_DEP'] = "Редактировать подразделение";
$MESS ['INTR_IS_TPL_ACTION_DELETE_DEP'] = "Удалить подразделение";
$MESS ['ISV_confirm_delete_department'] = "Удалить подразделение? Все нижележащие подразделения и сотрудники будут перенесены.";
?>