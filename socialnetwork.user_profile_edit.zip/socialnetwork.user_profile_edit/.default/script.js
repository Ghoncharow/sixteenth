BX.namespace("BX.Socialnetwork.User");

BX.Socialnetwork.User.ProfileEdit =
    {
        init: function ()
        {
            this.popupHint = {};

            BX.ready(BX.delegate(function(){
                if (BX.type.isDomNode(BX("group_admin_hint")))
                {
                    this.initHint('group_admin_hint');
                }
            }, this));
        },

        initHint : function(nodeId)
        {
            var node = BX(nodeId);
            if (node)
            {
                node.setAttribute('data-id', node);
                BX.bind(node, 'mouseover', BX.proxy(function(){
                    var id = BX.proxy_context.getAttribute('data-id');
                    var text = BX.proxy_context.getAttribute('data-text');
                    this.showHint(id, BX.proxy_context, text);
                }, this));
                BX.bind(node, 'mouseout',  BX.proxy(function(){
                    var id = BX.proxy_context.getAttribute('data-id');
                    this.hideHint(id);
                }, this));
            }
        },

        showHint : function(id, bind, text)
        {
            if (this.popupHint[id])
            {
                this.popupHint[id].close();
            }

            this.popupHint[id] = new BX.PopupWindow('user-profile-email-hint', bind, {
                lightShadow: true,
                autoHide: false,
                darkMode: true,
                offsetLeft: 0,
                offsetTop: 2,
                bindOptions: {position: "top"},
                zIndex: 200,
                events : {
                    onPopupClose : function() {this.destroy()}
                },
                content : BX.create("div", { attrs : { style : "padding-right: 5px; width: 250px;" }, html: text})
            });
            this.popupHint[id].setAngle({offset:13, position: 'bottom'});
            this.popupHint[id].show();

            return true;
        },

        hideHint : function(id)
        {
            this.popupHint[id].close();
            this.popupHint[id] = null;
        }
    };

function checkBirthDay(){
    if(
        (document.getElementById("PERSONAL_BIRTHDAY_DAY").value &&
            document.getElementById("PERSONAL_BIRTHDAY_MONTH").value) &&
        BX("PERSONAL_BIRTHDAY_YEAR", true).value != 'Год')
        return false;
    return true;
}

function formCustomSubmit(e){

	if(
	(document.getElementById("PERSONAL_BIRTHDAY_DAY").value ||
	document.getElementById("PERSONAL_BIRTHDAY_MONTH").value) &&
		BX("PERSONAL_BIRTHDAY_YEAR", true).value == 'Год'){
	
	
	
console.log("Не заполен год рождения");
	alert("Не заполен год рождения");
	return false;
	}

	process_tags();

}

function process_tags() {



    var tags = document.getElementById('saved-tags');
    var tagsArray = document.getElementsByClassName('tag');
    tags.value = getTagsString(tagsArray);
    var newTagsString = getTagsString(document.getElementsByClassName('new-tag'));
    console.log(newTagsString);
    if (newTagsString.length != 0) {
        $.getJSON('/bitrix/templates/bitrix24/utilites/search-tags/ajax.php', {
            action: 'push-new-tags',
            tags: newTagsString,
            type: 'lg'
        }, function () {
        });
    }
    //console.log(newTags);
}

function getTagsString(tagsArr) {
    var inputedText = document.getElementsByClassName('search-tags')[0].value;
    var tagsString = inputedText.length > 1 ? inputedText + ", " : "";
    var NOT = tagsArr.length;
    for (var i = 0; i < NOT; i++) {
        tagsString += tagsArr[i].textContent + (i < NOT - 1 ? ", " : "");
    }
    return tagsString;
}