<? require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
if ($_GET['action'] && $_GET['action'] == 'push-new-tags') {
    $tagsArray = explode(", ", $_GET['tags']);

    $UID = $USER->GetID();
	
	global $DB;
 
        foreach ($tagsArray as $i => $tag) {
            $query = "INSERT INTO dbroskazna.b_search_tags (SEARCH_CONTENT_ID, SITE_ID, NAME) VALUES (" . $UID . ", '" . $_GET['type'] . "', '" . $tag . "');";
            $DB->Query($query);
        }
}