<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
// CJSCore::Init(array('fx'));

$currentPath = str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);
$APPLICATION->AddHeadScript($currentPath."/script24.js", true);
$APPLICATION->SetAdditionalCSS($currentPath."/style24.css", true);
CJSCore::Init(array('jquery2', 'socnetlogdest', 'popup', 'fx', 'ui_date', 'date'));
// echo '<script type="text/javascript">console.log('.json_encode($currentPath).');</script>';

$APPLICATION->SetPageProperty("BodyClass", "page-one-column");

$admins = [1, 13];
$techSupport = [7];
$HR = [9];
$TM = [10];


if ($arResult["User"]['EXTERNAL_AUTH_ID'] == 'email') {
    $arFields = array(
        'MAIN' => array(
            'LAST_NAME', 'NAME', 'SECOND_NAME', 'PERSONAL_PHOTO', "UF_DEPARTMENT"
        ),

        'PERSONAL' => array(),
    );
} elseif ($bBitrix24) {
    $arFields = array(
        'MAIN' => array(
            'LAST_NAME', 'NAME', 'SECOND_NAME', 'PERSONAL_PHOTO', 'PERSONAL_PHONE', 'PERSONAL_MOBILE', 'WORK_PHONE', 'UF_PHONE_INNER', 'WORK_POSITION', 'GROUP_ID',"UF_DEPARTMENT"
        ),

        'PERSONAL' => array(
            'AUTO_TIME_ZONE', 'TIME_ZONE', 'PERSONAL_WWW', 'PERSONAL_CITY', 'WORK_COMPANY', 'PERSONAL_GENDER', 'PERSONAL_BIRTHDAY',
            'UF_SKYPE', "UF_TWITTER", "UF_FACEBOOK", "UF_LINKEDIN", "UF_XING", 'UF_WEB_SITES', 'UF_SKILLS', 'US_INTERESTS'
        ),
    );
    if (CModule::IncludeModule("socialservices")) {
        if ($bNetwork) {
            $arFields = array_merge(array('SOCSERV' => array('SOCSERVICES')), $arFields);
        } else {
            $arFields['SOCSERV'] = array('SOCSERVICES');
        }
    }
} else {
    $arFields = array(
        'MAIN' => array(
            'LAST_NAME', 'SECOND_NAME', 'NAME', 'PERSONAL_PHOTO', 'PERSONAL_PHONE', 'PERSONAL_MOBILE', 'WORK_PHONE', 'UF_PHONE_INNER', 'WORK_POSITION', 'GROUP_ID', 'AUTO_TIME_ZONE', 'TIME_ZONE', 'PERSONAL_WWW', 'PERSONAL_CITY', 'PERSONAL_GENDER', 'PERSONAL_BIRTHDAY', 'PERSONAL_BIRTHDATE',
            'UF_SKYPE', "UF_TWITTER", "UF_FACEBOOK", "UF_LINKEDIN", "UF_XING", 'UF_WEB_SITES',
            'PERSONAL_ICQ', 'PERSONAL_FAX', 'PERSONAL_PAGER', 'PERSONAL_COUNTRY', 'UF_ADDRESS', 'UF_CABINET', 'PERSONAL_MAILBOX', 'PERSONAL_CITY', 'PERSONAL_STATE', 'PERSONAL_ZIP', 'WORK_COUNTRY',
            'WORK_CITY', 'WORK_COMPANY', 'WORK_DEPARTMENT', 'WORK_PROFILE', 'WORK_WWW', 'WORK_FAX', 'WORK_PAGER', 'WORK_LOGO', 'PERSONAL_PROFESSION',
        ),

        'PERSONAL' => array(
            'UF_SKILLS', 'US_INTERESTS', 'UF_LANGS'
        ),
    );
    if (CModule::IncludeModule("socialservices"))
        $arFields['SOCSERV'] = array('SOCSERVICES');
}


$bBitrix24 = IsModuleInstalled("bitrix24");
$bNetwork = $bBitrix24 && COption::GetOptionString('bitrix24', 'network', 'N') == 'Y';

if (
    $arParams['IS_FORUM'] == 'Y'
    && $arResult["User"]['EXTERNAL_AUTH_ID'] != 'email'
) {
    $arFields['PERSONAL'][] = 'FORUM_SHOW_NAME';
}

if (LANGUAGE_ID != "ru" && LANGUAGE_ID != "ua") {
    unset($arFields["MAIN"][array_search("SECOND_NAME", $arFields["MAIN"])]);
    unset($arFields["PERSONAL"][array_search("PERSONAL_GENDER", $arFields["PERSONAL"])]);
}

$arSocialFieldsAll = array('UF_TWITTER', 'UF_FACEBOOK', 'UF_LINKEDIN', 'UF_XING');
$arSocialFields = array();

foreach ($arParams['EDITABLE_FIELDS'] as $FIELD) {
    $bFound = false;
    if ($arResult['USER_PROP'][$FIELD]) {
        foreach ($arFields as $FIELD_TYPE => $arTypeFields) {
            if (in_array($FIELD, $arFields[$FIELD_TYPE])) {
                $arFields[$FIELD_TYPE][] = $FIELD;
                $bFound = true;
                break;
            }
        }

        if (
            !$bFound
            && !$arResult["User"]["IS_EMAIL"]
        ) {
            $arFields['PERSONAL'][] = $FIELD;
        }
    }

    if (in_array($FIELD, $arSocialFieldsAll))
        $arSocialFields[] = $FIELD;
}

$UF_DEP = array_search('UF_DEPARTMENT', $arFields['MAIN']);
if ($arResult["User"]["IS_EXTRANET"] && $UF_DEP)
    unset($arFields['MAIN'][$UF_DEP]);

if ($arResult["User"]["IS_EXTRANET"] && in_array("UF_DEPARTMENT", $arParams['EDITABLE_FIELDS'])) {
    //$key = array_search("UF_DEPARTMENT", $arParams['EDITABLE_FIELDS']);
    //if ($key !== false)
    //    unset($arParams['EDITABLE_FIELDS'][$key]);
}

$GROUP_ACTIVE = false;

foreach ($arFields as $GROUP => $arGroupFields) {
    $arFields[$GROUP] = array_unique($arGroupFields);

    foreach ($arGroupFields as $fkey => $FIELD) {
        if (!in_array($FIELD, $arParams['EDITABLE_FIELDS'])) {
            unset($arGroupFields[$fkey]);
        } elseif (!$GROUP_ACTIVE)
            $GROUP_ACTIVE = $GROUP;
    }

    $arFields[$GROUP] = array_unique($arGroupFields);
}


if (count($arSocialFields) > 0) {
    $SocNetProfileExample = array(
        "UF_TWITTER" => "your_account",
        "UF_FACEBOOK" => "http://www.facebook.com/your_profile",
        "UF_XING" => "http://www.xing.com/profile/your_profile",
        "UF_LINKEDIN" => "http://www.linkedin.com/profile/view?id=your_id"
    );
    $sonetLinkAddShow = false;
    foreach ($arSocialFields as $key => $val) {
        if (!($arResult['User'][$val])) {
            $sonetLinkAddShow = true;
            break;
        }
    }
}

if ($arResult['ERROR_MESSAGE']) {
    ?>
    <div class="content-edit-form-notice-error"><span class="content-edit-form-notice-text"><span
                class="content-edit-form-notice-icon"></span><?= $arResult['ERROR_MESSAGE'] ?></span></div>
    <?
}
?>

<form onsubmit="formCustomSubmit()" id="bx_user_profile_form" name="user_profile_edit" method="POST"
      action="<? echo POST_FORM_ACTION_URI; ?>"
      enctype="multipart/form-data" autocomplete="off">
    <? if (array_search("PERSONAL_GENDER", $arFields["PERSONAL"]) === false): ?><input type="hidden"
                                                                                       name="PERSONAL_GENDER"
                                                                                       value="<?= $arResult["User"]["PERSONAL_GENDER"] ?>" /><? endif ?>
    <input type="hidden" name="MAX_FILE_SIZE" value="2000000"/>
    <input type="hidden" name="LOGIN" value="<?= $arResult['User']["LOGIN"] ?>"/>
    <? echo bitrix_sessid_post() ?>
    <table id="content-edit-form-1" class="content-edit-form" cellspacing="0" cellpadding="0">
        <tbody class="flex-body">


        <?
        $headerCount = 1;
        foreach ($arFields as $GROUP_ID => $arGroupFields):
            $groupMsg = "SOCNET_SUPE_TPL_GROUP_" . $GROUP_ID;
            $additionalClassName = "";
            if ($bNetwork && $GROUP_ID == "SOCSERV") {
                $groupMsg = "SOCNET_SUPE_TPL_GROUP_AUTH";
                $additionalClassName = 'content-edit-form-header-wrap-blue';
            } elseif ($GROUP_ID == "MAIN") {
                $additionalClassName = "content-edit-form-header-wrap-blue";
            }

            if (!empty($arGroupFields)) {
                ?><tr><td style="width: 100%">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>

                <tr class="header<?= $headerCount++; ?>">
                    <td class="content-edit-form-header content-edit-form-header-first content-edit-form-header-wrap <?= $additionalClassName; ?>" colspan="3">
                        <?= GetMessage($groupMsg) ?>
                    </td>
                </tr>
                <tr><td style="width: 100%">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>

                <?
            }

            if ($GROUP_ID == "MAIN"):?>
                <? if (in_array('PASSWORD', $arParams['EDITABLE_FIELDS'])) {
                    if (array_intersect((array_merge($admins, $techSupport)), $USER->GetUserGroupArray())) { ?>
                        <tr class="change-pass">
                        <td class="content-edit-form-field-name"></td>
                        <td class="content-edit-form-event-link" colspan="2"><a href="#showPassword"
                                                                                onclick="return bxUpeToggleHiddenField('content-edit-form-1', 'password')"
                                                                                class="content-edit-form-event-link-tag"><span
                                    class="content-edit-form-event-link-icon content-edit-form-icons content-edit-form-icon-password"></span><span
                                    class="content-edit-form-event-link-name"><?= GetMessage("SOCNET_CHANGE_PASSWORD") ?></span></a>
                        </td>
                        </tr><?
                    } ?>
                    <tr data-field-id="password" style="display:none">
                        <td class="content-edit-form-field-name"><?= GetMessage("ISL_PASSWORD_NEW") ?></td>
                        <td class="content-edit-form-field-input">
                            <input type="password" style="display: none; ">
                            <input name="PASSWORD" autocomplete="new-password" type="password"
                                   class="content-edit-form-field-input-text"/>
                            <div style="color: rgb(181, 178, 178); font-size: 11px; line-height: 1.5"><?= $arResult["User"]["PASSWORD_REQUIREMENTS"] ?></div>
                        </td>
                        <td class="content-edit-form-field-error"></td>
                    </tr>
                    <tr data-field-id="password" style="display:none">
                    <td class="content-edit-form-field-name"><?= GetMessage("ISL_CONFIRM_PASSWORD") ?></td>
                    <td class="content-edit-form-field-input"><input name="CONFIRM_PASSWORD" autocomplete="off"
                                                                     type="password"
                                                                     class="content-edit-form-field-input-text"/>
                    </td>
                    <td class="content-edit-form-field-error"></td>
                    </tr><?
                }
                if (in_array('EMAIL', $arParams['EDITABLE_FIELDS'])) { ?>
                    <tr class="email">
                    <td class="content-edit-form-field-name"><?= $bNetwork ? GetMessage("ISL_EMAIL_CONTACT") : GetMessage("ISL_EMAIL"); ?></td>
                    <td class="content-edit-form-field-input">
                        <? if (array_intersect((array_merge($admins, $techSupport)), $USER->GetUserGroupArray())) { ?>
                            <input type="text" name="EMAIL" value="<?= $arResult['User']["EMAIL"] ?>"
                                   class="content-edit-form-field-input-text"/>

                        <? } else { ?>
                            <input type="hidden" name="EMAIL" value="<?= $arResult['User']["EMAIL"] ?>">
                            <span><?= $arResult['User']["EMAIL"] ?></span>
                        <? } ?>

                    </td>
                    <td class="content-edit-form-field-error">&nbsp;</td>
                    </tr><?
                }
                $extmailAvailable = CModule::IncludeModule('intranet') && CIntranetUtils::IsExternalMailAvailable();
                $extmailConfigPath = \Bitrix\Main\Config\Option::get('intranet', $arParams['ID'] == $USER->getId() ? 'path_mail_config' : 'path_mail_manage');
                if (
                    !$arResult["User"]["IS_EMAIL"]
                    && (
                        !empty($arResult['User']['MAILBOX'])
                        || (
                            $extmailAvailable
                            && !empty($extmailConfigPath)
                            && (
                                $arParams['ID'] == $USER->getID()
                                || $USER->isAdmin()
                                || $USER->canDoOperation('bitrix24_config')
                            )
                        )
                    )
                ) { ?>
                    <tr class="email">
                        <td class="content-edit-form-field-name"><?= GetMessage('ISL_EXTMAIL'); ?></td>
                        <td class="content-edit-form-field-input">
                            <? if (!empty($arResult['User']['MAILBOX'])) echo $arResult['User']['MAILBOX']; ?>
                            <? if ($arParams['ID'] == $USER->getId() || $USER->isAdmin() || $USER->canDoOperation('bitrix24_config')): ?>
                                <? if (!empty($extmailConfigPath)): ?><a
                                    href="<?= htmlspecialcharsbx($extmailConfigPath) ?>"><?= getMessage('ISL_EXTMAIL_EDIT') ?></a><? endif ?>
                            <? endif ?>
                        </td>
                        <td class="content-edit-form-field-error"></td>
                    </tr>
                <? } ?>
            <? endif;?>
            <? foreach ($arGroupFields as $FIELD):
            if ($FIELD == "FORUM_SHOW_NAME") {
                ?>
                <tr>
                <td><input type="hidden" name="<?
                    echo $FIELD ?>" value="Y"/></td></tr><?
                continue;
            }
            $value = $arResult['User'][$FIELD]; ?>
            <tr <? if ($bBitrix24 && (in_array($FIELD, array("UF_TWITTER", "UF_FACEBOOK", "UF_LINKEDIN", "UF_XING")) || in_array($FIELD, array("PERSONAL_MOBILE", "WORK_PHONE", "UF_PHONE_INNER"))) && empty($value) || $FIELD == "GROUP_ID" && $arResult["User"]["IS_EXTRANET"]): ?>style="display:none"<? endif;
            ?>
                data-role="<?= $FIELD ?>"<?= ($FIELD == "TIME_ZONE" ? " data-field-id=\"time_zone\" style=\"display: " . ($arResult["User"]["AUTO_TIME_ZONE"] <> "N" ? "none" : "table-row") . ";\"" : "") ?>
                class="<?= $FIELD ?>"<?= ($FIELD == "TIME_ZONE" ? " data-field-id=\"time_zone\" style=\"display: " . ($arResult["User"]["AUTO_TIME_ZONE"] <> "N" ? "none" : "table-row") . ";\"" : "") ?>>
                <? if (!$bNetwork || $GROUP_ID !== "SOCSERV"): ?>

                <? endif; ?>
                <?
                switch ($FIELD) {
                    case "PASSWORD":
                    case "CONFIRM_PASSWORD":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        break;
                    case "AUTO_TIME_ZONE":
                        if (array_intersect((array_merge($admins, $techSupport)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input" colspan="2">
                            <select name="AUTO_TIME_ZONE"
                                    onchange="this.form.TIME_ZONE.disabled=(this.value != 'N'); bxUpeToggleHiddenField('content-edit-form-1', 'time_zone', (this.value == 'N'));"
                                    class="content-edit-form-field-input-select">
                                <option value=""><?
                                    echo GetMessage("soc_profile_time_zones_auto_def") ?></option>
                                <option value="Y"<?= ($value == "Y" ? ' SELECTED="SELECTED"' : '') ?>><?
                                    echo GetMessage("soc_profile_time_zones_auto_yes") ?></option>
                                <option value="N"<?= ($value == "N" ? ' SELECTED="SELECTED"' : '') ?>><?
                                    echo GetMessage("soc_profile_time_zones_auto_no") ?></option>
                            </select>
                            </td><?
                        }
                        break;
                    case 'TIME_ZONE':
                        if (array_intersect((array_merge($admins, $techSupport)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                            ?>
                            <td class="content-edit-form-field-input" colspan="2">
                            <select name="TIME_ZONE"<?
                            if ($arResult["User"]["AUTO_TIME_ZONE"] <> "N") echo '  disabled="disabled"' ?>
                                    class="content-edit-form-field-input-select">
                                <?
                                if (is_array($arResult["TIME_ZONE_LIST"]) && !empty($arResult["TIME_ZONE_LIST"])): ?>
                                    <?
                                    foreach ($arResult["TIME_ZONE_LIST"] as $tz => $tz_name): ?>
                                        <option value="<?= htmlspecialcharsbx($tz) ?>"<?= ($value == $tz ? ' SELECTED="SELECTED"' : '') ?>><?= htmlspecialcharsbx($tz_name) ?></option>
                                    <? endforeach ?>
                                <? endif ?>
                            </select>
                            </td><?
                        }
                        break;
                    case 'PERSONAL_COUNTRY':
                    case 'WORK_COUNTRY':
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) { ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input" colspan="2">
                            <?
                            echo SelectBoxFromArray($FIELD, GetCountryArray(), $value, GetMessage("ISL_COUNTRY_EMPTY"), "class=\"content-edit-form-field-input-select\""); ?>
                            </td><?
                        }
                        break;
                    case 'SOCSERVICES':
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        if (CModule::IncludeModule("socialservices")):
                            ?>
                            <td class="content-edit-form-field-input" colspan="<?= $bNetwork ? 3 : 2 ?>">
                                <div class="bx-sonet-profile-field-socserv">
                                    <?
                                    $APPLICATION->IncludeComponent("bitrix:socserv.auth.split", $bNetwork ? "network" : "twitpost", array(
                                        "SHOW_PROFILES" => "Y",
                                        "CAN_DELETE" => "Y",
                                        "USER_ID" => $arParams['ID']
                                    ),
                                        false
                                    );
                                    ?>
                                </div>
                            </td>
                        <?
                        endif;
                        break;
                    case "PERSONAL_GENDER":
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input" colspan="2">
                            <div><label><input type="radio" name="<?
                                    echo $FIELD ?>" value="M"<?
                                    echo $value == 'M' ? ' checked="checked"' : '' ?>
                                               class="content-edit-form-field-input-selector"/><span
                                        class="content-edit-form-field-input-selector-name"><?
                                        echo GetMessage('ISL_PERSONAL_GENDER_MALE') ?></span></label></div>
                            <div><label><input type="radio" name="<?
                                    echo $FIELD ?>" value="F"<?
                                    echo $value == 'F' ? ' checked="checked"' : '' ?>
                                               class="content-edit-form-field-input-selector"/><span
                                        class="content-edit-form-field-input-selector-name"><?
                                        echo GetMessage('ISL_PERSONAL_GENDER_FEMALE') ?></span></label></div>
                            </td><?
                        }
                        break;

                    case "PERSONAL_PHOTO":
                    case "WORK_LOGO":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2"><?
                        $APPLICATION->IncludeComponent('bitrix:main.file.input', 'drag_n_drop', array(
                            'INPUT_NAME' => $FIELD . '_ID',
                            'INPUT_NAME_UNSAVED' => $FIELD . '_ID_UNSAVED',
                            'CONTROL_ID' => $FIELD . '_IMAGE_ID',
                            'INPUT_VALUE' => $arResult["User"][$FIELD . "_FILE"]["ID"],
                            'MULTIPLE' => 'N',
                            'ALLOW_UPLOAD' => 'I',
                            'INPUT_CAPTION' => GetMessage("ISL_ADD_PHOTO"),
                            'SHOW_AVATAR_EDITOR' => 'Y'
                        )); ?>
                        </td><?
                        break;

                    case 'PERSONAL_BIRTHDAY':
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        $birthday = ParseDateTime($value);
                        $day = is_array($birthday) ? intval($birthday["DD"]) : "";
                        $month = is_array($birthday) ? intval($birthday["MM"]) : "";
                        $year = is_array($birthday) ? intval($birthday["YYYY"]) : "";
                        ?>
                        <td class="content-edit-form-field-input" colspan="2">
                            <?
                            $daySelect = '<select class="content-edit-form-field-input-select" id="PERSONAL_BIRTHDAY_DAY" name="PERSONAL_BIRTHDAY_DAY" onchange="onPersonalBirthdayChange(event)" onblur="onPersonalBirthdayChange(event)">';
                            $daySelect .= '<option value="">' . GetMessage("ISL_BIRTHDAY_DAY") . '</option>';
                            for ($i = 1; $i <= 31; $i++)
                                $daySelect .= '<option' . ($day == $i ? ' selected="selected"' : '') . ' value="' . $i . '">' . $i . '</option>';
                            $daySelect .= '</select>';

                            if (LANGUAGE_ID != "en")
                                echo $daySelect;
                            ?>
                            <select class="content-edit-form-field-input-select" id="PERSONAL_BIRTHDAY_MONTH"
                                    name="PERSONAL_BIRTHDAY_MONTH" onchange="onPersonalBirthdayChange(event)"
                                    onblur="onPersonalBirthdayChange(event)">
                                <option value=""><?= GetMessage("ISL_BIRTHDAY_MONTH") ?></option>
                                <? for ($i = 0; $i <= 11; $i++): ?>
                                    <option<? if ($month == ($i + 1)): ?> selected="selected"<? endif ?>
                                        value="<?= $i ?>"><?= GetMessage("MONTH_" . ($i + 1)) ?></option>
                                <? endfor ?>
                            </select>
                            <? if (LANGUAGE_ID == "en")
                                echo $daySelect;
                            ?>
                            <input type="text"
                                   class="content-edit-form-field-input-text content-edit-form-field-input-bd"
                                   value="<?= ($year > 0 ? $year : GetMessage("ISL_BIRTHDAY_YEAR")) ?>"
                                   onclick="this.setAttribute('data-focus', 'true'); if (this.value == '<?= GetMessage("ISL_BIRTHDAY_YEAR") ?>') { this.value = '';}"
                                   maxlength="4" id="PERSONAL_BIRTHDAY_YEAR" name="PERSONAL_BIRTHDAY_YEAR"
                                   onkeyup="onPersonalBirthdayChange(event)"
                                   onblur="this.setAttribute('data-focus', 'false'); if (!BX.type.isNumber(parseInt(this.value))) this.value='<?= GetMessage("ISL_BIRTHDAY_YEAR") ?>'; onPersonalBirthdayChange(event)"/>
                            <input type="hidden" id="PERSONAL_BIRTHDAY_VALUE" name="PERSONAL_BIRTHDAY"
                                   value="<?= $value ?>"/>

                            <script type="text/javascript">
                                function onPersonalBirthdayChange(event) {
                                    var daySelect = BX("PERSONAL_BIRTHDAY_DAY", true);
                                    var monthSelect = BX("PERSONAL_BIRTHDAY_MONTH", true);
                                    var yearTextbox = BX("PERSONAL_BIRTHDAY_YEAR", true);
                                    var birthdayHidden = BX("PERSONAL_BIRTHDAY_VALUE", true)

                                    var day = daySelect.selectedIndex != -1 ? parseInt(daySelect.options[daySelect.selectedIndex].value) : "";
                                    var month = monthSelect.selectedIndex != -1 ? parseInt(monthSelect.options[monthSelect.selectedIndex].value) : "";
                                    var year = parseInt(yearTextbox.value);

                                    var date = null;

                                    if (BX.type.isNumber(day) && BX.type.isNumber(month) && BX.type.isNumber(year) && (date = new Date(Date.UTC(year, month, day)))) {
                                        birthdayHidden.value = BX.message("FORMAT_DATE")
                                            .replace(/YYYY/ig, date.getUTCFullYear())
                                            .replace(/MM/ig, BX.util.str_pad_left((date.getUTCMonth() + 1).toString(), 2, "0"))
                                            .replace(/DD/ig, BX.util.str_pad_left(date.getUTCDate().toString(), 2, "0"))
                                            .replace(/HH/ig, BX.util.str_pad_left(date.getUTCHours().toString(), 2, "0"))
                                            .replace(/MI/ig, BX.util.str_pad_left(date.getUTCMinutes().toString(), 2, "0"))
                                            .replace(/SS/ig, BX.util.str_pad_left(date.getUTCSeconds().toString(), 2, "0"));

                                        yearTextbox.style.borderColor = "";
                                    }
                                    else {
                                        birthdayHidden.value = "";
                                        var eventType = event.type;
                                        setTimeout(function () {
                                            if (eventType == "blur" && BX.type.isNumber(day) && BX.type.isNumber(month) && !BX.type.isNumber(year) && yearTextbox.getAttribute("data-focus") != "true")
                                                yearTextbox.style.borderColor = "red";
                                            else
                                                yearTextbox.style.borderColor = "";
                                        }, 500);
                                    }
                                }

                            </script>
                        </td> <?
                        break;
                    case 'GROUP_ID':
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2">
                        <?
                        if (!$arResult["User"]["IS_EXTRANET"]):?>
                            <div class="content-edit-form-field-input-sub">
                                <label style="display: inline-block;">
                                    <input
                                        type="checkbox"
                                        class="content-edit-form-field-input-selector"
                                        id="group_admin"
                                        name="GROUP_ID[]"
                                        <?
                                        if ($arResult["IsMyProfile"]):?>
                                            readonly
                                            onclick="return false"
                                        <? else: ?>
                                            onchange="modifyGroups()"
                                        <? endif; ?>
                                        value="1"
                                        <?
                                        if ($arResult['User']['IS_ADMIN']) echo "checked"; ?>
                                        <?
                                        if (
                                            $arResult['User']['ACTIVE'] != "Y"
                                            || $arResult["IS_BITRIX24"] && $arResult["ADMIN_RIGHTS_RESTRICTED"]
                                            && (
                                                $arResult["User"]["IS_INVITED"]
                                                || in_array($arResult["User"]["EXTERNAL_AUTH_ID"], array("email", "replica", "imconnector", "bot", "__controller"))
                                            )
                                        )
                                            echo "disabled"; ?>
                                    />
                                    <span class="content-edit-form-field-input-selector-name"><?= GetMessage("ISL_GROUP_ADMIN") ?></span>
                                    <?
                                    if (
                                    $arResult["IS_BITRIX24"]
                                    && $arResult["ADMIN_RIGHTS_RESTRICTED"]
                                    ):
                                    ?>
                                    <div style="display: none">
                                        <div id="adminRestrContent">
                                            <?
                                            if ($arResult["IS_COMPANY_TARIFF"]):?>
                                                <div style="padding-bottom: 20px;"><?= GetMessage("SOCNET_RIGHTS_RESTR_COMPANY_TEXT") ?></div>
                                            <? else: ?>
                                                <div style='font-size: 20px; padding-bottom: 20px;'><?= GetMessage("SOCNET_RIGHTS_RESTR_TEXT1") ?></div>
                                                <div style='padding-bottom: 20px;'><?= GetMessage("SOCNET_RIGHTS_RESTR_TEXT2") ?></div>
                                                <table width='100%'>
                                                    <tr align='center' style='font-weight: bold'>
                                                        <td><?= GetMessage("SOCNET_TARIFF_PROJECT") ?></td>
                                                        <td><?= GetMessage("SOCNET_TARIFF_TF") ?></td>
                                                        <td><?= GetMessage("SOCNET_TARIFF_TEAM") ?></td>
                                                        <td><?= GetMessage("SOCNET_TARIFF_COMPANY") ?></td>
                                                    </tr>
                                                    <tr align='center'>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>5</td>
                                                        <td><?= GetMessage("SOCNET_UNLIM") ?></td>
                                                    </tr>
                                                </table>
                                                <br>
                                                <div><?= GetMessage("SOCNET_RIGHTS_RESTR_TEXT3") ?></div>
                                            <? endif ?>
                                        </div>
                                    </div>
                                </label>
                                <span class="tariff-lock" style="padding-left: 15px"
                                      onclick="B24.licenseInfoPopup.show('adminQuantityRestriction', '<?= GetMessageJS("SOCNET_RIGHTS_RESTR_TITLE") ?>', BX('adminRestrContent'))"></span>

                                <script>
                                    BX.bind(BX("group_admin"), "click", function (event) {
                                        if (BX("group_admin").checked) {
                                            event.preventDefault();
                                            BX.PopupWindowManager.create("menu-custom-preset-delete-popup", null, {
                                                closeIcon: true,
                                                contentColor: "white",
                                                contentNoPaddings: true,
                                                content: "<div style='padding: 10px;'>" + BX.message("SOCNET_MOVE_RIGHTS_CONFIRM") + "</div>",
                                                titleBar: BX.message("SOCNET_MOVE_RIGHTS_CONFIRM_TITLE"),
                                                buttons: [
                                                    (button = new BX.PopupWindowButton({
                                                        text: "OK",
                                                        className: "popup-window-button-create",
                                                        events: {
                                                            click: function () {
                                                                BX("group_admin").checked = BX("group_admin").checked ? "" : "checked";
                                                                modifyGroups();
                                                                this.popupWindow.close();
                                                            }
                                                        }
                                                    })),
                                                    new BX.PopupWindowButton({
                                                        text: BX.message('SOCNET_BUTTON_CANCEL'),
                                                        className: "popup-window-button-link popup-window-button-link-cancel",
                                                        events: {
                                                            click: function () {
                                                                this.popupWindow.close();
                                                            }
                                                        }
                                                    })
                                                ]
                                            }).show();
                                        }
                                        else {
                                            BX("group_admin").checked = "";
                                        }
                                    })
                                </script>
                                <?
                                endif ?>
                            </div>
                        <?endif;
                        if (is_array($arResult["GROUPS_LIST_HIDDEN"])):
                            foreach ($arResult["GROUPS_LIST_HIDDEN"] as $key => $group_id):?>
                                <input type="hidden" id="group_<?= $group_id ?>" name="GROUP_ID[]"
                                       value="<?= $group_id ?>"><?
                            endforeach;
                        endif;
                        ?></td><?
                        break;
                    case "UF_SKILLS":
                    case "UF_INTERESTS":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        ?>
                        <td class="content-edit-form-field-textarea" colspan="2"><textarea name="<?
                        echo $FIELD ?>" class="content-edit-form-field-input-textarea"><?= $value ?></textarea></td><?
                        break;
                    case "UF_LANGS":
                        $langTags = $value ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td id="parent-container" class="content-edit-form-field-textarea" colspan="2"><?
                        $APPLICATION->IncludeComponent("bitrix:search.tags.input", "autocomplete", Array(
                            "PAGE_ELEMENTS" => "10",
                            "SORT_BY_CNT" => "Y",
                            "TEXT" => "",
                            "TMPL_IFRAME" => "N",
                            "values" => $value,
                            "NAME" => $FIELD,
                            "VALUE" => "",
                            "arrFILTER" => "lg",
                            "SITE_ID" => "lg"

                        )); ?>
                        <textarea name="<?
                    echo $FIELD; ?>" id="saved-tags" class="content-edit-form-field-input-textarea"
                                  onkeypress="return false;"><?= $value ?></textarea><?
                        $arTags = explode(",", $value);
                        $numberOfTags = count($arTags);
                        if (!empty($arTags[0])) {
                            for ($i = 0; $i < $numberOfTags; $i++) { ?>
                                <div class="tag"><?= $arTags[$i] ?>
                                <div class="delete" onclick="this.parentNode.remove();"></div></div><?
                            }
                        } ?>
                        </td><?
                        break;
// the_start
                    case "UF_DEPARTMENT":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2">

                        <? if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) { ?>
                            <div class="social-group-create-options-item-column-one social-group-create-form-control-block"><?

									$selectorName = randString(6);

										?><div class="social-group-create-control-inner social-group-create-form-field feed-add-post-destination-wrap" id="sonet_group_create_popup_users_container_post_<?=$selectorName?>">
											<span id="sonet_group_create_popup_users_item_post_<?=$selectorName?>"></span>
											<span class="feed-add-destination-input-box" id="sonet_group_create_popup_users_input_box_post_<?=$selectorName?>">
												<input type="text" value="" class="feed-add-destination-inp" id="sonet_group_create_popup_users_input_post_<?=$selectorName?>">
											</span>
											<a href="#" class="feed-add-destination-link" id="sonet_group_create_popup_users_tag_post_<?=$selectorName?>">Добавить отдел</a><?

											$arStructure = CSocNetLogDestination::GetStucture(array(
												"LAZY_LOAD" => true, "DEPARTMENT_ID" => false
                                            ));
                                            foreach($arStructure['department'] as $key => $arValue) {
                                                $navDepartment = CIBlockSection::GetNavChain(5, $arValue["entityId"]);
                                                $arNavDepartment = ""; 
                                                while($sectionPath = $navDepartment->GetNext()) {
                                                    $arNavDepartment = $arNavDepartment.(($arNavDepartment) ? " / " : "").$sectionPath["NAME"]; 
                                                }
                                                $arStructure['department'][$key]["navChain"] = $arNavDepartment;
                                            }
                                            $depValue = array();
                                            foreach($value as $depNumber) $depValue['DR'.$depNumber] = 'department';

											?><script>
                                                $("body").bind("DOMSubtreeModified DOMNodeInserted DOMNodeRemoved propertychange", function () {
                                                    // console.log('popup:', $('#BXSocNetLogDestination').length);
                                                    if ($('.tooltip').length != 0 && $('#BXSocNetLogDestination').length == 0) $('.tooltip').each(function () { 
                                                        $(this).attr('style', ''); 
                                                    });
                                                });
                                                var arValue = <?=(empty($depValue)? '{}': CUtil::PhpToJSObject($depValue))?>;
												var department = <?=($arStructure && !empty($arStructure['department']) ? CUtil::PhpToJSObject($arStructure['department']) : '{}')?>;
                                                var departmentRelation = BX.SocNetLogDestination.buildDepartmentRelation(department);
                                                // console.log(arValue);

												BX.ready(function() {
                                                    BX.BXGCE.init({
                                                        config: {refresh: "Y"},
                                                        single: false
                                                    });
                                                    BX.message({
                                                        SONET_GCE_T_DEST_LINK_1 : 'Добавить отдел',
                                                        SONET_GCE_T_DEST_LINK_2 : 'Добавить ещё',
                                                        LM_POPUP_CHECK_STRUCTURE : 'Выбрать подразделение',
                                                        LM_POPUP_CAN_SELECT_ALSO : 'DR0',
                                                    });
													BX.SocNetLogDestination.init({
														name : '<?=$selectorName?>',
														searchInput : BX('sonet_group_create_popup_users_input_post_<?=$selectorName?>'),
														lastTabDisable : true,
														departmentSelectDisable : false,
														userSearchArea : 'E',
														allowSearchSelf: false,
														extranetUser :  false,
														allowAddSocNetGroup: false,
														siteDepartmentID : false,
														bindMainPopup : {
															node : BX('sonet_group_create_popup_users_container_post_<?=$selectorName?>'),
															offsetTop : '5px',
															offsetLeft: '15px'
														},
														bindSearchPopup : {
															node : BX('sonet_group_create_popup_users_container_post_<?=$selectorName?>'),
															offsetTop : '5px',
															offsetLeft: '15px'
														},
														callback : {
															select : BX.BXGCE.selectCallback,
															unSelect : BX.delegate(BX.SocNetLogDestination.BXfpUnSelectCallback, {
																formName: '<?=$selectorName?>',
																inputContainerName: 'sonet_group_create_popup_users_item_post_<?=$selectorName?>',
																inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>',
																tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>',
																tagLink1: BX.message('SONET_GCE_T_DEST_LINK_1'),
																tagLink2: BX.message('SONET_GCE_T_DEST_LINK_2')
															}),
															openDialog : BX.delegate(BX.BXGCE.openDialogCallback, {
																inputBoxName: 'sonet_group_create_popup_users_input_box_post_<?=$selectorName?>',
																inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>',
																tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>'
															}),
															closeDialog : BX.delegate(BX.SocNetLogDestination.BXfpCloseDialogCallback, {
																inputBoxName: 'sonet_group_create_popup_users_input_box_post_<?=$selectorName?>',
																inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>',
																tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>'
															}),
															openSearch : BX.delegate(BX.BXGCE.openDialogCallback, {
																inputBoxName: 'sonet_group_create_popup_users_input_box_post_<?=$selectorName?>',
																inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>',
																tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>'
															})
														},
														items : {
															users : {},
															groups : {},
															sonetgroups : {},
															department : department,
															departmentRelation : departmentRelation
														},
														itemsLast : {
															users : {},
															sonetgroups : {},
															department : {},
															groups : {}
														},
														itemsSelected : arValue,
														destSort : {}
													});
													for(var iid in department) {
														var categoryId = department[iid]['entityId'];
                                                        BX.SocNetLogDestination.obDepartmentLoad['<?=$selectorName?>'][categoryId] = true;
													}
													BX.BXGCE.arUserSelector.push('<?=$selectorName?>');
													BX.bind(BX('sonet_group_create_popup_users_input_post_<?=$selectorName?>'), 'keyup', BX.delegate(BX.SocNetLogDestination.BXfpSearch, {
														formName: '<?=$selectorName?>',
														inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>',
														tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>'
													}));
													BX.bind(BX('sonet_group_create_popup_users_input_post_<?=$selectorName?>'), 'keydown', BX.delegate(BX.SocNetLogDestination.BXfpSearchBefore, {
														formName: '<?=$selectorName?>',
														inputName: 'sonet_group_create_popup_users_input_post_<?=$selectorName?>'
													}));
													BX.bind(BX('sonet_group_create_popup_users_input_post_<?=$selectorName?>'), 'blur', BX.delegate(BX.SocNetLogDestination.BXfpBlurInput, {
														inputBoxName: 'sonet_group_create_popup_users_input_box_post_<?=$selectorName?>',
														tagInputName: 'sonet_group_create_popup_users_tag_post_<?=$selectorName?>'
													}));
													BX.bind(BX('sonet_group_create_popup_users_input_post_<?=$selectorName?>'), 'click', function(e) {
														BX.BXGCE.setSelector('<?=$selectorName?>');
														BX.SocNetLogDestination.openDialog('<?=$selectorName?>');
														BX.PreventDefault(e);
													});
													BX.bind(BX('sonet_group_create_popup_users_container_post_<?=$selectorName?>'), 'click', function(e) {
                                                        // console.log(1);
                                                        BX.BXGCE.setSelector('<?=$selectorName?>');
														BX.SocNetLogDestination.openDialog('<?=$selectorName?>');
                                                        BX.PreventDefault(e);
                                                        // console.log(2);
													});
												});
											</script>
										</div>
                                        <input type="hidden" name="NEW_INVITE_FORM" value="Y">
									</div>
                        
                            <?if (0) {?>
                                <select name="UF_DEPARTMENT[]" size="20" multiple="multiple">
                                    <option value="0" <?= in_array(0, $value) ? 'selected' : '' ;?>>Нет</option><?
                                    $rsDepartments = CIBlockSection::GetTreeList(array(
                                        "IBLOCK_ID" => intval(COption::GetOptionInt('intranet', 'iblock_structure', false)),
                                    ));
                                    while ($arDepartment = $rsDepartments->GetNext()) {
                                        ?>
                                        <option value="<?
                                        echo $arDepartment["ID"] ?>" <?
                                        if (is_array($value) && in_array($arDepartment["ID"], $value)) echo "selected" ?>><?
                                        echo str_repeat("&nbsp;.&nbsp;", $arDepartment["DEPTH_LEVEL"]) ?><?
                                        echo $arDepartment["NAME"] ?></option><?
                                    } ?>
                                </select>
                            <?}?>
                        <? } else { ?>
                               <? $rsDepartments = CIBlockSection::GetTreeList(array(
                                    "IBLOCK_ID" => intval(COption::GetOptionInt('intranet', 'iblock_structure', false)),
                                    "ID" => $value[0],
                                )); ?>
                                <span><?= $rsDepartments->GetNext()['NAME'];?></span><?
                            }
                            ?>
                        </td>
                        <?
                        break;

                    case "UF_POSITION_WEIGHT":
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                            ?>
                            <td class="content-edit-form-field-input" colspan="2"><?
                            if (substr($FIELD, 0, 3) == 'UF_' && !in_array($FIELD, array("UF_SKYPE", "UF_WEB_SITES"))) {
                                $APPLICATION->IncludeComponent(
                                    'bitrix:system.field.edit',
                                    $arResult['USER_PROPERTY_ALL'][$FIELD]['USER_TYPE_ID'],
                                    array(
                                        'arUserField' => $arResult['USER_PROPERTY_ALL'][$FIELD],
                                        'form_name' => 'user_profile_edit',
                                    ),
                                    null,
                                    array('HIDE_ICONS' => 'Y')
                                );
                            } else { ?>
                                <input type="text" name="<?= $FIELD ?>" value="<?= $value ?>"
                                       class="content-edit-form-field-input-text"/> <?
                            } ?>
                            </td><?
                        }
                        break;
                    case "UF_SUB_UNIT":
                    case "UF_PASS_CHIEF":
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                            ?>
                            <td class="content-edit-form-field-input" colspan="2"><?
                            if (substr($FIELD, 0, 3) == 'UF_' && !in_array($FIELD, array("UF_SKYPE", "UF_WEB_SITES"))) {
                                $APPLICATION->IncludeComponent(
                                    'bitrix:system.field.edit',
                                    $arResult['USER_PROPERTY_ALL'][$FIELD]['USER_TYPE_ID'],
                                    array(
                                        'arUserField' => $arResult['USER_PROPERTY_ALL'][$FIELD],
                                        'form_name' => 'user_profile_edit',
                                    ),
                                    null,
                                    array('HIDE_ICONS' => 'Y')
                                );
                            } else { ?>
                                <input type="text" name="<?= $FIELD ?>" value="<?= $value ?>"
                                       class="content-edit-form-field-input-text"/> <?
                            } ?>
                            </td><?
                        } elseif ($value) { ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input"
                                colspan="2"><?= (CIBlockSection::GetList(array("SORT" => "ASC"), array("IBLOCK_ID" => 5, "ID" => $value), false, $arSelect = array("NAME")))->GetNext()['NAME']; ?></td>
                            <?
                        }
                        break;
                    case "PERSONAL_MOBILE":
                    case 'PERSONAL_PHONE':
                    case 'WORK_PHONE':
                    case 'UF_PHONE_INNER':
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2">
                        <input type="text" name="<?
                        echo $FIELD ?>" value="<?= $value ?>" class="content-edit-form-field-input-text"/>
                        </td><?
                        break;
                    case "UF_TWITTER":
                    case "UF_FACEBOOK":
                    case "UF_LINKEDIN":
                    case "UF_XING":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        ?>
                        <td class="content-edit-form-field-input" colspan="2">
                            <input type="text" name="<?
                            echo $FIELD ?>" placeholder="<?= $SocNetProfileExample[$FIELD] ?>"
                                   value="<?= $arResult["User"][$FIELD] ?>" class="content-edit-form-field-input-text"/>
                        </td>
                        <?
                        break;
                    case "NAME":
                    case "LAST_NAME":
                    case "SECOND_NAME":?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2"> <?
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                            ?><input type="text" name="<?= $FIELD ?>" value="<?= $value ?>"
                                     class="content-edit-form-field-input-text"/><?
                        } else { ?>
                            <span><?= $value ?></span><?
                        } ?>
                        </td><?
                        break;
                    case 'UF_ADDRESS':
                        //if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                        ?>
                        <td class="content-edit-form-field-input" colspan="2"><?

                        $APPLICATION->IncludeComponent(
                            'bitrix:system.field.edit',
                            $arResult['USER_PROPERTY_ALL'][$FIELD]['USER_TYPE_ID'],
                            array(
                                'arUserField' => $arResult['USER_PROPERTY_ALL'][$FIELD],
                                'form_name' => 'user_profile_edit',
                            ),
                            null,
                            array('HIDE_ICONS' => 'Y')
                        ); ?>

                        </td><?/*
                        } elseif ($value) { ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input"
                                colspan="2"><?= CIBlockElement::GetByID($value)->GetNext()['NAME']; ?></td>
                            <?
                        }*/
                        break;
                    case "UF_CABINET":
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2">
                        <input type="text" name="<?= $FIELD ?>" value="<?= $value ?>" class="content-edit-form-field-input-text"/>
                        </td><?

                        break;
                    case "UF_CONTROLLER":
                        if(in_array(1, $USER->GetUserGroupArray())) {
                            $filter = [
                                "GROUPS_ID" => [31],
                                "ACTIVE" => "Y",
                            ];
                            $controlerList = CUser::GetList($by, $order, $filter); ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input" colspan="2">
                            <select name="<?= $FIELD; ?>">
                                <option value="">Не выбрано</option><?
                                while ($controler = $controlerList->Fetch()) { ?>
                                <option value="<?= $controler['ID']; ?>" <?= $value == $controler['ID'] ? 'selected' : ''; ?>>
                                    <?= "{$controler['LAST_NAME']} {$controler['NAME']} {$controler['SECOND_NAME']}"; ?>
                                    </option><?
                                } ?>
                            </select>
                            </td><?
                        }
                        break;
                    case "WORK_POSITION":
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                        ?>
                        <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                        <td class="content-edit-form-field-input" colspan="2">
                            <input type="text" name="<?= $FIELD ?>" value="<?= $value ?>"
                                     class="content-edit-form-field-input-text"/>
                            </td><?
                        }
                        break;
                        
                    default:
                        if (array_intersect((array_merge($admins, $HR)), $USER->GetUserGroupArray())) {
                            ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td><?
                            ?>
                            <td class="content-edit-form-field-input" colspan="2"><?
                            if (substr($FIELD, 0, 3) == 'UF_' && !in_array($FIELD, array("UF_SKYPE", "UF_WEB_SITES"))) {
                                $APPLICATION->IncludeComponent(
                                    'bitrix:system.field.edit',
                                    $arResult['USER_PROPERTY_ALL'][$FIELD]['USER_TYPE_ID'],
                                    array(
                                        'arUserField' => $arResult['USER_PROPERTY_ALL'][$FIELD],
                                        'form_name' => 'user_profile_edit',
                                    ),
                                    null,
                                    array('HIDE_ICONS' => 'Y')
                                );
                            } else { ?>
                                <input type="text" name="<?= $FIELD ?>" value="<?= $value ?>"
                                       class="content-edit-form-field-input-text"/> <?
                            } ?>
                            </td><?
                        } elseif ($value) { ?>
                            <td class="content-edit-form-field-name"><?= $arResult['USER_PROP'][$FIELD] ? $arResult['USER_PROP'][$FIELD] : GetMessage('ISL_' . $FIELD); ?></td>
                            <td class="content-edit-form-field-input" colspan="2"><?= $value ?></td>
                            <?
                        }
                }
                ?>
            </tr>
            <? if ($bBitrix24 && $FIELD == "PERSONAL_PHOTO" && in_array('UF_PHONE_INNER', $arFields['MAIN']) && !($arResult['User']["UF_PHONE_INNER"] && $arResult['User']["PERSONAL_MOBILE"] && $arResult['User']["WORK_PHONE"])): // for phones link
            ?>
            <tr>
                <td class="content-edit-form-field-name"></td>
                <td class="content-edit-form-event-link" colspan="2"><a href="#addPhone" onclick="ShowAddPnone(this)"
                                                                        class="content-edit-form-event-link-tag"><span
                            class="content-edit-form-event-link-icon content-edit-form-icons content-edit-form-icon-socnet"></span><span
                            class="content-edit-form-event-link-name"><?= GetMessage("SOCNET_PHONE_ADD") ?></span></a>
                </td>
            </tr>
        <? endif; ?>
            <? if ($bBitrix24 && $FIELD == "UF_SKYPE" && count($arSocialFields) > 0 && $sonetLinkAddShow): ?>
            <tr>
                <td class="content-edit-form-field-name"></td>
                <td class="content-edit-form-event-link" colspan="2"><a href="#addSocnet" onclick="ShowAddSocnet(this)"
                                                                        class="content-edit-form-event-link-tag"><span
                            class="content-edit-form-event-link-icon content-edit-form-icons content-edit-form-icon-socnet"></span><span
                            class="content-edit-form-event-link-name"><?= GetMessage("SOCNET_SOCNET_ADD") ?></span></a>
                </td>
            </tr>
        <? endif ?>
        <? endforeach; ?>
        <? endforeach; ?>
        <?


        if (substr($_REQUEST['backurl'], 0, 1) != "/")
            $_REQUEST['backurl'] = "/" . $_REQUEST['backurl'];
        ?>
        <tr>
            <td class="content-edit-form-field-name"></td>
            <td class="content-edit-form-buttons" colspan="2">
                <span class="webform-button webform-button-create"
                      onclick="BX('bx_user_profile_form').elements['submit'].click()"><span
                        class="webform-button-left"></span><span
                        class="webform-button-text"><?= GetMessage("SOCNET_BUTTON_SAVE") ?></span><span
                        class="webform-button-right"></span></span>
                <span class="webform-button" onclick="location.href = '<? echo htmlspecialcharsbx(CUtil::addslashes(
                    $_REQUEST['backurl']
                        ? $_REQUEST['backurl']
                        : CComponentEngine::MakePathFromTemplate($arParams["PATH_TO_USER"], array("user_id" => $arParams["ID"]))
                )) ?>'"><span class="webform-button-left"></span><span
                        class="webform-button-text"><?= GetMessage("SOCNET_BUTTON_CANCEL") ?></span><span
                        class="webform-button-right"></span></span>
            </td>
        </tr>
        </tbody>
    </table>
    <input type="submit" name="submit" value="Y" style="opacity:0; filter: alpha(opacity=0);"/>
</form>

<script src="/bitrix/js/main/jquery/jquery-2.1.3.min.js"></script>
<script>
    document.forms["user_profile_edit"].addEventListener('submit', function(e){
        // e.preventDefault();
        // console.log(this["UF_DEPARTMENT[]"]);
        if (!this["UF_DEPARTMENT[]"]) $(this).append('<input type="hidden" name="UF_DEPARTMENT[]" value="0" />');
    });    

    BX.message({
        "SOCNET_MOVE_RIGHTS_CONFIRM": "<?=GetMessageJS("SOCNET_MOVE_RIGHTS_CONFIRM")?>",
        "SOCNET_MOVE_RIGHTS_CONFIRM_TITLE": "<?=GetMessageJS("SOCNET_MOVE_RIGHTS_CONFIRM_TITLE")?>",
        "SOCNET_BUTTON_CANCEL": "<?=GetMessageJS("SOCNET_BUTTON_CANCEL")?>"
    });

    function confirmDelete(event) {
        if (confirm("<?=$arResult["User"]["ACTIVE"] == "Y" ? GetMessage("SOCNET_CONFIRM_FIRE1") : GetMessage("SOCNET_CONFIRM_RECOVER1")?>"))
            return true;
        else
            event.preventDefault();
    }

    function modifyGroups() {
        if (!BX("group_admin").checked) {
            var employee_group = BX("group_11");
            if (!employee_group) {
                BX("bx_user_profile_form").appendChild(BX.create("input", {
                        props: {
                            'value': '11',
                            'type': "hidden",
                            'name': "GROUP_ID[]",
                            'id': "group_11"
                        }
                    })
                );
            }
            var portal_admin_group = BX("group_12");
            if (portal_admin_group)
                BX.remove(portal_admin_group);
        }
        else {
            var portal_admin_group = BX("group_12");
            if (!portal_admin_group) {
                BX("bx_user_profile_form").appendChild(BX.create("input", {
                        props: {
                            'value': '12',
                            'type': "hidden",
                            'name': "GROUP_ID[]",
                            'id': "group_12"
                        }
                    })
                );
            }
            var employee_group = BX("group_11");
            if (employee_group)
                BX.remove(employee_group);
        }
    }

    function bxUpeToggleHiddenField(tableId, fieldId, show) {
        var elements = BX.findChildren(BX(tableId), {attribute: {'data-field-id': '' + fieldId + ''}}, true);
        if (elements != null) {
            BX.fx.colorAnimate.addRule('animationRule', "#FFF", "#faeeb4", "background-color", 50, 1, true);

            for (var i = 0; i < elements.length; i++) {
                if (typeof show == 'undefined') {
                    if (elements[i].style.display == 'none') {
                        BX.fx.colorAnimate(elements[i], 'animationRule');

                        elements[i].style.display = 'table-row';
                    }
                    else
                        elements[i].style.display = 'none';
                }
                else {
                    if (elements[i].style.display == 'none' && !!show) {
                        BX.fx.colorAnimate(elements[i], 'animationRule');

                        elements[i].style.display = 'table-row';
                    }
                    else if (!show) {
                        elements[i].style.display = 'none';
                    }
                }
            }
        }
        return false;
    }

    function ShowAddSocnet(bindElement) {
        var form = document.forms["user_profile_edit"];
        BX.PopupMenu.show('socnet_add', bindElement, [
                <?if (in_array("UF_TWITTER", $arSocialFields)):?>
                {
                    text: "<?=GetMessage("ISL_UF_TWITTER")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='UF_TWITTER']").style.display = "";
                        this.popupWindow.close();
                    }
                },
                <?endif?>
                <?if (in_array("UF_FACEBOOK", $arSocialFields)):?>
                {
                    text: "<?=GetMessage("ISL_UF_FACEBOOK")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='UF_FACEBOOK']").style.display = "";
                        this.popupWindow.close();
                    }
                },
                <?endif?>
                <?if (in_array("UF_LINKEDIN", $arSocialFields)):?>
                {
                    text: "<?=GetMessage("ISL_UF_LINKEDIN")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='UF_LINKEDIN']").style.display = "";
                        this.popupWindow.close();
                    }
                },
                <?endif?>
                <?if (in_array("UF_XING", $arSocialFields)):?>
                {
                    text: "<?=GetMessage("ISL_UF_XING")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='UF_XING']").style.display = "";
                        this.popupWindow.close();
                    }
                }
                <?endif?>
            ],
            {
                offsetTop: 10,
                offsetLeft: 30,
                angle: true
            })
    }

    function ShowAddPnone(bindElement) {
        var form = document.forms["user_profile_edit"];
        BX.PopupMenu.show('phone_add', bindElement, [
                {
                    text: "<?=GetMessage("ISL_PERSONAL_MOBILE")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='PERSONAL_MOBILE']").style.display = "";
                        this.popupWindow.close();
                    }
                },
                {
                    text: "<?=GetMessage("ISL_WORK_PHONE")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='WORK_PHONE']").style.display = "";
                        this.popupWindow.close();
                    }
                },
                {
                    text: "<?=GetMessage("ISL_UF_PHONE_INNER")?>", className: "menu-popup-no-icon", onclick: function () {
                        form.querySelector("[data-role='UF_PHONE_INNER']").style.display = "";
                        this.popupWindow.close();
                    }
                }
            ],
            {
                offsetTop: 10,
                offsetLeft: 30,
                angle: true
            })
    }
</script>